'use client';
import {useEffect,useRef,type ReactNode} from 'react';

/** Approved photographic transformation; native scrolling, no demo controls. */
export function StylingTransformation({children}:{children:ReactNode}){
 const sequence=useRef<HTMLDivElement>(null),stage=useRef<HTMLDivElement>(null);
 const sweep=useRef<SVGLinearGradientElement>(null),lights=useRef<SVGGElement>(null);
 useEffect(()=>{
  const section=sequence.current,pinned=stage.current;if(!section||!pinned)return;
  const reduce=matchMedia('(prefers-reduced-motion: reduce)');
  let current=0,target=0,frame=0,last=0,disposed=false,ready=false;
  const clamp=(x:number)=>Math.max(0,Math.min(1,x));
  const ease=(x:number)=>{x=clamp(x);return x*x*(3-2*x)};
  const paint=(p:number)=>{
   const coat=clamp((p-.1)/.63),edge=180+coat*1280,lamp=ease((p-.79)/.14);
   sweep.current?.setAttribute('x1',String(edge-110));sweep.current?.setAttribute('x2',String(edge+20));lights.current?.setAttribute('opacity',String(lamp));
   pinned.dataset.progress=p.toFixed(4);pinned.dataset.coat=coat.toFixed(4);pinned.dataset.lights=lamp.toFixed(4);
  };
  const tick=(now:number)=>{
   if(disposed)return;const dt=Math.min(64,now-last);last=now;
   current=reduce.matches?target:current+(target-current)*(1-Math.exp(-dt/90));
   if(Math.abs(current-target)<.0001)current=target;paint(current);
   frame=current!==target?requestAnimationFrame(tick):0;
  };
  const update=()=>{
   const style=getComputedStyle(pinned),inset=parseFloat(style.top)||0;
   if(style.position==='sticky'){
    target=clamp((inset-section.getBoundingClientRect().top)/Math.max(1,section.offsetHeight-pinned.offsetHeight));
   }else{
    // On phones the whole photographic scene scrolls together, without pinning.
    // Finish while the car is still visible, using stable svh geometry.
    const viewport=document.querySelector('.hero')?.clientHeight||innerHeight;
    const start=viewport*.76,end=Math.max(64,viewport*.15);
    target=clamp((start-section.getBoundingClientRect().top)/(start-end));
   }
   if(ready&&!frame){last=performance.now();frame=requestAnimationFrame(tick)}
  };
  const urls=[...new Set(Array.from(section.querySelectorAll('svg image'),el=>el.getAttribute('href')!))];
  Promise.all(urls.map(src=>{const img=new Image();img.src=src;return img.decode()})).then(()=>{
   if(disposed)return;ready=true;section.dataset.sceneState='ready';update();
  }).catch(()=>{if(!disposed)section.dataset.sceneState='fallback'});
  addEventListener('scroll',update,{passive:true});addEventListener('resize',update);reduce.addEventListener('change',update);paint(0);
  return()=>{disposed=true;cancelAnimationFrame(frame);removeEventListener('scroll',update);removeEventListener('resize',update);reduce.removeEventListener('change',update)};
 },[]);
 return <div className="styling-sequence" ref={sequence}><div className="styling-stage" ref={stage}><div className="styling-heading">{children}</div><div className="styling-transform-photo"><svg viewBox="0 0 1536 1024" role="img" aria-label="BMW: глянцевый кузов постепенно становится матовым, затем включаются фары">
<defs>
<filter id="bmw-edge"><feGaussianBlur stdDeviation=".65"/></filter>
<mask id="bmw-silhouette" maskUnits="userSpaceOnUse" x="0" y="0" width="1536" height="1024"><path filter="url(#bmw-edge)" fill="white" d="M262 545 L278 509 L283 489 Q311 456 356 440 Q421 420 558 415 L561 403 Q568 392 598 393 L598 400 Q658 324 774 310 Q884 298 1006 301 Q1103 298 1149 330 Q1200 359 1260 425 L1287 440 Q1314 452 1318 489 L1322 530 L1321 565 L1306 594 Q1305 652 1279 674 Q1261 689 1229 682 Q1197 680 1186 648 L974 681 Q960 718 928 732 Q895 748 858 738 Q823 735 802 695 L467 684 Q450 713 414 721 Q350 729 316 687 L269 670 Q260 663 263 640 Z"/></mask>
<radialGradient id="podium-contact"><stop stopColor="#000" stopOpacity=".9"/><stop offset="1" stopColor="#000" stopOpacity="0"/></radialGradient>
<linearGradient id="bmw-sweep" ref={sweep} gradientUnits="userSpaceOnUse" x1="0" x2="130" y1="0" y2="0"><stop offset="0" stopColor="white"/><stop offset="1" stopColor="black"/></linearGradient>
<mask id="bmw-progress-mask" maskUnits="userSpaceOnUse" x="0" y="0" width="1536" height="1024"><rect width="1536" height="1024" fill="url(#bmw-sweep)"/></mask>
<filter id="bmw-soft-mask"><feGaussianBlur stdDeviation="1.5"/></filter>
<mask id="bmw-body-mask" maskUnits="userSpaceOnUse" x="0" y="0" width="1536" height="1024"><g filter="url(#bmw-soft-mask)"><path fill="white" d="M263 539 L281 487 Q303 450 359 432 L552 413 Q641 319 773 308 Q977 284 1118 316 Q1205 333 1261 425 L1300 450 Q1328 485 1319 550 L1300 637 L1245 677 L955 711 L801 712 L721 694 L312 685 L264 662 Z"/>

<path fill="black" d="M588 409 Q666 323 779 319 L984 311 L938 428 L584 419 Z M1003 321 Q1073 313 1125 331 L1227 420 L984 421 Z"/>
<path fill="black" d="M977 389 Q1016 372 1056 391 L1054 422 L976 425 Z M329 494 Q345 480 420 481 L452 502 Q478 481 534 480 L603 493 L618 577 L594 606 L350 608 L329 580 Z"/>
<ellipse fill="black" cx="885" cy="620" rx="92" ry="124"/><ellipse fill="black" cx="1267" cy="593" rx="64" ry="99"/>
<path fill="black" d="M620 495 L819 478 L827 488 L791 516 L706 531 L641 523 Z M282 487 L328 498 L324 530 L276 520 Z M267 564 L318 565 L324 659 L277 652 Z M637 581 L769 563 L776 658 L629 674 Z M327 618 L626 613 L623 679 L333 671 Z M971 618 L1240 593 L1234 625 L964 651 Z"/>
</g></mask>
<clipPath id="bmw-lamps"><path d="M620 495 L819 478 L827 488 L791 516 L706 531 L641 523 Z M282 487 L328 498 L324 530 L276 520 Z"/></clipPath>
<radialGradient id="bmw-light-spill"><stop stopColor="#c9e6ff" stopOpacity=".22"/><stop offset="1" stopColor="#c9e6ff" stopOpacity="0"/></radialGradient>
<filter id="bmw-bloom"><feGaussianBlur stdDeviation="5"/></filter>
</defs>
<image href="/assets/podium-v43.webp" width="1536" height="1024"/>
<ellipse cx="794" cy="694" rx="548" ry="57" fill="url(#podium-contact)"/>
<ellipse cx="1261" cy="679" rx="68" ry="13" fill="url(#podium-contact)"/>
<ellipse cx="886" cy="738" rx="91" ry="15" fill="url(#podium-contact)"/>
<ellipse cx="394" cy="716" rx="82" ry="14" fill="url(#podium-contact)"/>
<g mask="url(#bmw-silhouette)">
<image id="bmw-base-image" href="/assets/bmw-gloss-off.webp" width="1536" height="1024"/>
<g mask="url(#bmw-body-mask)"><image id="bmw-matte-image" href="/assets/bmw-matte-off.webp" width="1536" height="1024" mask="url(#bmw-progress-mask)"/></g>
</g>
<g id="bmw-lights" ref={lights} opacity="0"><image href="/assets/styling-studio-v21.webp" width="1536" height="1024" clipPath="url(#bmw-lamps)"/><image href="/assets/styling-studio-v21.webp" width="1536" height="1024" clipPath="url(#bmw-lamps)" filter="url(#bmw-bloom)" opacity=".34"/><ellipse cx="650" cy="776" rx="275" ry="66" fill="url(#bmw-light-spill)"/><ellipse cx="280" cy="737" rx="110" ry="38" fill="url(#bmw-light-spill)"/></g>
</svg></div></div></div>;
}
