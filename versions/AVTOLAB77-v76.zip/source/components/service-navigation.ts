/** Navigation state is separate from the page DOM so returning never replays the intro. */
type ServicePosition={y:number;left:number;card:string;top:number};
type Section='services'|'projects'|'digital';
let section:Section='services';
const positions:Partial<Record<Section,ServicePosition>>={};
const storageKey=()=>section==='digital'?'avtolab:digital-position-v75':section==='services'?'avtolab:service-position-v70':'avtolab:project-position-v72';
const railSelector=()=>section==='digital'?'.digital-grid':section==='services'?'.service-rail':'.projects-rail';
export const isStylingPage=(href:string)=>/^\/?services\/styling\/[^/?#]+/.test(href);
export const isDigitalPage=(href:string)=>/^\/?services\/digital\/[^/?#]+/.test(href);
export const isProjectPage=(href:string)=>/^\/?projects\/[^/?#]+/.test(href);
export const isArticlePage=(href:string)=>isStylingPage(href)||isProjectPage(href)||isDigitalPage(href);
function selectSection(href:string){if(isDigitalPage(href)||href.includes('section=digital'))section='digital';else if(isProjectPage(href)||href.includes('section=projects'))section='projects';else if(isStylingPage(href)||href.includes('section=services'))section='services'}
export const isHome=(href:string)=>href.split('?')[0]==='/';
let returnIntent=false;
export function requestServiceReturn(href='/?section=services'){selectSection(href);returnIntent=true}
export function takeServiceReturnIntent(){const requested=returnIntent;returnIntent=false;return requested}
/** A URL copied after a return is not an instruction to skip the opening scene. */
export function resetHomeEntry(){
 history.scrollRestoration='manual';
 const url=new URL(location.href);
 if(['services','projects','digital'].includes(url.searchParams.get('section')??''))url.searchParams.delete('section');
 if(url.hash.startsWith('#/?')){
  const query=new URLSearchParams(url.hash.slice(3));
  if(['services','projects','digital'].includes(query.get('section')??'')){query.delete('section');url.hash=query.size?'/?'+query.toString():'/'}
 }
 if(url.href!==location.href)history.replaceState(history.state,'',url);
 window.scrollTo({top:0,behavior:'instant'});
}

function savedPosition(){
 if(positions[section])return positions[section];
 try{const value=JSON.parse(sessionStorage.getItem(storageKey())??'null');if(value&&Number.isFinite(value.y)&&Number.isFinite(value.left)&&Number.isFinite(value.top)&&typeof value.card==='string')positions[section]=value}catch{}
 return positions[section];
}
export function rememberServicePosition(card:HTMLAnchorElement){
 if(!document.querySelector('.home-scene'))return;
 selectSection(card.getAttribute('href')??'');
 const position={y:scrollY,left:document.querySelector(railSelector())?.scrollLeft??0,card:card.getAttribute('href')??'',top:document.querySelector(railSelector())?.getBoundingClientRect().top??card.getBoundingClientRect().top};
 positions[section]=position;
 try{sessionStorage.setItem(storageKey(),JSON.stringify(position))}catch{}
}
export function restoreServicePosition(){
 const rail=document.querySelector<HTMLElement>(railSelector()),saved=savedPosition();
 if(!rail)return;
 if(saved){
  rail.scrollLeft=saved.left;
  window.scrollTo({top:scrollY+rail.getBoundingClientRect().top-saved.top,behavior:'instant'});
 }else if(section==='digital')rail.scrollIntoView({block:'center',behavior:'instant'});
 else document.getElementById(section==='services'?'service-cards':'project-cards')?.scrollIntoView({block:'start',behavior:'instant'});
}
const frames=()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve())));
/** A short dissolve masks the route swap and scroll restoration; no transformed sticky ancestors. */
export function createRouteTransition(commit:(href:string)=>void|Promise<void>){
 const curtain=document.createElement('div');curtain.className='route-curtain';curtain.hidden=true;curtain.setAttribute('aria-hidden','true');document.body.appendChild(curtain);
 let generation=0,animation:Animation|null=null;
 const fade=async(opacity:number,duration:number)=>{
  const start=getComputedStyle(curtain).opacity;curtain.style.opacity=start;animation?.cancel();
  animation=curtain.animate([{opacity:start},{opacity}],{duration,easing:'cubic-bezier(.22,.7,.25,1)',fill:'forwards'});
  try{await animation.finished}catch{}
 };
 return {
  async run(href:string){
   selectSection(href);
   const own=++generation,reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
   document.documentElement.dataset.routeTransition='leaving';curtain.hidden=false;
   if(!reduced)await fade(1,240);else{animation?.cancel();curtain.style.opacity='1'}
   if(own!==generation)return;
   try{
    await commit(href);await frames();
    if(own!==generation)return;
    if(isHome(href)&&document.querySelector('.home-scene'))restoreServicePosition();
    const hero=document.querySelector<HTMLImageElement>('.service-article-hero img,.project-hero img');
    if(hero)await Promise.race([hero.decode().catch(()=>{}),new Promise(resolve=>setTimeout(resolve,600))]);
    if(own!==generation)return;
    document.documentElement.dataset.routeTransition='entering';
    if(!reduced)await fade(0,440);
   }finally{
    if(own===generation){
     animation?.cancel();curtain.style.opacity='0';curtain.hidden=true;delete document.documentElement.dataset.routeTransition;
     const saved=savedPosition();
     const focus=document.querySelector<HTMLElement>('.service-article h1')??Array.from(document.querySelectorAll<HTMLAnchorElement>(railSelector()+' a')).find(a=>a.getAttribute('href')===saved?.card);
     if(focus){if(focus.tagName==='H1')focus.tabIndex=-1;focus.focus({preventScroll:true})}
    }
   }
  },
  destroy(){generation++;animation?.cancel();curtain.remove();delete document.documentElement.dataset.routeTransition}
 };
}
