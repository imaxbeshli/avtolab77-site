'use client';
import {Atmosphere} from './Atmosphere';
/** The approved, lightly retouched artwork is displayed intact, with no re-created type or cars. */
export function CinematicHero(){return <section className="hero approved-hero"><h1 className="approved-heading">Премиальное решение для вашего автомобиля</h1><div className="hero-image approved-image"><img className="approved-artwork" src="/assets/approved-hero-v41.webp" alt="Rolls-Royce и ZEEKR на мокром полу, светящиеся цифры 77 и надпись «Премиальное решение для вашего автомобиля»" fetchPriority="high"/><Atmosphere/></div></section>}
