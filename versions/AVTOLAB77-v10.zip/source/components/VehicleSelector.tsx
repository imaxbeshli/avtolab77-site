'use client';
import {useCallback,useEffect,useRef,useState,type CSSProperties} from 'react';
import {ChevronLeft,ChevronRight,Cpu,Radio,Smartphone,User,LayoutGrid} from 'lucide-react';
import {models} from '../content/site';
import {services} from '../content/services';
const icons=[Cpu,Radio,Smartphone,User,Smartphone,LayoutGrid];
const slots=[-2,-1,0,1,2];
const duration=560;
const normalize=(index:number)=>(index%models.length+models.length)%models.length;

/** Five physical slots keep the wrap outside the viewport, in both directions. */
export function VehicleSelector(){
  const [selected,setSelected]=useState(0);
  const [motion,setMotion]=useState(0);
  const [dragX,setDragX]=useState(0);
  const [dragging,setDragging]=useState(false);
  const carousel=useRef<HTMLDivElement>(null);
  const indexRef=useRef(0);
  const directionRef=useRef(0);
  const queued=useRef(0);
  const timer=useRef<ReturnType<typeof setTimeout>|null>(null);
  const frame=useRef<number|null>(null);
  const advanceRef=useRef<(direction:number)=>void>(()=>{});
  const gesture=useRef<{x:number;y:number;id:number;horizontal:boolean}|null>(null);
  const ignoreClickUntil=useRef(0);

  const persist=useCallback((index:number)=>{
    if(window.location.protocol==='file:')return;
    const url=new URL(window.location.href);
    url.searchParams.set('model',models[index].id);
    window.history.replaceState({},'',url);
  },[]);

  const finish=useCallback(()=>{
    const direction=directionRef.current;
    if(!direction)return;
    if(timer.current){clearTimeout(timer.current);timer.current=null}
    const next=normalize(indexRef.current+direction);
    indexRef.current=next;
    directionRef.current=0;
    // Changing the image slots and snapping coordinates in one render is invisible:
    // all visible cars occupy exactly the same positions before and after the reset.
    setSelected(next);setMotion(0);setDragX(0);persist(next);
    if(queued.current){
      const nextDirection=Math.sign(queued.current);
      queued.current-=nextDirection;
      frame.current=requestAnimationFrame(()=>{
        frame.current=requestAnimationFrame(()=>advanceRef.current(nextDirection));
      });
    }
  },[persist]);

  const advance=useCallback((direction:number)=>{
    const step=Math.sign(direction);
    if(!step)return;
    if(directionRef.current){queued.current=Math.max(-3,Math.min(3,queued.current+step));return}
    if(window.matchMedia('(prefers-reduced-motion: reduce)').matches){
      const next=normalize(indexRef.current+step);
      indexRef.current=next;setSelected(next);setDragX(0);persist(next);return;
    }
    directionRef.current=step;
    setMotion(step);setDragX(0);setDragging(false);
    timer.current=setTimeout(finish,duration+90);
  },[finish,persist]);
  advanceRef.current=advance;

  useEffect(()=>{
    const raw=new URLSearchParams(window.location.search).get('model');
    const index=models.findIndex(model=>model.id===raw);
    if(index>=0){indexRef.current=index;setSelected(index)}
    return()=>{if(timer.current)clearTimeout(timer.current);if(frame.current!==null)cancelAnimationFrame(frame.current)};
  },[]);

  useEffect(()=>{
    const element=carousel.current;if(!element)return;
    let accumulated=0,lastEvent=0,lastChange=-Infinity;
    const onWheel=(event:WheelEvent)=>{
      if(event.ctrlKey||event.metaKey)return;
      const delta=Math.abs(event.deltaX)>Math.abs(event.deltaY)?event.deltaX:event.deltaY;
      if(!delta)return;
      event.preventDefault();
      const now=performance.now();
      if(now-lastEvent>180)accumulated=0;
      lastEvent=now;
      if(directionRef.current||now-lastChange<duration)return;
      accumulated+=delta*(event.deltaMode===1?16:event.deltaMode===2?element.clientWidth:1);
      if(Math.abs(accumulated)>=45){advance(Math.sign(accumulated));accumulated=0;lastChange=now}
    };
    element.addEventListener('wheel',onWheel,{passive:false});
    return()=>element.removeEventListener('wheel',onWheel);
  },[advance]);

  const resetDrag=()=>{gesture.current=null;setDragX(0);setDragging(false)};
  return <>
    <div ref={carousel} className={'vehicle-carousel'+(dragging?' is-dragging':'')+(motion?' is-moving':'')}
      data-moving={motion!==0} role="region" aria-roledescription="карусель" aria-label="Выбор модели автомобиля" tabIndex={0}
      onKeyDown={event=>{
        if(event.key==='ArrowRight'){event.preventDefault();advance(1)}
        if(event.key==='ArrowLeft'){event.preventDefault();advance(-1)}
      }}
      onPointerDown={event=>{
        if(event.button!==0||directionRef.current||(event.target as Element).closest('.round-arrow'))return;
        gesture.current={x:event.clientX,y:event.clientY,id:event.pointerId,horizontal:false};
      }}
      onPointerMove={event=>{
        const current=gesture.current;if(!current||current.id!==event.pointerId)return;
        const dx=event.clientX-current.x,dy=event.clientY-current.y;
        if(!current.horizontal){
          if(Math.abs(dy)>10&&Math.abs(dy)>Math.abs(dx)){resetDrag();return}
          if(Math.abs(dx)<8)return;
          current.horizontal=true;event.currentTarget.setPointerCapture(event.pointerId);setDragging(true);
        }
        setDragX(Math.max(-155,Math.min(155,dx)));
      }}
      onPointerUp={event=>{
        const current=gesture.current;
        if(current?.horizontal){
          const dx=event.clientX-current.x;ignoreClickUntil.current=performance.now()+300;
          if(Math.abs(dx)>45)advance(dx<0?1:-1);
        }
        if(event.currentTarget.hasPointerCapture(event.pointerId))event.currentTarget.releasePointerCapture(event.pointerId);
        resetDrag();
      }}
      onPointerCancel={resetDrag}
      onClickCapture={event=>{if(performance.now()<ignoreClickUntil.current){event.preventDefault();event.stopPropagation()}}}
    >
      <div className="vehicle-stage" aria-hidden="true"/>
      
      <div className="vehicle-track" style={{'--drag-x':`${dragX}px`,'--slide-duration':`${duration}ms`} as CSSProperties}>
        {slots.map(slot=>{
          const model=models[normalize(selected+slot)];
          const position=slot-motion;
          const hidden=Math.abs(slot)>1;
          const focused=slot===0;
          const scale=position===0?1.12:.83;
          return <button key={slot} className={'vehicle-card'+(focused?' selected':'')} data-slot={slot}
            style={{'--position':position,'--car-scale':scale,'--floor-light':position===0?1:.3,opacity:Math.abs(position)>1?0:1} as CSSProperties}
            onClick={()=>{if(slot)advance(Math.sign(slot))}} aria-label={'Выбрать '+model.name} aria-pressed={focused}
            aria-hidden={hidden} tabIndex={hidden?-1:0}
            onTransitionEnd={event=>{if(slot===0&&event.propertyName==='transform'&&event.target===event.currentTarget)finish()}}
          >
            <span className="vehicle-floor-light" aria-hidden="true"/><span className={'vehicle-reflection vehicle-'+model.tile} aria-hidden="true"/><span className="vehicle-contact-shadow"/>
            <span className={'vehicle-picture vehicle-'+model.tile} role="img" aria-label={model.name}/>
            <span className="vehicle-name">{model.name}</span>
          </button>;
        })}
      </div>
      
      <span className="visually-hidden" aria-live="polite">Выбран {models[selected].name}</span>
    </div>
    <div className="digital-grid">{services.slice(6).map((service,index)=>{
      const Icon=icons[index];return <a href={`/services/digital/${service.slug}?model=${models[selected].id}`} key={service.slug}>
        <span className="service-line-icon"><Icon/></span><span>{service.title}</span>
      </a>;
    })}</div>
  </>;
}
