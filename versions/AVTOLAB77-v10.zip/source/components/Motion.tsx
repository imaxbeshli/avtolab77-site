'use client';
import {useEffect,useState} from 'react';
let introPlayed=false;
export function Motion(){
 const [intro,setIntro]=useState(false);
 useEffect(()=>{
  const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const play=!introPlayed&&!reduced;
  introPlayed=true;
  setIntro(play);
  const timer=setTimeout(()=>setIntro(false),2200);
  const nodes=document.querySelectorAll('.home-scene .section-head,.direction,.service-card,.digital-grid a,.project-card,.studio-intro,.fact,.consult');
  if(reduced||!('IntersectionObserver' in window))return()=>clearTimeout(timer);
  nodes.forEach((el,i)=>{el.classList.add('reveal');(el as HTMLElement).style.setProperty('--delay',`${i%3*100}ms`)});
  const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('revealed');observer.unobserve(e.target)}}),{threshold:.16,rootMargin:'0px 0px -24px 0px'});
  const start=setTimeout(()=>nodes.forEach(el=>observer.observe(el)),play?2050:100);
  return()=>{clearTimeout(timer);clearTimeout(start);observer.disconnect();nodes.forEach(el=>el.classList.remove('reveal','revealed'))};
 },[]);
 return intro?<div className="intro" aria-hidden="true"><div className="intro-brand"><div className="logo-art"/><span className="intro-rule"/></div></div>:null;
}
export function useRail(){useEffect(()=>{const rail=document.querySelector<HTMLElement>('.service-rail');if(!rail)return;let x=0,start=0,down=false,moved=false;const wheel=(e:WheelEvent)=>{if(e.ctrlKey||rail.scrollWidth<=rail.clientWidth)return;const delta=Math.abs(e.deltaX)>Math.abs(e.deltaY)?e.deltaX:e.deltaY;const end=rail.scrollWidth-rail.clientWidth;if((delta<0&&rail.scrollLeft<=0)||(delta>0&&rail.scrollLeft>=end-1))return;e.preventDefault();rail.scrollLeft+=delta};const press=(e:PointerEvent)=>{if(e.pointerType!=='mouse'||e.button!==0)return;down=true;moved=false;x=e.clientX;start=rail.scrollLeft};const move=(e:PointerEvent)=>{if(!down)return;if(Math.abs(e.clientX-x)>5){moved=true;rail.scrollLeft=start+x-e.clientX;e.preventDefault()}};const up=()=>{down=false};const click=(e:MouseEvent)=>{if(moved){e.preventDefault();e.stopPropagation();moved=false}};const drag=(e:DragEvent)=>e.preventDefault();rail.addEventListener('wheel',wheel,{passive:false});rail.addEventListener('pointerdown',press);window.addEventListener('pointermove',move);window.addEventListener('pointerup',up);rail.addEventListener('click',click,true);rail.addEventListener('dragstart',drag);return()=>{rail.removeEventListener('wheel',wheel);rail.removeEventListener('pointerdown',press);window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',up);rail.removeEventListener('click',click,true);rail.removeEventListener('dragstart',drag)}},[])}
