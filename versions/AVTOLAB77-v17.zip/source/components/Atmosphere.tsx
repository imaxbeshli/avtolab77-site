'use client';
import {useEffect,useRef,useState} from 'react';
import {mountStudio} from './studio3d';
export function Atmosphere(){
 const host=useRef<HTMLDivElement>(null);const [ready,setReady]=useState(false);
 useEffect(()=>{const prepare=()=>setReady(true);if(!document.querySelector('.intro'))prepare();window.addEventListener('avtolab:prepare-atmosphere',prepare);return()=>window.removeEventListener('avtolab:prepare-atmosphere',prepare)},[]);
 useEffect(()=>{if(!host.current||!ready)return;try{return mountStudio(host.current)}catch(error){host.current.dataset.engine='fallback';console.warn('3D studio unavailable',error);window.dispatchEvent(new Event('avtolab:atmosphere-ready'))}},[ready]);
 return <div ref={host} className="hero-atmosphere studio-3d" aria-hidden="true"/>;
}
