'use client';
import {useEffect,useRef} from 'react';
export const heroArtwork='/assets/hero-clean-v46.webp';
const rrLenses='M462 578 L528 579 L532 612 L464 611 Z M681 579 L720 582 L726 614 L685 617 Z';
const zeekrLenses='M923 569 L973 573 L1128 571 L1234 565 L1227 579 L1132 582 L961 583 L921 580 Z M916 594 L933 593 L933 655 L914 657 Z M1188 591 L1215 590 L1218 656 L1188 658 Z';
/** Pixel-aligned light layers; the approved photograph is never regenerated. */
export function HeroLights(){
 const root=useRef<SVGSVGElement>(null);
 useEffect(()=>{
  const el=root.current;if(!el)return;
  const reduce=matchMedia('(prefers-reduced-motion: reduce)');
  let frame=0,elapsed=0,last=0,started=false,disposed=false;
  const clamp=(n:number)=>Math.max(0,Math.min(1,n));
  const smooth=(n:number)=>{n=clamp(n);return n*n*(3-2*n)};
  const paint=(time:number)=>{
   for(const [car,delay] of [['rr',1500],['zeekr',2000]] as const){
    const light=smooth((time-delay)/400),glow=smooth((time-delay-70)/450);
    el.querySelector(`[data-off="${car}"]`)?.setAttribute('opacity',String(1-light));
    el.querySelector(`[data-glow="${car}"]`)?.setAttribute('opacity',String(glow));
    el.dataset[car]=light.toFixed(4);
   }
   el.dataset.elapsed=String(Math.round(time));
  };
  const tick=(now:number)=>{
   if(disposed)return;
   if(!document.hidden)elapsed+=Math.min(64,now-last);
   last=now;paint(elapsed);
   if(elapsed<2550)frame=requestAnimationFrame(tick);else{frame=0;el.dataset.state='on'}
  };
  const start=async()=>{
   if(started||disposed)return;started=true;
   const image=el.parentElement?.querySelector<HTMLImageElement>('.approved-artwork');
   try{await image?.decode()}catch{}
   if(disposed)return;
   el.dataset.startedAt=String(performance.now());
   if(reduce.matches){paint(2550);el.dataset.state='on';return}
   el.dataset.state='waiting';last=performance.now();frame=requestAnimationFrame(tick);
  };
  const motionChange=()=>{if(reduce.matches){cancelAnimationFrame(frame);frame=0;paint(2550);el.dataset.state='on'}};
  paint(0);el.dataset.state='off';
  window.addEventListener('avtolab:title-ready',start);reduce.addEventListener('change',motionChange);
  if(reduce.matches||el.parentElement?.dataset.titleReady==='true')void start();
  return()=>{disposed=true;cancelAnimationFrame(frame);window.removeEventListener('avtolab:title-ready',start);reduce.removeEventListener('change',motionChange)};
 },[]);
 return <svg ref={root} className="hero-headlights" viewBox="0 0 1678 937" aria-hidden="true" focusable="false">
  <defs>
   <image id="headlight-source" href={heroArtwork} width="1678" height="937"/>
   <filter id="lens-edge" x="-5%" y="-5%" width="110%" height="110%"><feGaussianBlur stdDeviation="1.1"/></filter>
   <filter id="reflection-edge" x="-50%" y="-40%" width="200%" height="180%"><feGaussianBlur stdDeviation="12"/></filter>
   <filter id="rr-unlit" filterUnits="userSpaceOnUse" x="430" y="560" width="320" height="377" colorInterpolationFilters="sRGB"><feComponentTransfer><feFuncR type="linear" slope=".12"/><feFuncG type="linear" slope=".14"/><feFuncB type="linear" slope=".16"/></feComponentTransfer></filter>
   <filter id="zeekr-unlit" filterUnits="userSpaceOnUse" x="890" y="550" width="360" height="387" colorInterpolationFilters="sRGB"><feComponentTransfer><feFuncR type="linear" slope=".12"/><feFuncG type="linear" slope=".14"/><feFuncB type="linear" slope=".16"/></feComponentTransfer></filter>
   <mask id="rr-light-mask" maskUnits="userSpaceOnUse" x="0" y="0" width="1678" height="937" style={{maskType:'luminance'}}><path d={rrLenses} fill="white" filter="url(#lens-edge)"/><g fill="white" opacity=".45" filter="url(#reflection-edge)"><ellipse cx="500" cy="854" rx="24" ry="67"/><ellipse cx="698" cy="840" rx="17" ry="55"/></g></mask>
   <mask id="zeekr-light-mask" maskUnits="userSpaceOnUse" x="0" y="0" width="1678" height="937" style={{maskType:'luminance'}}><path d={zeekrLenses} fill="white" filter="url(#lens-edge)"/><g fill="white" opacity=".4" filter="url(#reflection-edge)"><ellipse cx="926" cy="843" rx="17" ry="53"/><ellipse cx="1202" cy="851" rx="24" ry="65"/></g></mask>
   <radialGradient id="lens-glow"><stop stopColor="#dcefff" stopOpacity=".17"/><stop offset=".35" stopColor="#dcefff" stopOpacity=".07"/><stop offset="1" stopColor="#dcefff" stopOpacity="0"/></radialGradient>
   <radialGradient id="floor-glow"><stop stopColor="#cde7ff" stopOpacity=".075"/><stop offset="1" stopColor="#cde7ff" stopOpacity="0"/></radialGradient>
  </defs>
  <g data-off="rr"><use href="#headlight-source" filter="url(#rr-unlit)" mask="url(#rr-light-mask)"/></g>
  <g data-off="zeekr"><use href="#headlight-source" filter="url(#zeekr-unlit)" mask="url(#zeekr-light-mask)"/></g>
  <g data-glow="rr" opacity="0"><g fill="url(#lens-glow)"><ellipse cx="496" cy="597" rx="54" ry="29"/><ellipse cx="705" cy="599" rx="34" ry="25"/></g><g fill="url(#floor-glow)"><ellipse cx="500" cy="847" rx="44" ry="79"/><ellipse cx="698" cy="835" rx="30" ry="65"/></g></g>
  <g data-glow="zeekr" opacity="0"><g fill="url(#lens-glow)"><ellipse cx="926" cy="625" rx="28" ry="48"/><ellipse cx="1203" cy="625" rx="35" ry="52"/><ellipse cx="1070" cy="576" rx="161" ry="15"/></g><g fill="url(#floor-glow)"><ellipse cx="926" cy="843" rx="32" ry="63"/><ellipse cx="1202" cy="851" rx="40" ry="73"/></g></g>
 </svg>;
}
