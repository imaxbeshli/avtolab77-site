'use client';
import {useEffect,useRef} from 'react';

const labels=[['导航','Навигация'],['空调','Климат'],['设置','Настройки']];
export function DigitalTransformation(){
 const scene=useRef<HTMLDivElement>(null),camera=useRef<SVGGElement>(null);
 useEffect(()=>{
  const el=scene.current;if(!el)return;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const cn=el.querySelectorAll<SVGGElement>('.screen-cn'),ru=el.querySelectorAll<SVGGElement>('.screen-ru');
  let current=0,target=0,frame=0,last=0,disposed=false;
  const clamp=(n:number)=>Math.max(0,Math.min(1,n));
  const smooth=(n:number)=>{const p=clamp(n);return p*p*(3-2*p)};
  const paint=(p:number)=>{
   const zoom=reduced.matches?1:1+.1*smooth(p);
   camera.current?.setAttribute('transform',`translate(830 475) scale(${zoom}) translate(-830 -475)`);
   labels.forEach((_,i)=>{const fade=smooth((p-(.18+i*.2))/.22);cn[i].setAttribute('opacity',String(1-fade));ru[i].setAttribute('opacity',String(fade))});
   el.dataset.progress=p.toFixed(4);el.dataset.zoom=zoom.toFixed(4);
  };
  const tick=(now:number)=>{if(disposed)return;const dt=Math.min(64,now-last);last=now;current=reduced.matches?target:current+(target-current)*(1-Math.exp(-dt/120));if(Math.abs(current-target)<.0001)current=target;paint(current);frame=current!==target?requestAnimationFrame(tick):0};
  const update=()=>{
   const viewport=document.documentElement.clientHeight,start=viewport*.82,end=Math.max(78,viewport*.16);
   target=clamp((start-el.getBoundingClientRect().top)/(start-end));
   if(!frame){last=performance.now();frame=requestAnimationFrame(tick)}
  };
  paint(0);update();addEventListener('scroll',update,{passive:true});addEventListener('resize',update);reduced.addEventListener('change',update);
  return()=>{disposed=true;cancelAnimationFrame(frame);removeEventListener('scroll',update);removeEventListener('resize',update);reduced.removeEventListener('change',update)};
 },[]);
 return <div ref={scene} className="digital-interior digital-transformation" role="img" aria-label="Русификация экрана автомобиля: китайские подписи плавно меняются на Навигация, Климат и Настройки">
  <svg className="digital-camera" viewBox="0 0 1536 1024" aria-hidden="true"><g ref={camera}>
   <image href="/assets/digital-interior-v29.webp" width="1536" height="1024"/>
   {labels.map(([cn,ru],i)=><g key={ru} className="screen-label" transform={`translate(695 ${423+i*55})`}><g className="screen-cn" opacity="1"><text fontFamily="TabletChinese, sans-serif" fontSize="22" fill="#e8edf0">{cn}</text></g><g className="screen-ru" opacity="0"><text fontFamily="Manrope, sans-serif" fontSize="20" fill="#e8edf0">{ru}</text></g></g>)}
  </g></svg>
 </div>;
}
