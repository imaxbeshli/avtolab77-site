'use client';
import {studio} from '../content/studio';

export function LocationMap({active}:{active:boolean}){
 return <div className="booking-map booking-map-online">
  {active&&<iframe
   src={studio.mapEmbed}
   title="Интерактивная Яндекс Карта — Автолаб77"
   loading="lazy"
   referrerPolicy="strict-origin-when-cross-origin"
   allowFullScreen
  />}
 </div>;
}
