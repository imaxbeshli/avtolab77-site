'use client';
import {Clock,MapPin,Navigation} from 'lucide-react';
import {studio,studioRoute} from '../content/studio';

export function BookingLocation(){
 return <section className="booking-location" aria-label="Как нас найти">
  <h2>Как нас найти</h2>
  <div className="booking-studio-logo" role="img" aria-label="AVTOLAB77 — студия премиум автостайлинга"><span className="logo-art"/></div>
  <div className="booking-location-item"><MapPin aria-hidden="true"/><address><a href={studio.mapUrl} target="_blank" rel="noopener noreferrer">{studio.address}</a></address></div>
  <div className="booking-location-item"><Clock aria-hidden="true"/><div><span className="booking-location-label">Работаем</span><p>{studio.hours}</p></div></div>
  <div className="booking-map">
   <img className="booking-map-image" src="/assets/studio-map-v61.webp" width={1315} height={1196} loading="lazy" decoding="async" alt="Схема расположения Автолаб77 рядом с метро Шелепиха и Москва-Сити"/>
   <a className="booking-map-link" href={studio.mapUrl} target="_blank" rel="noopener noreferrer" aria-label="Открыть расположение AVTOLAB77 в Яндекс Картах"></a>
  </div>
  <a className="booking-route" href={studioRoute} target="_blank" rel="noopener noreferrer"><Navigation size={19} aria-hidden="true"/>Построить маршрут</a>
 </section>;
}
