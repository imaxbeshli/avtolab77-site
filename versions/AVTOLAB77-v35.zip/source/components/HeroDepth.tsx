/** Atmosphere on the far side of the cars, aligned to the source photograph. */
export function RearAtmosphere(){return <svg className="hero-rear-fog" viewBox="0 0 1536 1024" aria-hidden="true">
 <defs>
  <filter id="rear-clouds" x="-20%" y="-30%" width="140%" height="160%"><feTurbulence type="fractalNoise" baseFrequency=".009 .022" numOctaves="3" seed="17"/><feColorMatrix type="matrix" values="0 0 0 0 .62 0 0 0 0 .66 0 0 0 0 .70 1.6 0 0 0 -.55"/><feGaussianBlur stdDeviation="3"/></filter>
  <linearGradient id="rear-fog-band" x1="0" y1="360" x2="0" y2="710" gradientUnits="userSpaceOnUse"><stop stopColor="white" stopOpacity="0"/><stop offset=".4" stopColor="white"/><stop offset=".78" stopColor="white"/><stop offset="1" stopColor="white" stopOpacity="0"/></linearGradient>
  <mask id="rear-fog-occlusion"><rect width="1536" height="1024" fill="url(#rear-fog-band)"/><path fill="black" d="M153 553L201 486Q244 457 346 460L464 466Q526 480 561 530L607 532L662 546Q708 556 711 613L712 690L680 718L161 724L150 640Z M837 570L857 546L972 526L1038 468Q1061 450 1167 454L1280 465Q1338 472 1357 503L1397 550L1397 660L1380 718L849 725L836 655Z"/></mask>
 </defs>
 <g mask="url(#rear-fog-occlusion)"><g className="rear-fog-drift"><rect x="-100" y="340" width="1736" height="410" filter="url(#rear-clouds)"/></g></g>
 </svg>}
export function Studio77(){return <svg className="hero-seventy-seven" viewBox="0 0 600 300" aria-hidden="true"><g><path d="M58 20H285L135 280H69L190 76H27Z M322 20H549L399 280H333L454 76H291Z"/></g></svg>}
