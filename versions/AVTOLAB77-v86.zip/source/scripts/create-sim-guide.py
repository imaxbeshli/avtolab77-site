"""Build the owner-approved, phone-friendly SIM memo with embedded Cyrillic fonts.
Requires ReportLab. No network or external assets are needed to read the PDF.
"""
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.lib.colors import HexColor

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'public/downloads/avtolab77-sim-cards-v1.pdf'
FONT = Path('/usr/share/fonts/truetype/dejavu')
pdfmetrics.registerFont(TTFont('Guide', str(FONT / 'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('GuideBold', str(FONT / 'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFontFamily('Guide', normal='Guide', bold='GuideBold', italic='Guide', boldItalic='GuideBold')
# Narrow portrait pages are readable at fit-to-width on mobile; printable as well.
W, H, M = 420, 650, 28
INK, RED, MUTED = '#202126', '#842337', '#64646b'
styles = {
 'body': ParagraphStyle('body', fontName='Guide', fontSize=14, leading=20, textColor=HexColor(INK)),
 'title': ParagraphStyle('title', fontName='GuideBold', fontSize=26, leading=32, textColor=HexColor(INK)),
 'heading': ParagraphStyle('heading', fontName='GuideBold', fontSize=18, leading=24, textColor=HexColor(RED)),
 'small': ParagraphStyle('small', fontName='Guide', fontSize=11, leading=16, textColor=HexColor(MUTED)),
}
DEST.parent.mkdir(parents=True, exist_ok=True)
c = canvas.Canvas(str(DEST), pagesize=(W,H), pageCompression=1, invariant=1)
c.setTitle('SIM-карты для автомобиля')
c.setAuthor('AVTOLAB77')
c.setSubject('Инструкция для сотрудника салона связи: выбор и активация SIM-карт для TCAM')
y = 0
def page(n, label):
 global y
 c.setFillColor(HexColor(RED));c.setFont('GuideBold',12);c.drawString(M,H-32,'AVTOLAB77')
 c.setFillColor(HexColor(MUTED));c.setFont('Guide',9);c.drawRightString(W-M,H-32,label)
 c.setStrokeColor(HexColor('#ded8da'));c.line(M,H-45,W-M,H-45)
 c.setFont('Guide',9);c.drawString(M,22,'SIM-карты для автомобиля');c.drawRightString(W-M,22,f'{n} / 3')
 y=H-65
def p(text,style='body',gap=12):
 global y
 para=Paragraph(text,styles[style]);_,h=para.wrap(W-2*M,H)
 assert y-h>=45, f'Page overflow: {text[:60]}'
 para.drawOn(c,M,y-h);y-=h+gap

page(1,'01 · Тарифы')
p('SIM-карты<br/>для автомобиля','title',8)
p('Инструкция для сотрудника салона связи','small',18)
p('SIM-карты будут установлены в телематический модуль (TCAM) автомобиля, а не в смартфон.')
p('Для работы TCAM необходимы <b>две SIM-карты</b>.',gap=20)
p('1. МегаФон — основной','heading',8)
p('Интернет — <b>от 150 ГБ в месяц</b>.',gap=8)
p('Тариф должен поддерживать использование SIM-карты в модемах и роутерах.',gap=8)
p('Необходим полноценный пакет интернет-трафика, а не безлимит только для отдельных приложений.',gap=20)
p('2. Билайн — дополнительный','heading',8)
p('Интернет — <b>от 50 ГБ в месяц</b>.',gap=8)
p('Тариф должен поддерживать использование SIM-карты в модемах и роутерах.',gap=8)
p('Необходим полноценный пакет интернет-трафика.',gap=0)
c.showPage()

page(2,'02 · Подготовка')
p('Активация SIM-карт','title',12)
p('SIM-карты необходимо активировать.',gap=18)
for i,text in enumerate([
 'Установить SIM-карту в телефон.',
 'Проверить работу мобильного интернета и доступный объём трафика в гигабайтах.',
 'Проверить получение SMS-сообщений.',
 'Установить официальные приложения МегаФон и Билайн на личный смартфон владельца.',
 'Привязать приобретённые номера к приложениям с подтверждением через SMS.',
 'Проверить отображение баланса, тарифа и остатка интернет-трафика.',
],1):p(f'<b>{i}.</b> {text}',gap=12)
p('SIM-карты будут находиться внутри автомобиля и станут труднодоступны. Поэтому приложения операторов должны быть настроены заранее, чтобы владелец мог контролировать баланс, расход интернета и своевременно пополнять счёт.',gap=0)
c.showPage()

page(3,'03 · Важно')
p('Важно','title',20)
p('<b>Не используйте SIM-карты от знакомых, посредников и тарифы с сомнительным «безлимитом».</b>',gap=18)
p('Даже если интернет работает в телефоне, это не гарантирует его работу в автомобиле.',gap=18)
p('«Безлимит» для социальных сетей, мессенджеров и видеосервисов не заменяет полноценный пакет интернет-трафика, необходимый для подключения автомобиля к серверам.',gap=18)
p('Неподходящие SIM-карты могут вызвать сбои телематики и потерю связи с серверами. В отдельных случаях для восстановления работы TCAM может потребоваться дополнительная диагностика и перепрошивка блока.',gap=22)
p('<b>Данная инструкция поможет избежать лишних расходов и обращений к специалисту.</b>')
c.save()
print(f'{DEST}: {DEST.stat().st_size / 1024:.0f} KB, 3 pages')
