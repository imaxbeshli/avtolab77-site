'use client';
import {useEffect,useState} from 'react';
let introPlayed=false;
export function Motion(){
 const [intro,setIntro]=useState(()=>!introPlayed);
 const [playing,setPlaying]=useState(false);
 useEffect(()=>{
  const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const play=intro;introPlayed=true;
  const animations:Animation[]=[];
  const timers:ReturnType<typeof setTimeout>[]=[];
  let disposed=false,started=false;
  const nodes=document.querySelectorAll('.home-scene .section-head,.direction,.service-card,.digital-grid a,.project-card,.fact,.consult');
  const groups=new Map<Element,number>();const order=new Map<Element,number>();
  const observer=!reduced&&'IntersectionObserver' in window?new IntersectionObserver(entries=>entries.forEach(e=>{
   if(!e.isIntersecting)return;
   const el=e.target as HTMLElement;observer?.unobserve(el);el.classList.remove('motion-pending');el.dataset.revealState='running';
   const delay=Math.min(order.get(el)||0,5)*120;
   const animation=el.animate([{opacity:0,translate:'0 18px'},{opacity:1,translate:'0 0'}],{duration:850,delay,easing:'cubic-bezier(.22,.7,.25,1)',fill:'backwards'});
   animations.push(animation);animation.onfinish=()=>{el.classList.add('revealed');el.dataset.revealState='complete'};
   el.querySelectorAll('.service-line-icon,.direction-content>svg').forEach(icon=>animations.push(icon.animate([{opacity:0,scale:'.94'},{opacity:1,scale:'1'}],{duration:600,delay:delay+120,fill:'backwards',easing:'ease-out'})));
  }),{threshold:.12,rootMargin:'0px 0px -30px 0px'}):null;
  if(observer)nodes.forEach(el=>{const group=el.closest('section')||el.parentElement!;const index=groups.get(group)||0;groups.set(group,index+1);order.set(el,index);el.classList.add('reveal','motion-pending');el.setAttribute('data-reveal-state','pending')});
  const observe=()=>nodes.forEach(el=>observer?.observe(el));
  const start=()=>{
   if(started||disposed||document.visibilityState==='hidden')return;started=true;
   if(!play){setIntro(false);observe();return}
   document.body.classList.add('intro-running');setPlaying(true);
   const length=reduced?1500:3600;
   if(!reduced)timers.push(setTimeout(()=>{
    const hero=document.querySelector('.hero-image');const title=document.querySelector('.hero-content');
    if(hero)animations.push(hero.animate([{scale:'.94',opacity:.45},{scale:'1',opacity:1}],{duration:1800,easing:'cubic-bezier(.2,.65,.3,1)'}));
    if(title)animations.push(title.animate([{opacity:0,translate:'0 8px'},{opacity:1,translate:'0 0'}],{duration:900,delay:200,fill:'backwards'}));
   },2900));
   timers.push(setTimeout(()=>{setIntro(false);document.body.classList.remove('intro-running');observe()},length));
  };
  if(play)document.body.classList.add('intro-running');
  document.addEventListener('visibilitychange',start);
  // Wait for the logo itself, not just for the JavaScript bundle.
  const logo=document.querySelector('.intro .logo-art');
  const url=logo?getComputedStyle(logo).backgroundImage.match(/^url\(["']?(.*?)["']?\)$/)?.[1]:null;
  const asset=new Image();if(url)asset.src=url;
  Promise.race([url?asset.decode().catch(()=>{}):Promise.resolve(),new Promise(resolve=>timers.push(setTimeout(resolve,1800)))]).then(start);
  return()=>{disposed=true;timers.forEach(clearTimeout);document.removeEventListener('visibilitychange',start);observer?.disconnect();animations.forEach(a=>a.cancel());document.body.classList.remove('intro-running');nodes.forEach(el=>{el.classList.remove('reveal','revealed','motion-pending');el.removeAttribute('data-reveal-state')})};
 },[]);
 return intro?<div className={'intro'+(playing?' is-playing':'')} aria-label="AVTOLAB77"><div className="intro-brand"><div className="logo-art"/><span className="intro-rule"/></div></div>:null;
}
export function useRail(){useEffect(()=>{const rail=document.querySelector<HTMLElement>('.service-rail');if(!rail)return;let x=0,start=0,down=false,moved=false;const wheel=(e:WheelEvent)=>{if(e.ctrlKey||rail.scrollWidth<=rail.clientWidth)return;const delta=Math.abs(e.deltaX)>Math.abs(e.deltaY)?e.deltaX:e.deltaY;const end=rail.scrollWidth-rail.clientWidth;if((delta<0&&rail.scrollLeft<=0)||(delta>0&&rail.scrollLeft>=end-1))return;e.preventDefault();rail.scrollLeft+=delta};const press=(e:PointerEvent)=>{if(e.pointerType!=='mouse'||e.button!==0)return;down=true;moved=false;x=e.clientX;start=rail.scrollLeft};const move=(e:PointerEvent)=>{if(!down)return;if(Math.abs(e.clientX-x)>5){moved=true;rail.scrollLeft=start+x-e.clientX;e.preventDefault()}};const up=()=>{down=false};const click=(e:MouseEvent)=>{if(moved){e.preventDefault();e.stopPropagation();moved=false}};const drag=(e:DragEvent)=>e.preventDefault();rail.addEventListener('wheel',wheel,{passive:false});rail.addEventListener('pointerdown',press);window.addEventListener('pointermove',move);window.addEventListener('pointerup',up);rail.addEventListener('click',click,true);rail.addEventListener('dragstart',drag);return()=>{rail.removeEventListener('wheel',wheel);rail.removeEventListener('pointerdown',press);window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',up);rail.removeEventListener('click',click,true);rail.removeEventListener('dragstart',drag)}},[])}
