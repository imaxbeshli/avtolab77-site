# AVTOLAB77 — визуальная версия сайта

Адаптивный сайт на Next.js 16, React 19, TypeScript. Дизайн по утверждённому референсу: тёмная студия, автомобильный hero, два направления, услуги, выбор моделей, проекты, студия и консультация.

## Посмотреть без установки

Открыть `/workspace/previews/AVTOLAB77.html` в современном браузере. В одном файле встроены все изображения, шрифты и React-интерфейс. Работают внутренние страницы, карусель автомобилей, FAQ и демонстрационная форма. Доступ к интернету не требуется. Контакты и отправка заявок ожидают наполнения.

## Разработка

Node.js 24, npm 11. Из `/workspace/avtolab77-site/avtolab77-new`:

```sh
npm ci
npm run dev
```

Dev-сервер слушает порт 3000. `npm run build` создаёт статический сайт в `out/`. Его можно разместить на статическом хостинге. Для локальной проверки сборки: `python3 -m http.server 3001 --directory out`. `npm start` для режима static export не используется.

## Проверки

- `npm run typecheck`
- `npm run build`
- `node scripts/export-preview.mjs` — пересобрать автономный HTML
- `python3 -m http.server 4173 --directory /workspace/previews`
- `node scripts/check-preview.cjs` — Chromium; проверка 320/360/390/430/768/1024/1280/1440/1920, навигации, формы, ESC, выбора моделей и проектов, скриншоты

В проверенной версии проходят сборка и тесты интерфейса. Горизонтальный overflow отсутствует на всех девяти размерах. JS-ошибок в проверенных сценариях нет. Файловая навигация запрещена политикой браузера облачной среды, поэтому автономный документ проверен через локальный HTTP; сам документ не использует сетевые зависимости.

## Контент и изображения

- `content/services.ts` — 12 услуг.
- `content/site.ts` — модели, демонстрационные проекты, страницы.
- `public/assets/hero.webp`, `details.webp`, `vehicles-v2.webp`, `glass-backdrop.webp` — сгенерированные визуальные концепты; не фотографии реальных работ или подтверждённых моделей.
- `public/assets/fonts` — локальные Manrope и Montserrat с кириллицей, лицензии OFL приложены.
- `components/Site.tsx` — компоненты главной, страниц, навигации и формы.
- `app/globals.css` — стили, шрифты и адаптивность.

Изображения обозначены как демонстрационные. Совместимость всех моделей требует проверки. Контакты, цены и реальные кейсы не выдуманы. Социальные иконки ведут на страницу контактов до появления подтверждённых адресов. Индексация закрыта через metadata robots. Форма проверяет введённые поля, но не отправляет и не сохраняет данные.

## Перед публичным запуском

Наполнить подтверждёнными материалами и контактами, подключить CMS и реальную обработку заявок с серверной валидацией, утвердить юридические документы и таблицу совместимости, настроить SEO/домен/редиректы. Production-публикация не выполнялась.

## Согласованные визуальные правки — версия 2

- Убраны пункты верхней навигации, подзаголовок hero и кнопка выбора услуг.
- Заголовок секции — «Услуги студии»; удалены ссылки «Все услуги» и «Смотреть все работы».
- Карусель содержит ZEEKR 9X, ZEEKR 8X и Lynk & Co 900, с отдельными сгенерированными визуализациями.
- Иконки цифровых услуг контурные, без красного свечения. Строка совместимости и дополнительная CTA под каруселью убраны.
- Карточки проектов содержат только изображения. Доступные названия ссылок сохранены через aria-label.
- Нижняя часть страницы использует тёмный каменный фон и полупрозрачные поверхности с backdrop blur. Проверены desktop и mobile.
- Текущий текстовый логотип оставлен до получения нового файла от владельца.
- Новый файл для просмотра: `/workspace/previews/AVTOLAB77-v2.html`.

## Версия 3 — логотип, автомобили без фона и единый стиль

- Логотип подготовлен из присланного изображения; локальный ассет `brand-logo.webp`.
- `vehicles-cutout.webp` содержит автомобили с прозрачным фоном: без пола и отражений.
- Карусель поддерживает колёсико мыши/трекпада, перетаскивание мышью, горизонтальный жест пальцем, кнопки и клавиатуру. Вертикальная прокрутка на touch сохранена.
- Убраны декоративные стрелки на карточках услуг и направлений, ссылка «Больше о студии» и отдельный подвал.
- Обновлён текст о студии. К трём фактам добавлен предоставленный владельцем тезис «5 лет гарантии на любое эксплуатационное повреждение».
- Главная завершается блоком консультации. Плитки и поверхности используют общие графитовые цвета, рамки и радиусы.
- Файл просмотра: `/workspace/previews/AVTOLAB77-v3.html`. Изображения автомобилей остаются визуализациями; форма работает в демонстрационном режиме.
- Проверки: сборка/TypeScript, 9 размеров экрана, wheel, mouse drag, keyboard, CDP touch swipe и вертикальная touch-прокрутка, форма и переходы — успешно.

## Версия 4 — композиция по исходному референсу

- Новый `studio-panorama.webp`: автомобиль целиком, больше студийного пространства и красные световые линии. Изображение плавно растворяется в общем фоне страницы.
- `styles/studio.css` объединяет оформление первого экрана, фотографий, карточек, автомобильной сцены и блока студии. Нижняя часть использует мягкую световую полосу и сдержанный каменный фон.
- Поверх фотографии подготовлен отдельный SVG-слой свечения ламп (`hero-lamps`, `--lamp-intensity`) для последующей анимации; основное освещение остаётся частью изображения.
- `components/VehicleSelector.tsx`: циклическая карусель с пятью физическими позициями и незаметной перестановкой после перехода. Крайняя модель уходит за край, не пересекает центр при возврате. Поддерживается reduced motion.
- Проверены полный цикл вперёд и назад, wheel, drag, keyboard, touch, вертикальная прокрутка, навигация и форма. Девять ширин 320–1920 px без переполнения; TypeScript и production build успешны.
- Автономный просмотр: `/workspace/previews/AVTOLAB77-v4.html`. Все изображения, шрифты и интерактивность встроены. Форма остаётся демонстрационной.

## Version 6 — motion and smoked glass

Intro now replays on a full document load, not on internal navigation; sessionStorage no longer suppresses it. IntersectionObserver reveals section headings, direction cards, services, digital tiles, projects and studio facts. Hero fog and red lamps animate independently using CSS. All motion respects prefers-reduced-motion. Centered typography, glass overlays and a continuous studio/consultation backdrop are implemented in styles/studio.css.

Validation: npm run typecheck, npm run build, scripts/check-motion.cjs and scripts/check-v5.cjs. The latter includes desktop/mobile screenshots and overflow checks. Public preview is deployed from the gh-pages branch of imaxbeshli/avtolab77-site. Publish by exporting the standalone HTML and updating index.html in the existing gh-pages checkout (/tmp/avtolab77-pages). Do not replace the branch history. Latest revision: a0f7ef1. Site: https://imaxbeshli.github.io/avtolab77-site/ . GitHub Actions must complete before describing a change as published.

## Version 7 — text centering correction

Restored bold hero typography (weight 800). Removed inherited maximum widths and left-anchored layout from fact captions; reset card text widths so equal left/right offsets center actual text containers. Verified 320/360/390/650/768/1024/1440/1920 px in scripts/check-centering.cjs: no horizontal overflow, centered heading/paragraph alignment, matching caption/headline and card/title centers within 1 px. Deployment commit: 9d2bfcc on gh-pages.

## Version backup workflow

The user requires recoverable versions for each future published visual revision. Keep immutable ZIPs under gh-pages/versions, each containing standalone index.html, VERSION.json with its SHA-256 and source commit, and Russian viewing/rollback instructions. Include a source/ snapshot for each new revision; omit dependencies, build caches and credentials. Preserve all earlier ZIPs and version HTMLs. Update versions/index.html and manifest.json, verify ZIP integrity and matching index hashes, then publish and confirm Pages completion. Never overwrite a historical version or force-push to roll back. Restore a selected index.html via a new commit, verify in browser, and wait for deployment. Historical v5–v7 packages contain standalone sites only; v8 includes source. Public version catalog: https://imaxbeshli.github.io/avtolab77-site/versions/ .

## Version 9 — two-car scene and primary section hierarchy

Generated a shared studio scene with Rolls-Royce Cullinan on the left and ZEEKR 9X on the right (studio-duo.webp). Updated SVG light positions to both walls. Desktop and mobile preserve both complete vehicles. Renamed the services heading to «Автостайлинг и детейлинг» and enlarged it and «Русификация и цифровые решения» equally. Verified centering/overflow at eight widths, desktop/mobile hero screenshots and matching section font sizes. Previous archives remain immutable.

## Version 10 — reference-style ground and studio

The hero and direction cards no longer overlap. Added carousel-asphalt.webp as a shared floor, attached model-matched reflections and contact light to each moving carousel slot, and removed translucent side car bodies. Replaced the third/fourth project visuals with Porsche/Audi front-corner closeups, preserving BMW/Mercedes. Restored a compact studio row with subtle upper light, stone edges and red fact dividers; consultation remains the last block. Checked hero/card clearance at 6 widths, reflections and wheel/keyboard transitions, centering at 8 widths, and production build.

## Version 11 — feathered floor and independent animations

Viewport-wide asphalt with a radial feather mask and slight defocus replaces hard rectangular floor edges. Distant logo is a separate subdued screen-blended layer, ready for later neon animation. Replaced digital direction image and windshield protection image; reordered styling services to ppf/tinting/polishing/glass/pdr/soundproofing. Scroll reveal now uses Web Animations with per-section stagger, independent of hover transitions. All six digital cards have stable bounds during hover. Verified progressive opacity in actual intermediate frames, eight viewport widths, carousel reflection continuity and production build. Screenshot evidence: reveal-v11-start.png / reveal-v11-end.png in local previews. Reduced motion remains supported.

## Version 12 — reliable entrance and discrete selection

Removed distant scene logo, softened/lowered hero typography, replaced the studio introduction with four centered facts (17 years, 10,000+ cars, premium materials, 5-year warranty), and centered a narrower consultation panel with its button below. Intro exists at first render, waits for the logo decode/visible document, shows and fades the logo, then reveals the hero with a gentle camera scale. Reduced motion shows a short static logo. Full reload replays the entrance; internal navigation does not. Car gestures track intent only, with no visual movement while held; release/click/wheel triggers one 720ms transition, repeated input during motion is ignored. Checks: build, check-v12, check-centering, check-v5, progressive reveal and all six hover bounds, native mobile touch swipe. Prior versions remain immutable.

## Version 13 — slower logo entrance

The logo now fades in for approximately 1 second, stays readable for 1 second and fades out for 1 second. The black curtain dissolves over 0.7 seconds from 2.9s; the camera entry lasts 1.8s. Verified real opacity at 450/1400/2500ms, camera animation and scroll release in check-intro-timing.cjs. Other site design is unchanged. scripts/archive-version.py now provides the repeatable, non-overwriting archive workflow.

## Version 14 — continuous entrance and WebGL atmosphere

Replaced conflicting CSS/reduced-motion entrance branches with one frame-controlled timeline: logo fade in 1.2s, hold .9s, fade out 1.2s, curtain 1.1s and gentle scene entry 2.2s. Logo decode and fonts finish before the timeline starts; bounded per-frame progress prevents loading stalls from skipping the fade. Reduced motion keeps opacity transitions and removes camera movement. Scroll elements and icons reveal sequentially at 120ms intervals without hover transforms.

Three.js renders procedural moving fog and subtle red reflected light on a transparent shader plane over the photographic hero. It starts after the entrance, renders at capped resolution/rate and pauses offscreen; CSS atmosphere remains as fallback. Cars are still photographs, not 3D models. Verified normal/reduced intro intermediate opacity, changing WebGL frames, reveal timing, eight responsive widths/centering, hover stability, wheel interaction, console and production build (30 static routes). Control recording: motion-v14.webm.

## Version 15 — seamless entrance and grounded atmosphere

The curtain now waits for all opening animations to finish. WebGL is prepared behind the logo and starts moving after entry; stable scrollbar gutters prevent width changes on scroll unlock. Browser sampling verifies hero bounds before/after curtain removal differ by less than 0.1px. Logo retains frame-progress protection; the opening uses coordinated compositor animations.

Fog is more visible around wheels and follows a continuous 32-second circular noise path. Three aligned pairs of wall strips breathe smoothly over eight seconds without flashes. Carousel cars have depth offsets, selected lighting, contact shadows and model-matched mirrored reflections. Section/carousel reveals move vertically upward; icons also rise rather than scale. Compact consultation reads “Обсудим ваш автомобиль” on one line with the booking button beneath it.

Validation: production build (30 pages), check-v14 (normal/reduced intro and changing WebGL frames), check-v15 (handoff bounds, lights, carousel and CTA at 320/390/768/1440), check-centering (8 widths), check-v11 (stable hover and sequential reveal). Cars remain photographic assets. Prior version archives are preserved.

## Version 16 — upward row reveal and visible scene motion

Removed per-column reveal delays: each intersecting row rises together with zero delay and 24px vertical movement over 1.1s. This fixes the perceived left-to-right sweep. Card artwork now zooms only 2.5% over 1.4s within clipped bounds; line icons do not enlarge. Increased the visible two-layer drifting mist and GPU fog motion, and replaced subtle breathing with a seven-second varied lamp pulse. Consultation heading matches section Montserrat weight 750 and tracking.

Validation: check-v16 asserts zero stagger/vertical keyframes, actual intermediate zoom values and unchanged card bounds, moving mist transforms and lamp opacity, matching heading family/weight. Production build and eight-width centering check passed. check-v16 supersedes older stagger assertions in check-v14/check-v11. Reduced-motion preferences retain static atmosphere. Prior archives remain immutable.

## Version 17 — geometric Three.js studio

Replaced the first-screen photographic overlay renderer with a perspective 3D scene. components/studio3d.ts builds two original procedural SUV models (326 scene meshes including detailed wheels, glazing, chrome, grilles and lamps), studio walls, six emissive wall strips, real point/directional lighting, shadow maps and a reflected wet floor. Vehicle models are simplified interpretations, not licensed/exact Rolls-Royce or ZEEKR production models. They do not use vehicle photographs or billboard geometry.

A depth-texture postprocess raymarches animated 3D density inside a low fog volume. Integration stops at visible scene geometry. Floor reflections use a second camera with rough surface distortion. Lamp intensity animates actual scene lights and the fog scattering tint. Photographic/CSS atmosphere is disabled when the real scene is available, retained as a WebGL failure fallback. Offscreen rendering pauses, shadow maps cache static geometry, and render resolution is capped at 1200px width. Mobile camera framing adapts to the viewport. Original photographic v16 remains archived for comparison.

Validation: production build (30 routes), check-v17 verifies mesh count, disabled old effects, changing rendered pixels and physical light intensity, browser errors and responsive canvas sizes. Model fidelity remains visibly lower than the photographic reference; this release establishes an actual editable 3D studio, not a claim of photorealistic vehicle reproduction.

## Version 18 — photographic baseline and gentle hover

Restored Atmosphere.tsx and studio.css from the v16 archive; the experimental v17 3D studio is not imported into this release. Photograph cards zoom internally to 1.03 over 1.8 seconds, and outline digital icons to 1.05 over 1.6 seconds. Both directions use the same easing and duration, with clipped/fixed card bounds. Mouse-only hover prevents sticky enlargement on touch; reduced motion disables the zoom. check-hover-v18 samples intermediate scale values on hover and exit for direction, service, project and digital cards and asserts unchanged card bounds. Production build passed.

## Version 19 — calmer selection, unified buttons and hero composition

Carousel transitions now last 1500ms with a shared ease-in/out curve for geometry, illumination, reflections and labels. Labels use consistent metrics and their highlight follows the incoming center position. Child transitions are disabled at the cyclic slot reset so a newly assigned sprite does not replay another car's lighting transition. Click/wheel/gesture intent handling remains discrete.

Header and consultation booking buttons share a translucent red background, 10px corners and restrained hover. Hero typography uses section Montserrat 750 weight, slightly larger desktop sizing and a lower position. Mobile positioning is independent and the scene moves upward to close the text/car gap. CSS fog cycles span 64/82 seconds with smaller movement; shader noise traverses its path over 90 seconds. Wall lights have occasional soft glints during a 22-second cycle.

Validation: production build, check-v19 at 320/390/768/1440; identical button styling; sampled carousel geometry and label opacity remain continuous across reset; keyboard and wheel transitions; browser errors. Archive originals are stored only in site-archives, keeping Pages lightweight.

## Version 20 — light looping fog and periodic wall glow

Restored perceptible atmosphere without the dense/fast v16 look. CSS fog follows continuous 32/43-second loops with staggered phases and lower opacity; shader flow has a 48-second cycle with reduced density. Wall strips and their aura rise/fall smoothly every 12 seconds, with no long inactive interval. v19 layout, buttons, hero type and carousel are preserved. check-atmosphere-v20 verifies real drift/light changes, matching cycle boundaries, reduced-motion CSS and no shader/browser errors; production build passed. publish-archived.py now prepares lightweight releases from the separately stored archive and pins the previous version correctly.

## Version 21 — unified photographic service sections

Replaced the two duplicate introductory direction cards with two complete service compositions. Auto styling has a new front-facing BMW studio image, centered title and all six existing service cards inside one frame. Digital services retain the three-model selector and six functional cards on a shared wet studio floor. Heading links retain access to both category pages. Newly generated studio assets are local WebP files and embedded in the standalone release.

Retained v20 hero atmosphere, intro, smooth carousel, upward scroll reveals and gentle internal hover zoom. Mobile styling tiles scroll horizontally; digital services wrap into two columns. The digital floor is framed separately on narrow screens to align with the vehicles instead of falling behind the icon grid.

Validation: 30-route production build; check-v21 at 320, 390, 768 and 1440 pixels checks retained service links/counts, no horizontal page overflow, carousel completion, stable card bounds on hover, detail navigation and browser errors. Desktop and mobile panel screenshots reviewed. Standalone release and complete source are archived separately from the lightweight Pages deployment; previous versions remain unchanged.

## Version 22 — continuous studio background and expandable service rail

Removed the large section frames and independent digital/studio background panels. A single generated graphite-floor image spans the homepage; the hero and styling photograph have soft edge masks, while projects, facts and the booking area continue on the same surface. BMW framing adapts to small screens. Service and project tiles retain their images with quieter outlines; digital icons have lighter surfaces.

Photographic hover now scales the actual `::before` artwork inside its stationary clipping box by 5.5% over 1.35 seconds, in both directions. This keeps labels and borders still and makes the slow approach perceptible. Reduced-motion preferences disable this zoom. Intro, upward reveals, 1500ms vehicle transitions, light fog and periodic wall glow remain.

Services are grouped explicitly by direction rather than split at a fixed array index. Home styling renders the complete group in a fixed-width horizontal rail, with a partial next tile and edge fades. Mouse wheel and keyboard scrolling use a subpixel accumulator to avoid rounding stalls near the end. Dragging suppresses link activation, native touch handles swiping, and wheel events at the boundary continue scrolling the page. Projects use the same rail behavior. No additional demo services were published.

Validation: production build (30 static routes); `check-v22.cjs` checks 320/390/768/1440/1920 widths, transparent borderless sections, real intermediate hover scales and stable tile bounds, appended future cards, wheel/drag/keyboard/edge release, carousel and service navigation. `check-v22-touch.cjs` checks native touch input, no accidental navigation, moving fog/lamp opacity, vertical icon reveal, reduced motion and mobile header. Desktop and mobile screenshots reviewed. The separate version archive includes the standalone site, source and generated assets; v21 remains available for rollback.

## Version 23 — restore the previous facts block

Restored the v21 facts block's glass/rock background, red vertical dividers and original internal spacing. Soft alpha masks on the background and light layers join it to the continuous v22 floor without a straight top edge. The current booking area, other sections and interactions remain unchanged.

Validation: production build (30 routes); browser comparison against the archived v21 at 1440 and 390 pixels confirms matching facts spacing/divider styling and no page overflow. Reviewed desktop/mobile screenshots of the restored block and its transition. v22 is retained in the version archive.

## Version 24 — restored CTA frame, frosted cards and uninterrupted page scrolling

Restored the consultation frame with a thin red border, rounded corners and translucent red-tinted background. Digital service tiles now use a lighter translucent gradient with 14px backdrop blur, keeping text/icons fully opaque. The continuous background and v23 facts backdrop remain.

Removed the vehicle selector's wheel listener entirely. Wheel and vertical trackpad gestures scroll the page; model changes retain their 1500ms animation on neighboring-car clicks and horizontal mouse/touch gestures. Native vertical touch panning and pinch zoom are allowed. Arrow keys remain available for keyboard users. The independent service rail keeps its wheel behavior.

All four facts headings now share Montserrat, weight 700, line height, tracking and one column-relative font-size rule. The common responsive size fits the two-line premium-materials label instead of giving that label a separate smaller font. Narrow-screen inner padding gives the titles more space.

Validation: production build; check-v24 covers wheel pass-through without model changes, intermediate click animation, drag/release selection, service-rail scrolling, matching/fitting typography at 320/390/768/1440, CTA dialog, native vertical touch scrolling and horizontal model swipes. Desktop/mobile visual review of glass cards and restored consultation frame. Earlier releases remain archived.

## Version 25 — interior scene, lighter headings and transparent header

Removed the styling subtitle. Digital services now follow the same visual order as styling: centered heading, a large generated luxury-cabin photograph with Russian infotainment labels, then the existing model selector and six service tiles. The interior uses soft edge masks against the continuous floor and joins the existing upward reveal animation. The WebP asset is local and embedded in the standalone release.

Hero, section headings (including projects), and consultation now share Manrope 500, consistent tracking and line-height; all section headings share a responsive size. Facts and card-label typography are preserved. The sticky header uses a translucent dark fill with backdrop blur and no bottom border. An SVG color-matrix filter makes the existing logo's dark background transparent at display time without replacing or redrawing the logo asset.

Validation: production build (30 static routes); browser review at 320/390/768/1440 checks no overflow, image/selector/tile order, removed subtitle, consistent section typography and sticky borderless header. Desktop/mobile screenshots reviewed; the header logo was additionally checked over the bright hero reflections. Existing check-v24 passes for wheel/vertical touch page scrolling, click/drag/swipe model selection, service rail, facts typography and consultation dialog. v24 remains archived for rollback.

## Version 26 — integrated BMW scroll transformation

Integrated the approved photographic BMW transformation into the styling section. Native scrolling drives the glossy-to-matte body reveal followed by headlights; the scene releases naturally into the service rail. Only the normal section heading remains: no demo instructions, stage labels, progress indicators or replay controls. Embedded scene images keep the published HTML self-contained. Reduced-motion support, image-failure fallback and listener cleanup are included.

Validation: check-v26 passes all four stages at 320/390/768/1440 widths, sticky positioning and release, reverse scroll, detail/home remount, reduced motion, no overflow and no external asset requests. Desktop/mobile screenshots reviewed. v25 retained for rollback.

## Version 27 — mobile scene flow and opening-screen separation

The opening hero now fills at least one viewport so the styling heading appears only after scrolling. The BMW roof sits closer below its heading. On narrow screens and coarse touch devices, the whole BMW scene stays in normal document flow: no sticky hold or three-screen spacer. Gloss/matte/headlight progress follows the scene entering the viewport, completing while the car is visible. The compact scene joins directly to service cards. Desktop keeps the approved pinned progression and timing. Mobile hero composition is vertically balanced within the full opening screen.

Validation: production build; check-v27 verifies 320/390 phone portrait, 844 phone landscape, 768 touch tablet, 1440/1920 desktop. Checks include native touch movement of scene with page, all desktop stages, hidden second heading on initial viewport, compact heading/rail spacing, no overflow or browser errors. Desktop and mobile screenshots reviewed. v26 retained for rollback.

## Version 28 — compact mobile hero and blended BMW surroundings

The mobile/coarse-touch opening now follows its photographic composition instead of viewport height: a 48px heading inset, both cars fully visible, wet-floor reflections and a short fade into styling. Desktop hero geometry stays unchanged. BMW uses intersecting horizontal/vertical feather masks that preserve the body, a subtle lower-floor color blend, and a low-opacity crop of its wet floor extending behind the start of the service rail. The heading has no separate panel. Animation timing, sharp car layers and normal mobile document scrolling are preserved.

Validation: production build; check-v28 checks compact opening geometry at 320/390, landscape phone and touch tablet flow, native touch movement, no overflow, and the four transformation stages on 1440/1920 desktop. Mobile/desktop screenshots reviewed. v27 remains archived for rollback.

## Version 29 — scroll-driven infotainment translation

Replaced the static interior with an edited photograph that removes the rear-view mirror/overhead console and baked-in text while preserving dashboard, screen icons and car graphic. A single SVG camera moves the photograph and separate screen typography together, smoothly zooming 10% around the tablet. Native scroll drives staggered crossfades from 导航 / 空调 / 设置 to Навигация / Климат / Настройки, reversing on upward scroll. No pinning, scroll interception, instructions or progress controls. Mobile framing keeps the tablet readable and the surrounding cabin visible. Reduced motion disables camera zoom and directly follows scroll state. Chinese glyphs are embedded from a six-character Noto Sans CJK subset with its license, so standalone rendering does not depend on device fonts.

Validation: production build (30 static routes); check-v29 verifies sequential fades, final/reverse states, camera scale, page scrolling, reduced motion, local embedded assets/fonts, remount and zero browser errors/overflow at 320/390/768/1440 widths. Mobile/desktop screenshots reviewed. v28 retained for rollback.

## Version 30 — reforming screen text and clean model transition

Removed overlaid Chinese/Russian text layers. Each row now has one visible sequence of two glyph runs: each Chinese glyph briefly compresses, reforms into its Russian word segment and expands, with a local subtle blur only during change. Segments and rows are staggered deterministically by scroll, without random characters or language opacity crossfades. Reverse scroll restores Chinese; reduced motion skips deformation. Text widths keep adjacent segments together.

Removed the separate model-stage glow/background in the homepage digital section, faded the shared rough floor underneath that section into the same dark cabin tone, and replaced negative carousel margins with positive spacing. Carousel overflow is contained so it cannot cover the interior. Model contact shadows and restrained local lighting remain.

Validation: production build; check-v30 covers complete/reverse language states, one visible text sequence, non-overlapping cabin/carousel geometry, responsive overflow, model selection, wheel pass-through and reduced motion at 320/390/768/1440. Desktop/mobile visual review. v29 retained for rollback.

## Version 31 — desktop pinned localization scene

The homepage digital heading and cabin now share a desktop-only sticky stage below the header. Its native scroll span drives the existing 10% camera move and sequential glyph reformation, then releases into the model selector after completion. No wheel interception or body scroll lock is used. Narrow and coarse-touch devices retain the v30 normal document flow. Short desktop viewports have a smaller camera framing and heading to keep the tablet visible. Reverse scrolling and reduced-motion behavior remain supported.

Validation: production build; check-v31 covers desktop 1440/768, short 1280x500, phone portrait and touch landscape. Checks pinning, language stages, release, non-overlap with model selector, normal touch flow, reverse translation, reduced motion, overflow and browser errors. Desktop/mobile screenshots reviewed. v30 archived for rollback.

## Version 32 — visible desktop camera push-in

Increased the pinned desktop cabin camera movement from 10% to 30%, centered on the tablet and driven continuously by the same eased scroll progress. Touch/mobile retains its 10% movement; reduced motion still disables zoom. Text transformation, scene pin/release and model rail remain unchanged.

Validation: production build; check-v32 verifies camera scale at four scroll stages, desktop pin/release at wide/narrow/short viewports, mobile normal flow, reverse text, reduced motion and overflow. Desktop/mobile screenshots reviewed. v31 retained for rollback.

## Version 33 — tighter mobile digital-section spacing

For screens up to 650px, reduced the gap after styling services from 64px to 32px, cabin height to 240–300px, and heading bottom margin to 4px. Raised the camera within the cabin to 42%, reduced the model rail margin to 8px and rail height to 250px. Camera scale, text translation, desktop layout/pinning and model interaction are unchanged.

Validation: production build; browser review at 320/390/430 checks no horizontal overflow, the 8px non-overlapping cabin/model gap and visible tablet/vehicle content. Mobile screenshots reviewed. v32 saved for rollback.

## Version 34 — ultrawide image edges and hybrid desktop pinning

Applied horizontal feathering to the actual cabin SVG bounds, so the 1450px image no longer ends abruptly inside a wider viewport mask. Restricted coarse-pointer mobile rules to widths below 1024px, and made the digital sticky sequence unconditional at 1024px and above. This prevents touch-capable desktop devices from losing both BMW and cabin pinning or receiving the compact mobile hero. A stable dark BMW stage backdrop prevents the scrolling shared floor from moving behind its feathered edges.

Validation: production build; check-v34 exercises both scenes with real wheel input at 2048/3440 mouse, 2560/1024 touch-hybrid, plus a 390px phone. Verifies pin position through coating/lights and translation, release after completion, image edge masks and no overflow/browser errors. Wide screenshots reviewed. v33 retained for rollback.

For viewports at least 2000px wide, both photographic scenes additionally scale against viewport height/width with capped sizes, avoiding a small fixed-width image on an ultrawide monitor. Rechecked the two ultrawide cases after this geometry adjustment.

## Version 35 — reference-inspired hero typography and layered atmosphere

Split the hero heading into a wide Montserrat 800 silver-gradient main line and a lighter tracked subtitle. Added a scalable outline 77 sign behind the heading, with subdued red glow and slow opacity breathing. Added a separate slow procedural SVG mist layer registered to the hero photograph; its mask excludes the two car silhouettes and fades vertically into the far floor. Existing foreground GPU atmosphere and lights remain. Mobile retains compact composition with fitted typography. Reduced motion disables the new drift/glow loops.

Validation: production build; check-v35 verifies 320/390/1440/2048 layouts, fitted headline and no overflow, rear atmosphere/occlusion and sign presence, changing fog transform, reduced motion and no browser errors. Desktop/mobile screenshots reviewed. v34 retained for rollback.

## Version 36 — rebuilt hero atmosphere and dedicated typography

Generated a refined studio photograph with coherent distant wall haze and reflections while preserving both cars. Replaced stretched Montserrat headline with locally embedded Unbounded variable Cyrillic subset (OFL included). Removed the polygon-traced vehicle fog mask entirely. The distant 77 now has separate contour/bloom layers with a slow pulse and an independently drifting, softly bounded haze layer composited in front of the digits. Existing foreground atmosphere remains. Reduced motion disables new loops.

Validation: production build; 390/1440 browser review confirms font loading, no overflow, active sign pulse/haze animations. Screenshots reviewed. v35 retained for rollback.

## v37 — layered approved hero

The hero uses registered 1672×941 environment and transparent car masters in
`public/assets/masters/v37/`. WebP copies retain native resolution; no artificial
4K claim or upscaling. `HeroDepth.tsx` contains editable vector 77, soft pulse and
rear mist. `Site.tsx` keeps the Russian heading as real selectable text. Layer order:
environment → lamps/sign → rear haze → alpha cars → GPU foreground fog → title.
All layers share the same aspect ratio; mobile has its own title placement.
Reduced-motion preferences disable drift and pulse. Intro lifecycle is preserved.

Validation: production build; Chromium 320/390/1440/3440 px, heading/overflow,
image loading, moving rear haze, reduced motion and no runtime errors.

## v38 — long 77 and seamless hero edges

Extended the vector legs of both sevens from 280 to 520 units. A local SVG
opacity gradient fades them out before the closed lower edges. Removed the
central decorative red line and the additional sign-local rectangular fog layer.
Photographic backdrop now has its own top/side/bottom feathering; the parent no
longer clips fog or the mobile sign. Wider screens use a broader side feather.
Verified production build and Chromium at 320, 390, 1440 and 3440 px.

## v39 — rebuilt cinematic opening scene

`components/CinematicHero.tsx` replaces the former hero markup and overlays.
New assets are independent room, Rolls-Royce and ZEEKR images; PNG masters live
in `public/assets/masters/v39`, native 1672×941 room and 1536×1024 cars. Room has
no baked fog. Vehicles are photographic alpha planes, not low-poly vehicle meshes.
Three.js renders the room, bevelled/extruded 77 geometry, luminous edge/glint
materials, depth-separated procedural fog, vehicle shadows and attenuated
reflections. Bloom uses EffectComposer/UnrealBloomPass. No decorative centre line.
Fog is shader-driven and loops over 90 seconds. Rendering pauses offscreen and in
hidden tabs; reduced motion freezes time. Resolution capped at 2000 pixels, frame
rate at 30 fps. HTML image fallback remains if WebGL cannot initialize or is lost.
Editable HTML title stays independent of the canvas. Other sections preserved.

Checks: production Next build; Chromium 390/1440/3440, real WebGL initialized,
clock advances, reduced motion stops it, no runtime errors or horizontal overflow.

## v40 — preserve the approved reference composition

Restored the approved camera angles, relative sizes, placement, photographic
contact shadows and wet-floor reflections. The clean photographic plate is a
minimal fog-removal retouch of the approved composition, not two newly styled
cars. Native 1672×941 PNG master: public/assets/masters/v40/approved-composition-clean.png.
A registered matte reprojects identical photo pixels in front of rear atmosphere;
this deliberately locks vehicle layout to the approved plate. It is not a free
3D vehicle model. Removed v39 synthetic reflections/shadows and separate vehicle
placements. Updated wall-light coordinates to this reference. Geometry 77, live
shader fog, reduced-motion behavior and independent HTML title remain.
Validation: production build and real Chromium WebGL at 390, 1440, 3440 pixels;
no browser errors/overflow; animation runs and reduced-motion freezes time.

## v41 — approved artwork as one intact image, with separate foreground fog

Replaced the reconstructed hero with the approved header-free artwork after the
requested localized type-artifact cleanup and softer photographic wet-ground
retouch. Original retouched PNG is `public/assets/approved-hero-v41.png`.
The displayed lossless WebP decodes to exactly the same pixels (verified with sharp).
No re-created title, digits, vehicle layers, bloom or recolouring. The complete
image scales proportionally with no crop/filter/mask. Existing site header stays.
A separate transparent WebGL canvas adds slow foreground fog on a 90-second loop;
no extra lamp or sign animation. Reduced motion and tab/offscreen pause supported.
Other sections unchanged. Verified production build and real Chromium WebGL at
390/1440/3440 pixels: original aspect ratio, no duplicate title/sign, live fog,
reduced-motion freeze, no browser errors/overflow.

## v42 — opening scene raised by 10%

One scoped CSS change: negative top margin equals 10% of the intact artwork
height, accounting for its 1678×937 ratio and 2200px width cap. The hero clips only
the empty top portion and becomes equally shorter; image scale, fog registration
and all other sections stay unchanged. Browser-measured lift is 10% at 390,
1440 and 3440px, with no horizontal overflow. No image edits.

## v43 — единое окружение
Новый отдельный графитовый подиум, существующие фото BMW с прежней анимацией покрытия и фар. Автомобиль отделён SVG-маской от старого окружения. Общий фон больше не растягивает текстуру по всей длине страницы; края главной сцены и салона плавно уходят в темноту. Масштаб сцен ограничен шириной и высотой экрана. Главная фотография, карточки, селектор, перевод интерфейса, факты и CTA сохранены. Проверки: production build, check-v34.cjs (sticky/release/широкие touch-экраны/мобильный overflow), check-v43.cjs (снимки сцен).

## v44 — общий павильон и отдельный SVG-заголовок
Общее фиксированное окружение Pavilion сопровождает всю страницу: пол, красный свет, медленная дымка и небольшой параллакс. Площадка v43 удалена, BMW снова использует исходную фотографию с родными тенями и прежним переходом глянец/мат/фары. Салон и края сцен согласованы с общим окружением.
Главная фотография очищена от заголовка и центральной световой полосы (hero-clean-v44.webp). Утверждённые буквы трассированы в SVG-контуры без замены шрифта (hero-title-v44.svg и content/hero-title-paths.json). Появление SVG независимо от изображения встроено во вступление. Трассировка воспроизводится scripts/trace-hero-title.cjs.
Проверки: production build; check-v44.cjs — SVG, заставка, общий фон, reduced-motion, ширины 390/1440/3440; check-v44-scroll.cjs — sticky, завершение/выход из двух сцен на 2048/3440/2560 touch/1024 touch/390. Визуальные снимки реального сайта: check-v44-visual.cjs.

## v45 — живой текст главного заголовка
Контуры SVG заменены настоящим HTML h1: Unbounded 650 для основной строки, Manrope 400 для подзаголовка. Размеры привязаны к ширине сцены, на телефонах отдельная типографическая настройка. Сохранено появление после заставки. Фон и остальные сцены не менялись. Проверены production build и отображение на ширинах 390/1440/3440.

## v46 — сцены, нижний блок и плавность
1. Возвращены графитовый светлый градиент и скалы внизу с адаптивным фоном.
2. Удалён фиксированный Pavilion из Home: окружение больше не остаётся неподвижной фотографией за прокручиваемыми сценами.
3. Края главной сцены, BMW и салона сведены с общим тёмным тоном, важные детали не размываются.
4. Два заголовка разделов используют Unbounded 650, общий цвет и прозрачность с главным; «Наши проекты» сохранён. Старое затемнение поверх главного текста отключено.
5. Reveal: 800 мс, 150 мс между стартами, очередь отдельно по разделам. Устаревшие невидимые элементы не задерживают новые; структурные сцены исключены из дополнительного translate.
6. Главная сцена восстановлена из approved-hero-v41.png: ровнее световые линии, мягче ореолы; текст и центральная полоса удалены, текст остаётся HTML. Master PNG сохранён.
7. Вступление ждёт декодирования изображения и шрифтов, reduced-motion сразу показывает страницу. Исправлена мобильная нормализация BMW по высоте viewport.
Проверки: production build; check-v46.cjs (390/1440/3440, шрифты/цвет/очередь/быстрый скролл/селектор/reduced-motion); check-v46-scroll.cjs (прямой и обратный скролл, sticky/release, hybrid/tablet/phone).

## v47 — переход сцен, масштаб разделов и шапка
- Стыку главной сцены и BMW добавлены плавные градиенты с несколькими точками затухания; верх BMW отдельно сведён с общим тёмным фоном без затемнения заголовка.
- Заголовки автостайлинга и цифровых решений увеличены на 25%; сохранены Unbounded 650, цвет и прозрачность. На телефоне предусмотрено место для переноса строк.
- Убраны скалы. Нижний блок сохраняет факты и рамку консультации, завершаясь мягким светлым графитом с лёгким бордовым оттенком.
- Desktop BMW: дополнительные 28svh нативной прокрутки с полностью включёнными фарами после завершения анимации. Скорость самой трансформации прежняя. На телефоне без закрепления и дополнительной задержки.
- Только LAB в логотипе шапки приведён к бордовому оттенку через SVG color matrix; исходное изображение, форма, белые части и вступительный логотип сохранены.
- Пять белых SVG-знаков: Telegram, VK, YouTube, Instagram, MAX. Источники и лицензии в content/social-icons-sources.md. До наполнения ссылки, как прежде, ведут в контакты.
Проверено: production build; check-v47.cjs (390/1440/3440, раскрытия, шрифты/цвет, SVG-иконки, селектор, reduced-motion); check-v47-scroll.cjs (2048/3440/2560/1024/390, прямой/обратный скролл, фары остаются на месте при следующем wheel, выход из обеих сцен).

## v48 — LAB чуть светлее
Только цвет LAB в шапке: бордовый осветлён примерно на 25%. Белые части логотипа сохраняют исходный цвет. Геометрия, вступительный логотип, кнопки и сцены не менялись.

## v49 — нижний блок, мобильная очередь и фокус автомобилей
- Возвращены скалы по бокам: две пересекающиеся маски оставляют центр прозрачным, лёгкое CSS-размытие смягчает края. Графитовый градиент v47 сохранён.
- Только заголовок консультации переведён в Unbounded 650. Заголовок «Наши проекты» сохраняет Manrope и увеличен на 30% на каждом брейкпоинте.
- На телефоне главный заголовок и видимые элементы разделов объединены в общую очередь: 800 мс на появление, 150 мс между стартами, включая элементы из разных групп IntersectionObserver. Очередь начинается во время растворения заставки; завершение вступления не перезапускает её. Элементы ниже экрана ожидают пересечения viewport. Desktop-вступление сохранено; reduced-motion показывает всё сразу.
- Боковые автомобили: blur(1.5px), brightness(.65); центральный — резкий и прежней яркости. Переход фильтра синхронизирован с движением 1500 мс, перезапись слотов выполняется без дополнительного перехода.
Проверки: production build; check-v49.cjs — 320/390/1440/3440, равные старты/длительности и отсутствие повторного запуска, шрифты/размеры, скалы, промежуточный фильтр при переключении, обратный выбор, wheel остаётся прокруткой страницы, отсутствие overflow и ошибок JS, reduced-motion.

## v50 — мобильный заголовок и исходное глянцевое состояние
- Только мобильный заголовок «Автостайлинг и детейлинг» уменьшен до 4.4vw, немного меньше основной строки hero (4.5cqw). Desktop и остальные заголовки сохранены.
- Мобильный прогресс BMW теперь вычисляется по прокрутке документа с нижней границей начала 0: на верхней точке страницы всегда глянец и выключенные фары, даже когда автомобиль виден целиком сразу после загрузки.
- После прокрутки покрытие меняется плавно, затем включаются фары. На телефоне по-прежнему нет закрепления. При обратной прокрутке к началу возвращается глянец.
- Изменение высоты мобильной панели браузера не продвигает анимацию; размер viewport пересчитывается при изменении ширины (например, повороте телефона).
Проверки: production build; check-v50.cjs — 320×568, 390×844, 430×932, 390×1100: исходный прогресс/мат/фары 0, меньший заголовок, изменение только после скролла, стабильность при изменении высоты, обратная прокрутка, отсутствие overflow/JS-ошибок; desktop удержание сцены сохранено.

## v51 — отступ BMW и стабильные прозрачные изображения селектора
- Desktop: BMW опущена на дополнительные 36–80 px в зависимости от высоты окна, при обычной высоте 1000 px — на 60 px. На низких экранах отдельный отступ 32 px. Мобильное расположение и таймлайн покрытия сохранены.
- Селектор перешёл с CSS-фона WebP с анимированной цепочкой blur/brightness/contrast/drop-shadow на обычные PNG img с альфа-каналом. PNG получен исключительно перекодированием; совпадение декодированных RGBA-пикселей с исходным WebP проверено.
- Чёткий слой не использует фильтры, размытый слой имеет постоянный blur; переключение фокуса происходит через opacity за прежние 1500 мс. Тень под автомобилем остаётся отдельным элементом. Нативное оформление кнопок отключено через appearance:none.
- Обход потенциальных артефактов мобильного композитинга, без регенерации автомобилей. Проверка на физическом iPhone в этой среде недоступна.
Проверки: production build; check-v51.cjs — 390/430/1024/1440/3440, промежуток между заголовком и крышей, декодирование каждой модели, прозрачный PNG без больших белых областей, переход opacity в середине движения и после завершения, отсутствие overflow и JS-ошибок.

## v52 — последовательное включение фар и мобильные интервалы
- Главная фотография сохранена побитно. HeroLights добавляет SVG-слои в её исходных координатах 1678×937: затемнение оптики и части отражений для выключенного состояния, отдельное мягкое свечение и отблеск на мокром полу для включённого.
- Событие title-ready приходит после завершения появления HTML-заголовка: на телефоне из общей reveal-очереди, на компьютере из вступительной анимации. После декодирования фото 1500 мс ожидания → Rolls-Royce; 2000 мс → ZEEKR. Включение 400 мс, ореол проявляется с небольшим запозданием. Фары остаются включёнными. Отсчёт приостанавливается в скрытой вкладке; reduced-motion сразу показывает включённый свет.
- LAB в заставке использует тот же SVG-фильтр и режим смешивания, что и логотип шапки. Геометрия и белые части сохранены.
- Только на мобильном: margin-top селектора 8→28 px, плиток 8→26 px.
- Услуга firmware теперь называется «Русификация и настройка». URL, форма и остальная структура сохранены.
Проверки: production build; check-v52.cjs — 390/1440/3440, порядок и задержки фар, совмещение световых слоёв с фото, совпадение фильтров логотипа, мобильные интервалы, новое название, сохранение включённого состояния после скролла, отсутствие overflow/JS-ошибок, reduced-motion. Визуально проверены выключенный/включённый свет и мобильный блок.

## v53 — векторные соцсети, приближение сцены и свечение 77
- MAX заменён на заполненный векторный знак с характерной внутренней формой. Telegram — отдельный самолёт без внешнего диска. Все пять знаков белые, с оптически согласованными размерами; источники указаны в content/social-icons-sources.md. Ссылки пока ведут в контакты.
- Фотографические слои главной сцены плавно приближаются с 1 до 1.025 за 3800 мс; HTML-заголовок не масштабируется. Наезд продолжается после растворения заставки и сохраняет конечный масштаб без сброса.
- Свечение извлекается из существующих красных контуров 77 в исходной фотографии: форма цифр не перерисована. Мягкие горизонтальная и вертикальная маски убирают прямоугольные границы и растворяют ножки; свет медленно пульсирует с периодом 10 секунд. Туман и фары находятся в той же системе координат, что и фото.
- Reduced-motion отключает наезд и пульсацию.
Проверено: production build; check-v53.cjs на 390/1440/3440 — независимость заголовка от наезда, продолжение движения после заставки, совмещение фото/свечения/фар, SVG MAX без растровых вложений, отсутствие горизонтальной прокрутки и ошибок JS, reduced-motion. Визуально проверены шапка и главная сцена.

## v54 — ссылки соцсетей, прежние 77 и заголовок проектов
- Все пять векторных значков ведут на аккаунты, предоставленные владельцем: Telegram, Instagram, YouTube, VK и MAX. Открываются в отдельной вкладке с noopener noreferrer.
- Дополнительное свечение и пульсация 77 из v53 убраны. Исходная фотография с прежними цифрами сохранена; плавный наезд, фары и туман остаются.
- «Наши проекты» использует Unbounded 650 и цвет основных заголовков. Размеры и центрирование сохранены.
Проверено: production build; браузерный предпросмотр 390/1440 — точные адреса пяти ссылок и открытие в отдельной вкладке, Unbounded у проектов, отсутствие дополнительного слоя свечения и горизонтального переполнения. Мобильный заголовок проверен визуально.

## v55 — единый масштаб мобильных заголовков
- Только до 650 px: «Автостайлинг и детейлинг», «Русификация и цифровые решения» и «Наши проекты» используют общий размер clamp(28px,7.2vw,36.25px), межстрочный интервал 1.25 и сбалансированные переносы.
- Удалено отдельное правило 4.4vw, делавшее заголовок автостайлинга заметно мельче. Unbounded, начертание, цвет, desktop-стили и анимации сохранены.
Проверено: production build; браузер на 320/390/430/650/1440 — равные размеры трёх мобильных заголовков, отсутствие переполнения текста/страницы, сохранение desktop-размеров. Визуально проверены переносы и расстояние до BMW на 320/390 px.

## v56 — диагностика и стабильность анимаций
- HeroLights: затемнение фар и свечение перенесены из изменяемых групп одного SVG в четыре самостоятельных SVG-слоя. Маски, оптика, отражения, цвета, порядок и задержки 1500/2000 мс сохранены; меняется только CSS opacity корней. Повторные записи одинаковой прозрачности исключены. Камера сохраняет подготовленный слой scale после завершения наезда; reduced-motion не резервирует дополнительные слои.
- Цифровая сцена на телефоне: высота для расчёта прогресса фиксируется до изменения ширины. Исчезновение/появление панели браузера больше не меняет перевод и приближение без прокрутки. До исправления при resize 844→760 прогресс самопроизвольно менялся .6231→.5604; после остаётся стабильным.
- Диагностика: check-v56.cjs на 390/1440/3440 — порядок фар, совпадение координат слоёв, стабильное завершение наезда, desktop sticky BMW/салона вперёд и назад, мобильный resize, циклический выбор моделей, wheel, reduced-motion, overflow и JS-ошибки. Дополнительный финальный прогон 390 после настройки композитинга.
- check-v56-continuity.cjs — сравнение неподвижной hero-сцены с v55 без динамического тумана: среднее RGB-отклонение 0; завершение смены модели без скачка (менее 1 px между последними кадрами); плавный штатный hover 1→1.055→1. Для сравнения требуется standalone v55 как previews/AVTOLAB77-v55-diagnostic.html.
- Контрольная Chrome trace на мобильной ширине: число Paint-событий между готовым заголовком и включёнными фарами снизилось с 24 до 16. Это диагностика конкретного прогона, не гарантия FPS на устройстве. Проверка на физическом iPhone/Safari недоступна; точный аппаратный рывок пользователя не подтверждён.
- Production build проходит. Изображения, оформление, шрифты, размеры и структура не изменены.

## v57 — компактная форма записи на услугу
- Диалог центрируется по экрану. Заголовок «Запись на услугу» по центру; убраны прежние вводные тексты, постоянное поле автомобиля/пожеланий, демо-подпись и ссылка на обработку данных.
- Имя и телефон, затем нативный доступный select «Что вас интересует?»: 12 актуальных услуг в двух группах и «Другое». При выборе «Другое» появляется обязательное поле своего обращения. На странице услуги выбор заполняется её значением.
- Бордовая кнопка «Подать заявку» в существующей палитре. На телефоне поля располагаются друг под другом, размер текста 16px избегает автоматического увеличения формы браузером. Панель ограничена высотой экрана, внутренний скролл доступен.
- Повторное открытие создаёт новое состояние формы: имена/телефоны/свой текст и сообщения очищаются. Закрытие работает по крестику, Escape и клику за пределами панели. Есть связанный заголовок, доступные имена полей и проверка номера по количеству цифр.
- Отправка ещё не подключена. После валидного нажатия вместо ложного подтверждения появляется сообщение о недоступности отправки со ссылкой на Telegram студии. Начальная форма не содержит технических пояснений; данные не отправляются и не сохраняются.
Проверено: production build; check-v57.cjs на 320/390/1440 — центрирование, состав полей/опций, «Другое», валидация, состояние отправки, закрытие/сброс, предвыбор со страницы услуги, отсутствие JS-ошибок. Мобильный и desktop-вид проверены визуально.

## v58 — запись и информация о студии в одной панели
- Широкий экран: две колонки, форма слева, «Как нас найти» справа. До 820 px колонки становятся вертикальными, форма и отправка идут первыми. Контент прокручивается внутри панели, отдельная верхняя полоса удерживает крестик доступным. При повторном открытии прокрутка возвращается к форме.
- Выпадающий список без групп: Антигравийная защита, Полировка кузова, Тонирование стекол, Бронирование стекол, Удаление вмятин, Шумоизоляция, Русификация, Другое. «Другое» открывает своё поле. Цифровые страницы предвыбирают Русификацию.
- Данные владельца централизованы в content/studio.ts: Москва, ул. Ермакова Роща, д. 7А, строение 2; Пн–Сб, 10:00–19:00. Те же адрес/часы заменяют заполнители на странице контактов.
- Яндекс iframe для организации 98750739355 создаётся только при открытии панели и удаляется при закрытии. Карта не перехватывает прокрутку и фокус; прозрачная ссылка поверх ведёт к исходной карточке организации. «Построить маршрут» открывает Яндекс с rtext по полному адресу; ll из предоставленной ссылки не трактуется как координата входа. Все внешние ссылки открываются отдельно с noopener noreferrer.
- В рабочей среде домен Яндекса недоступен. Проверены URL, поведение и геометрия встраивания; реальную загрузку стороннего виджета здесь подтвердить нельзя. На контрольных снимках iframe скрывался только в тесте, показывая запасную панель, без подмены географии.
- Приём заявок по-прежнему не подключён: валидная форма честно сообщает об этом и предлагает Telegram, не отправляет и не сохраняет данные.
Проверки: production build; check-v58.cjs — 320/390/768/1024/1440, точный список, контактные данные, адаптивная раскладка, отсутствие переполнения, неподвижный доступный крестик, ссылки маршрута/организации, отсутствие iframe до открытия, «Другое», сброс, закрытие и предвыбор цифровой услуги, отсутствие JS-ошибок.

## v59 — центрирование панели записи и единая типографика
- Заголовки формы и контактов используют Unbounded, остальной текст и поля — Manrope. Текст, плейсхолдеры, выбранная услуга, адрес, часы и кнопки выровнены по центру.
- Вместо набранного буквами знака используется настоящий логотип сайта с тем же изображением и SVG-фильтром бордового LAB, что в шапке.
- На широком экране форма центрируется по высоте относительно контактной колонки. На телефоне сохранён естественный порядок: форма, контакты, карта, маршрут, без лишней вертикальной пустоты.
- Проверки: production build; Chromium 320/390/768/1024/1440 — центрирование текста и колонок, совпадение логотипа с шапкой, шрифты, поле «Другое», отсутствие горизонтального переполнения, доступный крестик при внутренней прокрутке. Desktop и мобильная композиция проверены визуально. Реальный виджет Яндекса недоступен для проверки в рабочей среде; поведение отправки не менялось.

## v60 — монохромная карта с бордовым оттенком
- Встроенная карта обесцвечена и приведена к тёмной палитре CSS-фильтром; отдельный мягкий бордовый слой объединяет её с оформлением панели.
- Убрана наша видимая плашка «Открыть в Яндекс Картах». Ссылка поверх карты сохраняет доступное имя и видимый фокус; кнопка «Построить маршрут» остаётся ниже.
- Проверки: production build; Chromium 390/1440 — фильтр, отсутствие текста плашки, доступное имя ссылки, сохранённый маршрут и отсутствие переполнения. Яндекс недоступен из рабочей среды: реальная загрузка и внешний вид содержимого стороннего iframe не подтверждены.

## v61 — статичная схема расположения студии
- Вместо внешнего iframe установлено отдельное изображение, подготовленное по предоставленному пользователем снимку карты: графитовая палитра, бордовые акценты, Автолаб77, Шелепиха, Москва-Сити и Деловой центр. Убраны посторонние организации и интерфейс карты.
- Это иллюстративная схема, а не навигационная карта с гарантированной точностью геометрии. Точный маршрут открывается по существующей ссылке Яндекса с адресом студии.
- Изображение показывается целиком с естественными пропорциями на всех ширинах, встроено в standalone HTML; сторонние запросы для его отображения больше не нужны. Ссылка на карточку организации и кнопка маршрута сохранены.
- Проверки: production build; Chromium 320/390/1440 — декодирование картинки, полные пропорции, отсутствие iframe, подписей интерфейса и горизонтального переполнения, URL маршрута; мобильный вид проверен визуально.

## v62 — интерактивный просмотр карты
- Статичная схема теперь открыта в локальном просмотрщике: масштаб 1–3× кнопками +/− и двумя пальцами, перетаскивание мышью или пальцем. Колёсико не перехватывается и продолжает прокручивать панель.
- Смещение ограничено краями изображения; при смене числа касаний жест пересчитывается без скачка. Нажатие после незавершённого кнопочного зума начинает перетаскивание с текущего видимого кадра. Pointer capture удерживает жест до отпускания/отмены.
- Кнопочное приближение плавное, reduced-motion отключает переход. Клавиатура: +/−, стрелки при увеличении, Home/0 для исходного вида. При повторном открытии заявки масштаб сбрасывается. Ссылка поверх изображения удалена, отдельная кнопка маршрута и адрес сохранены.
- Проверки: production build; check-v62.cjs в Chromium 390/1440 — ограничения зума и смещения, перетаскивание, wheel над картой прокручивает панель, клавиатура, повторное открытие, отсутствие переполнения и ошибок JS. На мобильной эмуляции реальные CDP touch-события проверяют увеличение/уменьшение двумя пальцами и отмену жеста; физический iPhone/Safari не проверялся.

## v63 — интерактивные Яндекс Карты вместо просмотра картинки
- LocationMap использует официальный iframe Яндекс Карт по предоставленному владельцем ID организации 98750739355. Статичная схема и собственные обработчики зума/перетаскивания удалены из отображения.
- В iframe включено прямое взаимодействие: pointer-events:auto, доступный фокус, нет прозрачной ссылки/щита поверх. Декоративный бордовый слой не принимает события. Приближение, перемещение и содержимое обслуживаются самим Яндексом, а не локальным просмотрщиком.
- Карта монтируется только при открытой заявке и удаляется при закрытии. Высота 340 px на компьютере и 320 px на телефоне; тёмная монохромная обработка сохранена. Кнопка маршрута и адрес ведут в Яндекс отдельно.
- Проверки: production build; check-v63.cjs на 320/390/1440 — URL виджета, ID организации, прямой hit-test iframe, клавиатурный фокус, отсутствие прежней картинки/контролов/перекрывающего слоя, маршрут, открытие/закрытие, отсутствие переполнения и JS-ошибок.
- Домен Яндекса запрещён сетевой политикой рабочей среды: реальная загрузка, оформление и жесты внутри стороннего виджета здесь не проверены. Проверки не подменяют карту фиктивной географией и не утверждают, что проверен её внешний сервис.

## v64 — MapLibre и OpenFreeMap без рекламного виджета
- Яндекс iframe заменён настоящей векторной картой MapLibre GL JS 6.16.0 на бесплатном публичном источнике OpenFreeMap / OpenStreetMap. Нужные детали подгружаются при изменении масштаба; никаких статичных схем и рекламных карточек внутри панели.
- Точная метка владельца: 55.758385, 37.529670. Собственный графитовый стиль с бордовыми акцентами, зданиями, улицами и транспортными ориентирами. Посторонние организации не добавляются. Названия станций и Москва-Сити берутся из векторных данных, а не из придуманных точек.
- Перемещение мышью/пальцами, приближение двумя пальцами и кнопками. Колёсико прокручивает панель, вращение отключено. Видимая атрибуция источников, прежняя отдельная кнопка маршрута в Яндексе.
- MapLibre и его module worker встроены в сборку; worker воспроизводимо собирается перед build/export. Карта создаётся только в открытой заявке, очищает canvas/worker/ResizeObserver при закрытии. Есть обработка недоступности тайлов и повторная загрузка. Координаты пользователя не запрашиваются.
- Бюджет standalone-публикации повышен с 12 до 14 MiB из-за настоящего векторного рендера и worker; прежние снимки по-прежнему вынесены в архив. Лицензия сохранена, источники описаны в content/map-sources.md.
- Проверки: production build; стиль валиден по спецификации MapLibre; check-v64.cjs — Chromium 390/1440, работа реального renderer/worker на явно синтетической тестовой геометрии, зум, pan, touch pinch, wheel, атрибуция, точность введённых координат, отсутствие переполнения/JS-ошибок, освобождение worker, ошибка загрузки и успешный retry.
- Домен тайлов не разрешён в рабочей среде. Реальная загрузка внешней картографии, расположение подписей и физический iPhone/Safari не проверены; тестовые данные не выдаются за настоящую географию и не публикуются.

## v65 — компактные источники карты и плавная панель записи
- Атрибуция MapLibre сворачивается в штатную кнопку ⓘ при первом появлении. Нажатие раскрывает все три ссылки источников; повторное нажатие сворачивает. Отслеживание первичной инициализации отключается сразу после сворачивания и очищается при закрытии карты.
- Крестик получил явное appearance:none, прозрачный фон, нулевые рамку/тень/outline и область нажатия 44×44 px. Для клавиатуры оставлен небольшой круглый индикатор фокуса вместо квадратной рамки.
- Панель появляется за 480 мс с лёгким подъёмом и масштабом .985→1; закрывается за 360 мс с обратным движением. Затемнение плавно появляется и исчезает вместе с окном. При закрытии во время открытия оба перехода начинаются из текущего видимого состояния, без скачка к началу/концу анимации.
- Крестик, Escape и нажатие вне окна проходят через одну процедуру закрытия. Пока идёт выход, диалог остаётся модальным и карта сохраняется. После закрытия восстанавливаются прокрутка и фокус кнопки; смена маршрута только снимает блокировку, не переопределяя прокрутку новой страницы.
- Инициализация карты отложена до завершения появления панели; reduced-motion открывает/закрывает без анимации. Повторные нажатия не создают конкурирующие переходы.
- Проверки: production build; check-v65.cjs на 390/1440 — раскрытие/сворачивание атрибуции, оформление крестика, промежуточные кадры браузерных анимаций, прерывание входа, все способы закрытия, сохранение позиции страницы/фокуса, очистка worker, reduced-motion и уход на другую страницу. Геометрия карты в проверках синтетическая; внешний источник тайлов и физический iPhone не проверялись.

## v66 — точные векторные значки соцсетей
- YouTube, VK и Instagram используют полные контуры Simple Icons 16.0.0 без ручного округления координат. YouTube увеличен до 28 px по ширине, лишние поля его viewBox убраны; исходные пропорции сохранены. Telegram и MAX сохранены.
- Значки выровнены по центру, без обводки и растровых изображений. Все пять ссылок владельца сохранены.
- Проверки: Chromium 390/1440/2560 — ссылки, отсутствие горизонтального переполнения и ошибок JS; на компьютере одинаковая ось центров и визуальная проверка снимков. На телефоне сохранено прежнее скрытие группы соцсетей в компактной шапке.

## v67 — компактная запись, контакты и управление картой
- На компьютере форма и контакты начинаются с одной линии заголовков. Уплотнены логотип, контактные строки и карта; окно помещается без внутренней прокрутки при 1366×768 и 1440×900 с исходной формой. Невысокие экраны и расширенная форма сохраняют прокрутку.
- Под формой добавлены «Удобнее написать?» и общий SocialMarks со всеми пятью действующими ссылками; MAX использует тот же SVG, что в шапке. На мобильных — вертикальный порядок формы, соцсетей, контактов и карты.
- Добавлен подтверждённый владельцем телефон +7 (495) 506-55-50, tel:+74955065550 между адресом и расписанием.
- Колёсико над картой меняет масштаб без прокрутки панели; кнопки масштаба удалены. Сохранены pinch, перемещение одним пальцем, клавиатурное управление, отдельный маршрут и все источники карты.
- Значок атрибуции центрирован внутри подложки 28×28, фон SVG центрирован, устранены конфликтующие отступы/box-sizing и фоновая заливка summary. Источники по-прежнему раскрываются штатной кнопкой.
- Проверки: production build; check-v67.cjs на 1440×900, 1366×768, 390×844, 320×640 — компоновка, телефон, совпадение MAX, раскрытие источников, выравнивание кнопки, масштаб колесом в обе стороны, pinch/pan, прокрутка вне карты, поле «Другое», очистка карты. check-v65.cjs подтверждает плавное открытие/закрытие, Escape, backdrop, восстановление прокрутки и фокуса.
- Проверки карты используют реальный MapLibre renderer с явно синтетической тестовой геометрией; реальная внешняя картография и физический iPhone/Safari в рабочей среде не проверялись.

## v68 — общий шаблон услуг и первая страница «Шумоизоляция»
- Центрированная редакционная страница по согласованному макету: название, крупное изображение с мягкими краями, три коротких блока, горизонтальная лента примеров и запись. Без хлебных крошек, FAQ, этапов и логотипа Comfort Mat.
- Содержание шумоизоляции взято из текста, присланного владельцем, и согласованного сокращённого варианта. Изображения временные с явной подписью; реальные работы ещё не предоставлены.
- Новый ServiceArticle и content/service-pages.ts разделяют шаблон и наполнение. Пять остальных услуг пока не переведены: оригинальный avtolab77.ru заблокирован сетевой политикой, доступ запрошен через черновик настроек. Это частичный этап, не завершённый перенос всех услуг.
- «К услугам» возвращает к карточкам на главной, без повторной заставки. Лента управляется колесом, мышью, касанием и клавиатурой; запись открывается с выбранной услугой.
- Для новых страниц подготовлен полный латинско-кириллический Unbounded из существующего шрифта; прежний малый hero-subset не изменён.
- Проверки: production build; scripts/check-service-pages.cjs на 390/1440/2560 — содержание, центрирование, изображения, отсутствие переполнения, горизонтальная лента, выбор услуги при записи и возврат к карточкам. Предыдущие страницы и архивы сохранены.

## v69 — шесть услуг, новые главные иллюстрации и галереи без полосы прокрутки
- Все шесть страниц автостайлинга оформлены по согласованному центрированному шаблону. Тексты сокращены с доступного оригинального сайта; источники и фотографии зафиксированы в content/service-pages-sources.md и JSON-манифестах.
- Для антигравийной защиты, тонировки и полировки сгенерированы отдельные реалистичные иллюстрации 1672×941 в общей тёмной стилистике. Главные изображения бронирования, PDR и шумоизоляции сохранены.
- Настоящие фотографии в примерах работ сохранены без замены сгенерированными изображениями. Общие фотографии студии в галереях бронирования/PDR подписаны как общие; реальные тематические кейсы добавятся позже.
- Полоса прокрутки скрыта только у лент примеров работ (стандартный scrollbar-width и WebKit). Колесо, перетаскивание, свайп и клавиатура работают как раньше.
- Standalone-экспорт хранит каждое JS-изображение единожды. Бюджет Pages увеличен с 14 до 18 MiB для шести полных страниц и реальных галерей; иллюстрации сжаты в WebP без уменьшения разрешения. Прежние версии сохранены отдельно.
- Проверки: production build/TypeScript; 24 проверки страниц на 320/390/1440/2560 px — картинки, центрирование, отсутствие переполнения, скрытая полоса, wheel/drag/keyboard, выбранная услуга в заявке, возврат. Отдельно: нативные touch-события, загрузка изображений главной из автономного HTML, неизменность всех галерей и текстов относительно одобренного черновика. Физический Safari/iPhone не проверялся.
- Пользователь прямо запросил внести изменения на сайт. v69 включает предыдущий согласованный локальный черновик услуг; конфигурация рабочей среды не менялась.

## v70 — полные галереи, мягкая цветокоррекция и плавная навигация
- Убраны все поясняющие подписи под «Примерами работ». Подключены все фотографии из текстов и галерей соответствующих исходных страниц: антигравийная защита — 17, тонировка — 14, полировка — 15, удаление вмятин — 12, шумоизоляция — 15. На исходной странице бронирования фотогалереи нет; ранее согласованная общая подборка студии расширена до 12 снимков.
- 25 уникальных оригиналов сохранены побайтно в content/original-service-photos, контрольные суммы и происхождение — content/service-gallery-sources.json. Сгенерированные главные иллюстрации и тексты услуг не менялись. Повторы одного URL внутри каждой ленты исключены.
- Светлые фотографии приглушены индивидуальными CSS brightness/saturation. Перерисовки нет, содержимое фотографий неизменно; обработка полностью обратима. Скрипт prepare-service-galleries.cjs воспроизводит WebP-копии и данные галерей из сохранённых оригиналов.
- При входе в услугу и возврате работает мягкое затемнение/появление 240/440 ms. Маршрут меняется под непрозрачным слоем; положение страницы и горизонтальной ленты восстанавливается до появления контента. Фиксированная шапка и sticky-сцены не помещаются в трансформированный контейнер. Уважается reduced-motion, сохраняется клавиатурный фокус.
- Возврат не повторяет заставку. Проверены браузерные Back/Forward и прерывание перехода быстрым Back: устаревший переход отменяется. Отдельный Next-адаптер использует тот же механизм; основная standalone-сборка работает через hash/history.
- Проверки: production build/TypeScript; все 6 страниц на 320/390/1440/2560 — количество изображений, отсутствие подписей и полосы прокрутки, загрузка, центрирование, wheel/drag/keyboard, запись и возврат; анимированная навигация на 390/1440 с точным восстановлением обеих прокруток и отменой перехода; production Next-навигация с reduced-motion. Контрольные суммы всех 25 исходников совпали. Физический iPhone/Safari не проверялся.

## v71 — открытие сайта с главной сцены
- Исправлена причина запуска с середины: прежняя опубликованная ссылка содержала `#/?section=services`. При первоначальном открытии главной этот служебный параметр теперь удаляется; принудительно устанавливаются начальная прокрутка и manual scroll restoration.
- Начальный вход отделён от навигационного возврата: только действие внутри сайта передаёт намерение восстановить карточки услуг. Next-версия использует отдельный одноразовый флаг; URL сам по себе больше не отключает заставку и не перемещает страницу к услугам.
- Обычная загрузка и reload главной начинаются сверху даже при сохранённой в sessionStorage позиции. Прямые ссылки на конкретные страницы услуг сохранены.
- Проверки: production build/TypeScript; check-home-entry.cjs на 390/1440 — чистая ссылка, старый hash-параметр, query-параметр, reload после прокрутки и сохранённая старая позиция; обычная анимация заставки; production Next-вход. check-service-navigation.cjs подтвердил плавные переходы, точное восстановление вертикальной/горизонтальной позиции, Back/Forward, отмену перехода и reduced-motion.

### v72 — real project catalogue

The six entries in `content/projects.ts` correspond to the six individual cases on the original site's Works pages (checked 2026-11-07). Model-specific generated covers are separate from 97 real project photographs. `content/project-gallery-sources.json` records source URLs and SHA-256 hashes of untouched originals. Website photos are resized/encoded as WebP; tonal matching is reversible CSS only.

`ProjectArticle` displays centered copy and a vertical photo list. Project and service navigation share the route dissolve but keep independent return positions. Fresh homepage visits still start at the opening scene.

The exporter writes a self-contained offline `AVTOLAB77.html` and a live `AVTOLAB77-live.html`; the latter lazy-loads content-addressed files from `project-media/`. Release metadata verifies both HTML variants and each external photo. Full camera originals are preserved in a companion ZIP to keep the main rollback ZIP below GitHub's file-size limit. The main ZIP includes all website assets and sources needed for restoration.

Validation: `npm run build`, `node scripts/check-project-pages.cjs`, `node scripts/check-service-pages.cjs`, `node scripts/check-service-navigation.cjs`, `node scripts/check-home-entry.cjs`. Browser checks use Chromium at widths 320, 390, 1440 and 2560, including actual motion, reduced motion, real-photo decoding, original hashes and return navigation.

### v73 — horizontal project galleries

Project galleries now reuse the same `work-rail`, `work-photo` and `useRail` as the styling service pages: native touch, eased mouse wheel, mouse dragging and keyboard navigation, with a hidden scrollbar. All 97 photos and their tonal treatment are retained. The v72 snapshot preserves the prior vertical layout.

### v75 — six digital service pages

All six digital cards now use the centered ServiceArticle layout: title, generated illustration, agreed informational copy and the existing booking panel. Content is brand-neutral; the master-account page is informational only and app installation concerns the customer's phone. No empty or fabricated work galleries are rendered.

Digital navigation has an independent return position and shares the existing dissolve in both Next and standalone builds. The top “К услугам” button restores the digital cards, without replaying the intro. Existing styling/project return behavior is retained.

Six 1672×941 illustrations are optimized to WebP (about 700 KiB total). Digital hero composition is preserved at mobile and desktop widths. Source notes and asset provenance: content/digital-pages-sources.md.

Validation: production build (including TypeScript); check-digital-pages.cjs at 320, 390, 1440 and 2560, all six routes, images, booking, no overflow, motion and return restoration in standalone/Next; existing service navigation regression checks.

### v76 — digital hero images in the published export

Fixed the six digital hero paths: their runtime string concatenation was invisible to the standalone asset embedder. The Next build could load them from public/assets, but Pages requested missing root-domain URLs. Paths are now complete literals, so all six illustrations are embedded in both export variants.

Added check-digital-export.cjs to decode every digital hero in the actual Pages and standalone HTML at mobile and desktop widths, check reveal visibility, and reject failed image requests. The same check can target the public URL via DIGITAL_EXPORT_URL. This complements the existing Next page tests.

### v77 — route focus after clicks and taps

Route transitions retain accessible focus on the page heading and originating card, but suppress the outline for focus assigned after pointer/touch navigation. A subsequent keyboard action removes the suppression; Tab/Enter retain visible focus. The suppression is scoped to the programmatically focused element and is cleaned up on blur and unmount. Global focus styles and form field outlines are unchanged.

Validation: production build; check-route-focus.cjs exercises touch/mouse opening and return for styling, digital and project articles in standalone and Next, keyboard Tab/Enter, and a forced retained :focus-visible browser state. Chromium coverage uses 390/1440 widths. Native WebKit could not launch in this environment because its system libraries are unavailable.

### v78 — approved localization hero and final copy

Replaced the localization hero with the owner's approved image containing a detailed Russian interface, Yandex-style map, music, menus and climate. The new WebP has an explicit literal path so both live and offline exports embed it; the original approved PNG remains in generated_images.

Applied the exact agreed App Store, OTA and setup/check wording. Full-localization and voice-assistant paragraphs and the other five service pages are unchanged. Paragraph breaks are preserved in the digital service text. OTA capability wording comes from the owner's description of their own solution.

Validation: production build/TypeScript; mobile and desktop checks of live export, offline export and Next page, matching the embedded image bytes to the approved asset, agreed copy presence, removed copy absence, paragraph layout and no horizontal overflow or JavaScript errors.

### v79 — Chinese number registration and SIM copy

Removed the entire “Как выбрать SIM-карту” section from the SIM service page. Expanded the Chinese number registration section with the owner's approved wording: personal visit, verification on the customer's device, access retained by the customer and no passport data/document copies retained by AVTOLAB77. Other service copy and visuals are unchanged.

### v80 — distinct project descriptions

Expanded all six project descriptions and work summaries, using the original project records for each vehicle. Added the owner-confirmed paintwork restoration and interior restoration to BMW E31. Existing model names, covers, galleries and navigation are retained. Mercedes remains a complete-body protection case; unrelated services are not presented as performed work.

### v81 — centered booking social heading

Renamed the booking form's social heading to “Мы в соцсетях”. Equal grid columns center the label between its decorative lines, aligned with the social icons and form. Close-button styling is unchanged. Checked at 320, 390, 430 and 1440 pixels; production build passed.

### v82 — downloadable SIM information

Added a centered, subdued burgundy “Скачать информацию по SIM-картам” link below the SIM service copy. The three-page PDF uses the owner's supplied instructions verbatim with the requested generic title “SIM-карты для автомобиля”. Operator, traffic and TCAM requirements are owner-provided service instructions. Embedded Cyrillic fonts, selectable text and narrow portrait pages keep the 53 KB file readable offline and printable.

PDF source: scripts/create-sim-guide.py (ReportLab and system DejaVu fonts). Versioned asset: public/downloads/avtolab77-sim-cards-v1.pdf. Next serves the native file; live preview uses a base-path-safe relative URL; offline exports embed the PDF. Release manifests checksum and copy downloads without modifying old assets. Change the versioned filename for future document revisions.

Validation: production build; PDF text/font checks and visual review of all three pages; download byte checks at 320/390/1440 widths, standalone offline export and built Next page. Browser emulation uses Chromium, not physical iPhone/Android devices.

### v83 — simplified download block

Removed the explanatory line beneath the SIM download button and its unused style. Button and PDF are unchanged.
