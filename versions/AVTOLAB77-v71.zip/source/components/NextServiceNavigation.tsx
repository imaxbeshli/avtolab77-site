'use client';
import {useEffect,useRef} from 'react';
import {usePathname,useRouter} from 'next/navigation';
import {createRouteTransition,isStylingPage,rememberServicePosition,requestServiceReturn} from './service-navigation';
/** Next build uses the same dissolve and restoration as the standalone release. */
export function NextServiceNavigation(){
 const router=useRouter(),pathname=usePathname();const ready=useRef<(()=>void)|null>(null);
 useEffect(()=>{ready.current?.();ready.current=null},[pathname]);
 useEffect(()=>{
  let timer:ReturnType<typeof setTimeout>|undefined;
  const transition=createRouteTransition(href=>new Promise<void>(resolve=>{
   ready.current=()=>{clearTimeout(timer);resolve()};timer=setTimeout(()=>{ready.current=null;resolve()},2500);
   if(href.startsWith('/?section=services'))requestServiceReturn();
   router.push(href,{scroll:false});if(!href.startsWith('/?section=services'))window.scrollTo({top:0,behavior:'instant'});
  }));
  const click=(event:MouseEvent)=>{
   if(event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
   const link=(event.target as Element).closest<HTMLAnchorElement>('a'),href=link?.getAttribute('href');
   if(!link||!href||(link.target&&link.target!=='_self')||link.hasAttribute('download')||(!isStylingPage(href)&&!link.classList.contains('service-return')))return;
   event.preventDefault();if(isStylingPage(href))rememberServicePosition(link);void transition.run(href);
  };
  document.addEventListener('click',click);
  return()=>{document.removeEventListener('click',click);clearTimeout(timer);ready.current?.();ready.current=null;transition.destroy()};
 },[router]);
 return null;
}
