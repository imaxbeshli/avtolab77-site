/** Navigation state is separate from the page DOM so returning never replays the intro. */
type ServicePosition={y:number;left:number;card:string;top:number};
let position:ServicePosition|null=null;
const storageKey='avtolab:service-position-v70';
export const isStylingPage=(href:string)=>/^\/?services\/styling\/[^/?#]+/.test(href);
export const isHome=(href:string)=>href.split('?')[0]==='/';
function savedPosition(){
 if(position)return position;
 try{const value=JSON.parse(sessionStorage.getItem(storageKey)??'null');if(value&&Number.isFinite(value.y)&&Number.isFinite(value.left)&&Number.isFinite(value.top)&&typeof value.card==='string')position=value}catch{}
 return position;
}
export function rememberServicePosition(card:HTMLAnchorElement){
 if(!document.querySelector('.home-scene'))return;
 position={y:scrollY,left:document.querySelector('.service-rail')?.scrollLeft??0,card:card.getAttribute('href')??'',top:document.querySelector('.service-rail')?.getBoundingClientRect().top??card.getBoundingClientRect().top};
 try{sessionStorage.setItem(storageKey,JSON.stringify(position))}catch{}
}
export function restoreServicePosition(){
 const rail=document.querySelector<HTMLElement>('.service-rail'),saved=savedPosition();
 if(!rail)return;
 if(saved){
  rail.scrollLeft=saved.left;
  window.scrollTo({top:scrollY+rail.getBoundingClientRect().top-saved.top,behavior:'instant'});
 }else document.getElementById('service-cards')?.scrollIntoView({block:'start',behavior:'instant'});
}
const frames=()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve())));
/** A short dissolve masks the route swap and scroll restoration; no transformed sticky ancestors. */
export function createRouteTransition(commit:(href:string)=>void|Promise<void>){
 const curtain=document.createElement('div');curtain.className='route-curtain';curtain.hidden=true;curtain.setAttribute('aria-hidden','true');document.body.appendChild(curtain);
 let generation=0,animation:Animation|null=null;
 const fade=async(opacity:number,duration:number)=>{
  const start=getComputedStyle(curtain).opacity;curtain.style.opacity=start;animation?.cancel();
  animation=curtain.animate([{opacity:start},{opacity}],{duration,easing:'cubic-bezier(.22,.7,.25,1)',fill:'forwards'});
  try{await animation.finished}catch{}
 };
 return {
  async run(href:string){
   const own=++generation,reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
   document.documentElement.dataset.routeTransition='leaving';curtain.hidden=false;
   if(!reduced)await fade(1,240);else{animation?.cancel();curtain.style.opacity='1'}
   if(own!==generation)return;
   try{
    await commit(href);await frames();
    if(own!==generation)return;
    if(isHome(href)&&document.querySelector('.home-scene'))restoreServicePosition();
    const hero=document.querySelector<HTMLImageElement>('.service-article-hero img');
    if(hero)await Promise.race([hero.decode().catch(()=>{}),new Promise(resolve=>setTimeout(resolve,600))]);
    if(own!==generation)return;
    document.documentElement.dataset.routeTransition='entering';
    if(!reduced)await fade(0,440);
   }finally{
    if(own===generation){
     animation?.cancel();curtain.style.opacity='0';curtain.hidden=true;delete document.documentElement.dataset.routeTransition;
     const saved=savedPosition();
     const focus=document.querySelector<HTMLElement>('.service-article h1')??Array.from(document.querySelectorAll<HTMLAnchorElement>('.service-rail a')).find(a=>a.getAttribute('href')===saved?.card);
     if(focus){if(focus.tagName==='H1')focus.tabIndex=-1;focus.focus({preventScroll:true})}
    }
   }
  },
  destroy(){generation++;animation?.cancel();curtain.remove();delete document.documentElement.dataset.routeTransition}
 };
}
