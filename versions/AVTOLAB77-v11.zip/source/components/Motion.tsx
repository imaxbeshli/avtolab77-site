'use client';
import {useEffect,useState} from 'react';
let introPlayed=false;
export function Motion(){
 const [intro,setIntro]=useState(false);
 useEffect(()=>{
  const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const play=!introPlayed&&!reduced;
  introPlayed=true;
  setIntro(play);
  const timer=setTimeout(()=>setIntro(false),2200);
  const nodes=document.querySelectorAll('.home-scene .section-head,.direction,.service-card,.digital-grid a,.project-card,.studio-intro,.fact,.consult');
  if(reduced||!('IntersectionObserver' in window))return()=>clearTimeout(timer);
  const animations:Animation[]=[];
  const index=new Map<Element,number>();
  const groups=new Map<Element,number>();
  nodes.forEach(el=>{
   const group=el.closest('section')||el.parentElement!;
   const order=groups.get(group)||0;groups.set(group,order+1);index.set(el,order);
   el.classList.add('reveal','motion-pending');el.setAttribute('data-reveal-state','pending');
  });
  const observer=new IntersectionObserver(entries=>entries.forEach(e=>{
   if(!e.isIntersecting)return;
   const el=e.target as HTMLElement;observer.unobserve(el);
   el.classList.remove('motion-pending');el.setAttribute('data-reveal-state','running');
   const animation=el.animate([{opacity:0,translate:'0 22px'},{opacity:1,translate:'0 0'}],{duration:850,delay:Math.min(index.get(el)||0,5)*140,easing:'cubic-bezier(.22,.7,.25,1)',fill:'backwards'});
   animations.push(animation);
   animation.onfinish=()=>{el.classList.add('revealed');el.setAttribute('data-reveal-state','complete')};
  }),{threshold:.12,rootMargin:'0px 0px -36px 0px'});
  const start=setTimeout(()=>nodes.forEach(el=>observer.observe(el)),play?2050:80);
  return()=>{clearTimeout(timer);clearTimeout(start);observer.disconnect();animations.forEach(a=>a.cancel());nodes.forEach(el=>{el.classList.remove('reveal','revealed','motion-pending');el.removeAttribute('data-reveal-state')})};
 },[]);
 return intro?<div className="intro" aria-hidden="true"><div className="intro-brand"><div className="logo-art"/><span className="intro-rule"/></div></div>:null;
}
export function useRail(){useEffect(()=>{const rail=document.querySelector<HTMLElement>('.service-rail');if(!rail)return;let x=0,start=0,down=false,moved=false;const wheel=(e:WheelEvent)=>{if(e.ctrlKey||rail.scrollWidth<=rail.clientWidth)return;const delta=Math.abs(e.deltaX)>Math.abs(e.deltaY)?e.deltaX:e.deltaY;const end=rail.scrollWidth-rail.clientWidth;if((delta<0&&rail.scrollLeft<=0)||(delta>0&&rail.scrollLeft>=end-1))return;e.preventDefault();rail.scrollLeft+=delta};const press=(e:PointerEvent)=>{if(e.pointerType!=='mouse'||e.button!==0)return;down=true;moved=false;x=e.clientX;start=rail.scrollLeft};const move=(e:PointerEvent)=>{if(!down)return;if(Math.abs(e.clientX-x)>5){moved=true;rail.scrollLeft=start+x-e.clientX;e.preventDefault()}};const up=()=>{down=false};const click=(e:MouseEvent)=>{if(moved){e.preventDefault();e.stopPropagation();moved=false}};const drag=(e:DragEvent)=>e.preventDefault();rail.addEventListener('wheel',wheel,{passive:false});rail.addEventListener('pointerdown',press);window.addEventListener('pointermove',move);window.addEventListener('pointerup',up);rail.addEventListener('click',click,true);rail.addEventListener('dragstart',drag);return()=>{rail.removeEventListener('wheel',wheel);rail.removeEventListener('pointerdown',press);window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',up);rail.removeEventListener('click',click,true);rail.removeEventListener('dragstart',drag)}},[])}
