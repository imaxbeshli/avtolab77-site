export const models=[
  {id:'9x',brand:'zeekr',name:'ZEEKR 9X',tile:0},
  {id:'8x',brand:'zeekr',name:'ZEEKR 8X',tile:1},
  {id:'900',brand:'lynk-co',name:'Lynk & Co 900',tile:2},
];
export const projects=[{slug:'protection',title:'Защита без компромиссов',category:'Антигравийная защита',tile:2,description:'Прозрачная защита, которая сохраняет характер автомобиля.'},{slug:'red',title:'Цвет в каждой детали',category:'Индивидуальный стиль',tile:3,description:'Глубокий цвет, выразительные линии и внимание к каждой детали.'},{slug:'polish',title:'Безупречный блеск',category:'Полировка и керамика',tile:4,description:'Глубина цвета и чистота отражения в лакокрасочном покрытии.'},{slug:'digital',title:'Новый уровень комфорта',category:'Цифровые решения',tile:1,description:'Современные возможности в привычном интерьере автомобиля.'}];
export const serviceTiles:Record<string,number>={ppf:2,polishing:4,tinting:5,glass:5,pdr:0,soundproofing:1,firmware:1,tcam:1,number:1,account:1,sim:1,apps:1};

export const pageInfo:Record<string,[string,string]>={about:['О студии AVTOLAB77','С 2009 года мы объединяем заботу о внешнем виде автомобиля и современные технологии.'],contacts:['Будем на связи','Обсудим ваш автомобиль и подберём решение под ваши задачи.'],projects:['Наши проекты','Внимание к деталям. Выразительный стиль. Продуманные решения.'],privacy:['Конфиденциальность','Сейчас вы смотрите демонстрационную версию сайта.'],consent:['Обработка персональных данных','Форма работает в демонстрационном режиме.']};
