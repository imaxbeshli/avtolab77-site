export const studio = {
 address: 'Москва, ул. Ермакова Роща, д. 7А, строение 2',
 hours: 'Пн–Сб, с 10:00 до 19:00',
 mapUrl: 'https://yandex.ru/maps/org/avtolab77/98750739355/?ll=37.529655%2C55.758210&z=16.69',
 mapEmbed: 'https://yandex.ru/map-widget/v1/?oid=98750739355&ol=biz&z=16',
};
// Route to the supplied street address, not to the viewport centre in the map URL.
export const studioRoute = 'https://yandex.ru/maps/?rtext=~'+encodeURIComponent(studio.address)+'&rtt=auto';
export const bookingServices = [
 ['ppf','Антигравийная защита'],
 ['polishing','Полировка кузова'],
 ['tinting','Тонирование стекол'],
 ['glass','Бронирование стекол'],
 ['pdr','Удаление вмятин'],
 ['soundproofing','Шумоизоляция'],
 ['firmware','Русификация'],
 ['other','Другое'],
] as const;
