'use client';
import {useEffect,useRef,useState} from 'react';
import type {Map as LibreMap} from 'maplibre-gl';
import {studio} from '../content/studio';
import {studioCoordinates,studioMapBounds,studioMapStyle} from '../content/studio-map';

export function LocationMap({active}:{active:boolean}){
 const container=useRef<HTMLDivElement>(null);
 const [status,setStatus]=useState<'loading'|'ready'|'error'>('loading');
 const [attempt,setAttempt]=useState(0);
 useEffect(()=>{
  if(!active||!container.current)return;
  let cancelled=false,map:LibreMap|undefined,observer:ResizeObserver|undefined,attributionObserver:MutationObserver|undefined,workerUrl:string|undefined,timer:ReturnType<typeof setTimeout>|undefined;
  let rendered=false;
  setStatus('loading');
  const start=async()=>{
   try{
    const [lib,worker]=await Promise.all([import('maplibre-gl'),import('../content/map-worker.generated.json')]);
    if(cancelled)return;
    workerUrl=URL.createObjectURL(new Blob([worker.default.code],{type:'text/javascript'}));
    lib.setWorkerUrl(workerUrl);lib.setWorkerCount(1);
    map=new lib.Map({container:container.current!,style:studioMapStyle(),center:studioCoordinates,zoom:14,minZoom:10,maxZoom:19,
     attributionControl:false,scrollZoom:false,dragRotate:false,pitchWithRotate:false,touchPitch:false,
     locale:{'NavigationControl.ZoomIn':'Приблизить карту','NavigationControl.ZoomOut':'Отдалить карту','AttributionControl.ToggleAttribution':'Источники карты'}});
    map.touchZoomRotate.disableRotation();
    map.getCanvas().setAttribute('aria-label','Карта расположения Автолаб77. Перемещение стрелками, масштаб клавишами плюс и минус.');
    map.addControl(new lib.NavigationControl({showCompass:false}),'top-right');
    map.addControl(new lib.AttributionControl({compact:true}),'bottom-left');
    // v6 expands attribution initially; collapse it once, without changing its links or later user choices.
    const collapseInitialAttribution=()=>{
     const control=container.current?.querySelector('details.maplibregl-ctrl-attrib');
     if(!control||control.classList.contains('maplibregl-attrib-empty'))return;
     if(control.classList.contains('maplibregl-compact-show'))control.querySelector('summary')?.click();
     attributionObserver?.disconnect();
    };
    attributionObserver=new MutationObserver(collapseInitialAttribution);
    attributionObserver.observe(container.current!,{subtree:true,childList:true,attributes:true,attributeFilter:['class']});
    collapseInitialAttribution();
    const marker=document.createElement('div');marker.className='studio-map-marker';marker.setAttribute('role','img');marker.setAttribute('aria-label','Автолаб77');
    const label=document.createElement('span');label.textContent='АВТОЛАБ77';marker.append(label);
    new lib.Marker({element:marker,anchor:'bottom'}).setLngLat(studioCoordinates).addTo(map);
    map.fitBounds(studioMapBounds,{padding:{top:38,bottom:34,left:18,right:34},duration:0,maxZoom:15});
    observer=new ResizeObserver(()=>map?.resize());observer.observe(container.current!);
    // A load/idle event can also follow failed tiles: require actual visible map geometry.
    const ready=()=>{
     if(cancelled||!map?.isStyleLoaded())return;
     if(map.queryRenderedFeatures(undefined,{layers:['roads','buildings','water']}).length){rendered=true;setStatus('ready');if(timer)clearTimeout(timer)}
    };
    map.on('idle',ready);map.on('error',()=>{ /* Keep transient tile failures from covering a usable map. */ });
    timer=setTimeout(()=>{if(!cancelled&&!rendered)setStatus('error')},15000);
   }catch{if(!cancelled)setStatus('error')}
  };
  start();
  return ()=>{cancelled=true;if(timer)clearTimeout(timer);observer?.disconnect();attributionObserver?.disconnect();map?.remove();if(workerUrl)URL.revokeObjectURL(workerUrl)};
 },[active,attempt]);
 return <div className="booking-map booking-map-libre" data-map-status={status}>
  <div ref={container} className="studio-map-canvas"/>
  {active&&status==='loading'&&<div className="studio-map-loading" role="status">Загружаем карту…</div>}
  {active&&status==='error'&&<div className="studio-map-error" role="status"><p>Карта временно недоступна</p><button type="button" onClick={()=>setAttempt(a=>a+1)}>Повторить</button><a href={studio.mapUrl} target="_blank" rel="noopener noreferrer">Открыть карту</a></div>}
 </div>;
}
