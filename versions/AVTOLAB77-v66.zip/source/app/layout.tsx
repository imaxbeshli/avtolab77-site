import type { Metadata } from 'next';
import 'maplibre-gl/dist/maplibre-gl.css';
import './globals.css';
import '../styles/studio.css';
export const metadata: Metadata={title:'AVTOLAB77 — автостайлинг и цифровые решения',description:'Защита, уход и цифровые решения для вашего автомобиля.',robots:{index:false,follow:false}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="ru"><body>{children}</body></html>}
