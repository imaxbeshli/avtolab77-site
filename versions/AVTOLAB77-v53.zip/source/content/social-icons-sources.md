# Social marks, v47
Telegram, VK, YouTube, Instagram: Simple Icons, CC0, via @iconify-json/simple-icons 1.2.101.
https://github.com/simple-icons/simple-icons
MAX Messenger: Arcticons max-messenger, CC BY-SA 4.0, via @iconify-json/arcticons 1.2.59. Stroke adjusted for the 22px header display; shape unchanged.
https://github.com/Arcticons-Team/Arcticons
https://creativecommons.org/licenses/by-sa/4.0/
All marks use currentColor. No external runtime icon requests.
Links retain the existing /contacts destination until studio account URLs are supplied.

## v53 update
MAX: the white even-odd vector glyph from @alex_rexby/n8n-nodes-max 0.4.43, dist/nodes/Max/max.svg (MIT package). Only the vector mark is reused; the bitmap gradient background is excluded. The viewBox crops unused padding. https://www.npmjs.com/package/@alex_rexby/n8n-nodes-max
Telegram: existing Simple Icons glyph extracted from its enclosing disk and optically scaled. Other Simple Icons glyphs retained, with consistent white rendering and optical sizes.
