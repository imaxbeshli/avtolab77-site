import {heroArtwork} from './HeroLights';
// Extract only the existing red contours: the exact approved 77 shape is retained.
const redOnly='0 0 0 0 1  0 0 0 0 .065  0 0 0 0 .12  3 -1.5 -1.5 0 -.035';
export function HeroNeon(){return <svg className="hero-neon77" viewBox="0 0 1678 937" aria-hidden="true" focusable="false">
 <defs>
  <image id="neon77-source" href={heroArtwork} width="1678" height="937"/>
  <linearGradient id="neon77-distance" x1="0" y1="140" x2="0" y2="490" gradientUnits="userSpaceOnUse"><stop stopColor="white" stopOpacity="0"/><stop offset=".045" stopColor="white"/><stop offset=".28" stopColor="white" stopOpacity=".85"/><stop offset=".65" stopColor="white" stopOpacity=".15"/><stop offset="1" stopColor="white" stopOpacity="0"/></linearGradient>
  <linearGradient id="neon77-horizontal" x1="450" y1="0" x2="1250" y2="0" gradientUnits="userSpaceOnUse"><stop stopColor="white" stopOpacity="0"/><stop offset=".17" stopColor="white"/><stop offset=".86" stopColor="white"/><stop offset="1" stopColor="white" stopOpacity="0"/></linearGradient>
  <mask id="neon77-sides" maskUnits="userSpaceOnUse" x="0" y="0" width="1678" height="937" style={{maskType:'luminance'}}><rect width="1678" height="937" fill="url(#neon77-horizontal)"/></mask>
  <mask id="neon77-depth" maskUnits="userSpaceOnUse" x="0" y="0" width="1678" height="937" style={{maskType:'luminance'}}><rect width="1678" height="937" fill="url(#neon77-distance)" mask="url(#neon77-sides)"/></mask>
  <filter id="neon77-core" filterUnits="userSpaceOnUse" x="0" y="0" width="1678" height="937" colorInterpolationFilters="sRGB"><feColorMatrix type="matrix" values={redOnly}/></filter>
  <filter id="neon77-close" filterUnits="userSpaceOnUse" x="0" y="0" width="1678" height="937" colorInterpolationFilters="sRGB"><feColorMatrix type="matrix" values={redOnly}/><feGaussianBlur stdDeviation="3"/></filter>
  <filter id="neon77-aura" filterUnits="userSpaceOnUse" x="0" y="0" width="1678" height="937" colorInterpolationFilters="sRGB"><feColorMatrix type="matrix" values={redOnly}/><feGaussianBlur stdDeviation="12"/></filter>
 </defs>
 <g mask="url(#neon77-depth)" className="neon77-breathe">
  <use href="#neon77-source" filter="url(#neon77-aura)" opacity=".5"/>
  <use href="#neon77-source" filter="url(#neon77-close)" opacity=".5"/>
  <use href="#neon77-source" filter="url(#neon77-core)" opacity=".7"/>
 </g>
</svg>}
