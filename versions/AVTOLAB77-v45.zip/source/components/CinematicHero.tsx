'use client';
import {Atmosphere} from './Atmosphere';
/** Live, selectable typography over the restored photographic scene. */
export function CinematicHero(){return <section className="hero approved-hero pavilion-hero"><div className="hero-image approved-image"><img className="approved-artwork" src="/assets/hero-clean-v44.webp" alt="Rolls-Royce и ZEEKR в тёмном павильоне, светящиеся цифры 77 в глубине" fetchPriority="high"/><h1 className="hero-text-title"><span className="hero-text-main">Премиальное решение</span>{' '}<span className="hero-text-sub">для вашего автомобиля</span></h1><Atmosphere/></div></section>}
