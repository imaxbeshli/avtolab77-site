/** Rear haze is local to the distant sign; no traced masks around vehicle bodies. */
export function RearAtmosphere(){return null}
export function Studio77(){return <svg className="hero-seventy-seven" viewBox="0 0 600 360" aria-hidden="true"><defs>
 <filter id="sign-halo" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="5"/></filter>
 <filter id="sign-mist" x="-30%" y="-30%" width="160%" height="160%"><feTurbulence type="fractalNoise" baseFrequency=".012 .025" numOctaves="3" seed="9"/><feColorMatrix type="matrix" values="0 0 0 0 .21 0 0 0 0 .23 0 0 0 0 .25 1.4 0 0 0 -.43"/><feGaussianBlur stdDeviation="5"/></filter>
 <radialGradient id="mist-fade"><stop stopColor="white"/><stop offset=".65" stopColor="white" stopOpacity=".55"/><stop offset="1" stopColor="white" stopOpacity="0"/></radialGradient>
 <mask id="mist-boundary"><rect width="600" height="360" fill="url(#mist-fade)"/></mask>
 <path id="studio-seven-shape" d="M58 20H285L135 300H69L190 82H27Z M322 20H549L399 300H333L454 82H291Z"/>
 </defs><g className="studio-sign"><use href="#studio-seven-shape" className="sign-bloom" filter="url(#sign-halo)"/><use href="#studio-seven-shape" className="sign-outline"/></g>
 <g mask="url(#mist-boundary)"><g className="sign-haze"><rect x="-70" y="35" width="740" height="300" filter="url(#sign-mist)"/></g></g>
 </svg>}
