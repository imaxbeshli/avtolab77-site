'use client';
import {useEffect,useRef} from 'react';
export const heroArtwork='/assets/hero-clean-v46.webp';
const rrLenses='M462 578 L528 579 L532 612 L464 611 Z M681 579 L720 582 L726 614 L685 617 Z';
const zeekrLenses='M923 569 L973 573 L1128 571 L1234 565 L1227 579 L1132 582 L961 583 L921 580 Z M916 594 L933 593 L933 655 L914 657 Z M1188 591 L1215 590 L1218 656 L1188 658 Z';
/** Pixel-aligned light layers; the approved photograph is never regenerated. */
export function HeroLights(){
 const root=useRef<HTMLDivElement>(null);
 useEffect(()=>{
  const el=root.current;if(!el)return;
  const reduce=matchMedia('(prefers-reduced-motion: reduce)');
  let frame=0,elapsed=0,last=0,started=false,disposed=false;
  const layers=(['rr','zeekr'] as const).map(car=>({car,off:el.querySelector<SVGSVGElement>(`[data-off="${car}"]`)!,glow:el.querySelector<SVGSVGElement>(`[data-glow="${car}"]`)!,light:-1,halo:-1}));
  const clamp=(n:number)=>Math.max(0,Math.min(1,n));
  const smooth=(n:number)=>{n=clamp(n);return n*n*(3-2*n)};
  const paint=(time:number)=>{
   for(const layer of layers){
    const delay=layer.car==='rr'?1500:2000;
    const light=smooth((time-delay)/400),glow=smooth((time-delay-70)/450);
    // Change only composited root opacity; keep the filtered SVG pixels static.
    if(layer.light!==light){layer.off.style.opacity=String(1-light);layer.light=light;el.dataset[layer.car]=light.toFixed(4)}
    if(layer.halo!==glow){layer.glow.style.opacity=String(glow);layer.halo=glow}
   }
   el.dataset.elapsed=String(Math.round(time));
  };
  const tick=(now:number)=>{
   if(disposed)return;
   if(!document.hidden)elapsed+=Math.min(64,now-last);
   last=now;paint(elapsed);
   if(elapsed<2550)frame=requestAnimationFrame(tick);else{frame=0;el.dataset.state='on'}
  };
  const start=async()=>{
   if(started||disposed)return;started=true;
   const image=el.closest('.hero-image')?.querySelector<HTMLImageElement>('.approved-artwork');
   try{await image?.decode()}catch{}
   if(disposed)return;
   el.dataset.startedAt=String(performance.now());
   if(reduce.matches){paint(2550);el.dataset.state='on';return}
   el.dataset.state='waiting';last=performance.now();frame=requestAnimationFrame(tick);
  };
  const motionChange=()=>{if(reduce.matches){cancelAnimationFrame(frame);frame=0;paint(2550);el.dataset.state='on'}};
  paint(0);el.dataset.state='off';
  window.addEventListener('avtolab:title-ready',start);reduce.addEventListener('change',motionChange);
  if(reduce.matches||el.closest<HTMLElement>('.hero-image')?.dataset.titleReady==='true')void start();
  return()=>{disposed=true;cancelAnimationFrame(frame);window.removeEventListener('avtolab:title-ready',start);reduce.removeEventListener('change',motionChange)};
 },[]);
 return <div ref={root} className="hero-headlights" aria-hidden="true">
  {(['rr','zeekr'] as const).map(car=>{const rr=car==='rr';return <svg key={car} data-off={car} className="hero-light-layer" viewBox="0 0 1678 937" focusable="false">
   <defs>
    <filter id={`${car}-lens-edge`} x="-5%" y="-5%" width="110%" height="110%"><feGaussianBlur stdDeviation="1.1"/></filter>
    <filter id={`${car}-reflection-edge`} x="-50%" y="-40%" width="200%" height="180%"><feGaussianBlur stdDeviation="12"/></filter>
    <filter id={`${car}-unlit`} filterUnits="userSpaceOnUse" x={rr?430:890} y={rr?560:550} width={rr?320:360} height={rr?377:387} colorInterpolationFilters="sRGB"><feComponentTransfer><feFuncR type="linear" slope=".12"/><feFuncG type="linear" slope=".14"/><feFuncB type="linear" slope=".16"/></feComponentTransfer></filter>
    <mask id={`${car}-light-mask`} maskUnits="userSpaceOnUse" x="0" y="0" width="1678" height="937" style={{maskType:'luminance'}}>
     <path d={rr?rrLenses:zeekrLenses} fill="white" filter={`url(#${car}-lens-edge)`}/>
     <g fill="white" opacity={rr ? .45 : .4} filter={`url(#${car}-reflection-edge)`}>{rr?<><ellipse cx="500" cy="854" rx="24" ry="67"/><ellipse cx="698" cy="840" rx="17" ry="55"/></>:<><ellipse cx="926" cy="843" rx="17" ry="53"/><ellipse cx="1202" cy="851" rx="24" ry="65"/></>}</g>
    </mask>
   </defs>
   <image href={heroArtwork} width="1678" height="937" filter={`url(#${car}-unlit)`} mask={`url(#${car}-light-mask)`}/>
  </svg>})}
  {(['rr','zeekr'] as const).map(car=><svg key={car} data-glow={car} className="hero-light-layer" style={{opacity:0}} viewBox="0 0 1678 937" focusable="false">
   <defs>
    <radialGradient id={`${car}-lens-glow`}><stop stopColor="#dcefff" stopOpacity=".17"/><stop offset=".35" stopColor="#dcefff" stopOpacity=".07"/><stop offset="1" stopColor="#dcefff" stopOpacity="0"/></radialGradient>
    <radialGradient id={`${car}-floor-glow`}><stop stopColor="#cde7ff" stopOpacity=".075"/><stop offset="1" stopColor="#cde7ff" stopOpacity="0"/></radialGradient>
   </defs>
   <g fill={`url(#${car}-lens-glow)`}>{car==='rr'?<><ellipse cx="496" cy="597" rx="54" ry="29"/><ellipse cx="705" cy="599" rx="34" ry="25"/></>:<><ellipse cx="926" cy="625" rx="28" ry="48"/><ellipse cx="1203" cy="625" rx="35" ry="52"/><ellipse cx="1070" cy="576" rx="161" ry="15"/></>}</g>
   <g fill={`url(#${car}-floor-glow)`}>{car==='rr'?<><ellipse cx="500" cy="847" rx="44" ry="79"/><ellipse cx="698" cy="835" rx="30" ry="65"/></>:<><ellipse cx="926" cy="843" rx="32" ry="63"/><ellipse cx="1202" cy="851" rx="40" ry="73"/></>}</g>
  </svg>)}
 </div>;
}
