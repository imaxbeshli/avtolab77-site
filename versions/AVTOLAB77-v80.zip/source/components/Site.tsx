'use client';
import {useRef,useState,useId,useEffect,useLayoutEffect,type ReactNode,type CSSProperties} from 'react';
import {ArrowRight,ChevronLeft,ChevronRight,ChevronDown,Shield,Cpu,X,Check,Phone,Send,Instagram,Youtube,MapPin,Clock} from 'lucide-react';
import {services} from '../content/services';
import {models,projects,serviceTiles,pageInfo} from '../content/site';
import {restoreServicePosition,resetHomeEntry,takeServiceReturnIntent} from './service-navigation';
import {ProjectArticle} from './ProjectArticle';
import {ServiceArticle} from './ServiceArticle';
import {servicePages} from '../content/service-pages';
import {digitalPages} from '../content/digital-pages';
import {SocialMarks} from './SocialMarks';
import {BookingLocation} from './BookingLocation';
import {bookingServices,studio} from '../content/studio';
import {CinematicHero} from './CinematicHero';
import {Motion,useRail} from './Motion';
import {VehicleSelector} from './VehicleSelector';
import {StylingTransformation} from './StylingTransformation';
import {DigitalTransformation} from './DigitalTransformation';
export function Art({tile=0,className='',children}:{tile?:number,className?:string,children?:ReactNode}){return <div className={'art tile-'+tile+' '+className} style={{'--tile-x':`${tile%3*50}%`,'--tile-y':tile<3?'0%':'100%'} as CSSProperties}>{children}</div>}
export function Logo(){return <a className="logo brand-logo" href="/" aria-label="AVTOLAB77 — главная"><span className="logo-art" role="img" aria-label="AVTOLAB77 — студия премиум автостайлинга"/></a>}
export function Socials(){return <SocialMarks/>}
export function Header(){
  return <>
    <svg width="0" height="0" aria-hidden="true" focusable="false" style={{position:'absolute',pointerEvents:'none'}}><defs><filter id="header-logo-alpha" colorInterpolationFilters="sRGB"><feColorMatrix type="matrix" values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 1 1 1 0 -0.04"/><feColorMatrix type="matrix" values=".60 .40 0 0 0 .070 .930 0 0 0 .008 -.008 1 0 0 0 0 0 1 0"/></filter></defs></svg>
    <a className="skip" href="#main">К содержимому</a>
    <header className="header">
      <div className="header-inner">
        <Logo/>
        <div className="header-social"><Socials/></div>
        <div className="header-book"><Booking/></div>
      </div>
    </header>
  </>;
}
export function Booking({label='Записаться',context='Консультация',className=''}:{label?:string,context?:string,className?:string}){
 const ref=useRef<HTMLDialogElement>(null);
 const [formSession,setFormSession]=useState(0);
 const [opened,setOpened]=useState(false);
 const titleId=useId();
 const [service,setService]=useState(''),[unavailable,setUnavailable]=useState(false);
 const motion=useRef<Animation|null>(null);
 const returnPoint=useRef<{x:number;y:number;trigger:HTMLElement|null}|null>(null);
 const restoreSite=()=>{
  const saved=returnPoint.current;if(!saved)return;returnPoint.current=null;
  if(!document.querySelector('dialog[open]')){
   document.body.classList.remove('dialog-open');document.documentElement.classList.remove('dialog-open');
   window.scrollTo({left:saved.x,top:saved.y,behavior:'instant'});
   if(saved.trigger?.isConnected)saved.trigger.focus({preventScroll:true});
  }
 };
 useEffect(()=>()=>{
  motion.current?.cancel();ref.current?.close();returnPoint.current=null;
  // Route changes own their scroll position; only release the dialog lock on unmount.
  if(!document.querySelector('dialog[open]')){document.body.classList.remove('dialog-open');document.documentElement.classList.remove('dialog-open')}
 },[]);
 const finishClose=()=>{
  ref.current?.close();motion.current?.cancel();motion.current=null;
  setOpened(false);restoreSite();
 };
 const close=()=>{
  const dialog=ref.current;if(!dialog?.open||dialog.dataset.state==='closing')return;
  const style=getComputedStyle(dialog);
  const from={opacity:style.opacity,transform:style.transform};
  dialog.style.setProperty('--booking-backdrop-from',getComputedStyle(dialog,'::backdrop').opacity);
  dialog.dataset.state='closing';motion.current?.cancel();
  if(matchMedia('(prefers-reduced-motion: reduce)').matches){finishClose();return}
  const animation=dialog.animate([from,{opacity:0,transform:'translateY(12px) scale(.99)'}],{duration:360,easing:'cubic-bezier(.4,0,.2,1)',fill:'both'});
  motion.current=animation;
  animation.finished.then(()=>{if(motion.current===animation)finishClose()}).catch(()=>{});
 };
 const open=()=>{
  const dialog=ref.current;if(!dialog||dialog.open)return;
  returnPoint.current={x:window.scrollX,y:window.scrollY,trigger:document.activeElement instanceof HTMLElement?document.activeElement:null};
  setFormSession(value=>value+1);setUnavailable(false);
  const matching=services.find(item=>item.title===context);
  setService(matching?(matching.direction==='digital'?'firmware':matching.slug):(bookingServices.find(([,title])=>title===context)?.[0]??''));
  dialog.dataset.state='open';dialog.style.removeProperty('--booking-backdrop-from');
  document.body.classList.add('dialog-open');document.documentElement.classList.add('dialog-open');
  dialog.showModal();
  const scroll=dialog.querySelector('.booking-scroll');if(scroll)scroll.scrollTop=0;
  if(matchMedia('(prefers-reduced-motion: reduce)').matches){setOpened(true);return}
  // Start costly map initialization after the panel has finished appearing.
  const animation=dialog.animate([{opacity:0,transform:'translateY(18px) scale(.985)'},{opacity:1,transform:'none'}],{duration:480,easing:'cubic-bezier(.22,1,.36,1)',fill:'both'});
  motion.current=animation;
  animation.finished.then(()=>{
   if(motion.current!==animation||!dialog.open||!dialog.isConnected)return;
   animation.cancel();motion.current=null;setOpened(true);
  }).catch(()=>{});
 };
 return <>
  <button className={'primary '+className} onClick={open}>{label}</button>
  <dialog ref={ref} className="booking-dialog" aria-labelledby={titleId} onClose={()=>{motion.current?.cancel();motion.current=null;setOpened(false);restoreSite()}} onCancel={event=>{event.preventDefault();close()}} onClick={event=>{
   if(event.target!==ref.current)return;
   const box=event.currentTarget.getBoundingClientRect();
   if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)close();
  }}>
   <div className="booking-toolbar"><button type="button" className="close" aria-label="Закрыть форму" onClick={close}><X/></button></div>
   <div className="booking-scroll"><div className="booking-layout"><section className="booking-form-column">
   <h2 id={titleId} tabIndex={-1} autoFocus>Запись на услугу</h2>
   <form key={formSession} onInput={()=>setUnavailable(false)} onSubmit={event=>{
    event.preventDefault();
    const phone=event.currentTarget.elements.namedItem('phone') as HTMLInputElement;
    const digits=phone.value.replace(/\D/g,'');
    if(digits.length<10||digits.length>15){phone.setCustomValidity('Введите номер телефона: от 10 до 15 цифр.');phone.reportValidity();return}
    // No delivery endpoint is configured. Never claim that an unsent request was received.
    setUnavailable(true);
   }}>
    <div className="form-row">
     <label><span className="visually-hidden">Введите ваше имя</span><input name="name" required placeholder="Введите ваше имя" autoComplete="given-name" maxLength={80}/></label>
     <label><span className="visually-hidden">Номер телефона</span><input name="phone" required type="tel" inputMode="tel" autoComplete="tel" maxLength={24} placeholder="Номер телефона" onInput={event=>event.currentTarget.setCustomValidity('')}/></label>
    </div>
    <label className="booking-service"><span className="visually-hidden">Что вас интересует?</span>
     <select name="service" required value={service} onChange={event=>{setService(event.target.value);setUnavailable(false)}}>
      <option value="" disabled>Что вас интересует?</option>
      {bookingServices.map(([value,title])=><option key={value} value={value}>{title}</option>)}
     </select><ChevronDown size={18} aria-hidden="true"/>
    </label>
    {service==='other'&&<label><span className="visually-hidden">Ваш вопрос или пожелание</span><textarea name="comment" required rows={3} maxLength={1000} placeholder="Напишите, что вас интересует"/></label>}
    <button type="submit" className="primary booking-submit">Подать заявку</button>
    {unavailable&&<p className="booking-status" role="status">Отправка заявки пока не подключена. <a href="https://t.me/AVTOLAB77" target="_blank" rel="noopener noreferrer">Свяжитесь с нами в Telegram</a>.</p>}
   </form>
   <div className="booking-socials"><p className="booking-socials-title">Удобнее написать?</p><SocialMarks/></div>
   </section><BookingLocation key={formSession} active={opened}/></div></div>
  </dialog>
 </>;
}

export function SectionTitle({children}:{children:ReactNode}){
  return <div className="section-head"><h2>{children}</h2></div>;
}
export function Consultation(){return <section className="consult"><div><h2>Обсудим ваш автомобиль</h2></div><div className="consult-actions"><Booking/></div></section>}

export function ProjectGrid({compact=false}:{compact?:boolean}){
  return <div className={compact?'projects-rail':'projects-grid'} tabIndex={compact?0:undefined} role={compact?'region':undefined} aria-label={compact?'Наши проекты — прокручиваемая лента':undefined}>
    {projects.map(p=><a className="project-card project-case-card" href={'/projects/'+p.slug} key={p.slug} aria-label={'Открыть проект: '+p.title}>
      <div className="project-card-image"><img src={p.thumbnail} alt={p.title} width={720} height={405} loading="lazy" draggable={false}/></div><h3>{p.title}</h3>
    </a>)}
  </div>;
}
export function Home({returnToServices=false}:{returnToServices?:boolean}){const[pendingReturn]=useState(takeServiceReturnIntent);const returning=returnToServices||pendingReturn;useRail();useLayoutEffect(()=>{const position=returning?restoreServicePosition:resetHomeEntry;position();const frame=requestAnimationFrame(position);return()=>cancelAnimationFrame(frame)},[returning]);const rail=useRef<HTMLDivElement>(null);return <><Motion skipIntro={returning}/><Header/><main id="main" className="home-scene"><CinematicHero/><div className="container"><section className="section popular styling-panel" id="directions"><StylingTransformation><a className="section-entry" href="/services/styling"><SectionTitle>Автостайлинг и детейлинг</SectionTitle></a></StylingTransformation><div className="rail-wrap" id="service-cards"><div className="service-rail" ref={rail} tabIndex={0} role="region" aria-label="Услуги автостайлинга — прокручиваемая лента">{services.filter(s=>s.direction==='styling').map(s=><a className="service-card" href={'/services/styling/'+s.slug} key={s.slug}><Art tile={serviceTiles[s.slug]} className={s.slug==='glass'?'glass-art-v11':''}/><h3>{s.title}</h3></a>)}</div></div></section><section className="section digital-section digital-panel"><div className="digital-sequence"><div className="digital-pinned"><a className="section-entry" href="/services/digital"><SectionTitle>Русификация и цифровые решения</SectionTitle></a><DigitalTransformation/></div></div><VehicleSelector/></section><section className="section projects" id="project-cards"><SectionTitle>Наши проекты</SectionTitle><ProjectGrid compact/></section></div><section className="studio-section"><div className="container"><div className="studio"><div className="studio-facts"><div className="fact"><strong>{new Date().getFullYear()-2009} ЛЕТ</strong><p>опыта</p></div><div className="fact"><strong>10 000+</strong><p>автомобилей прошли через нас</p></div><div className="fact materials"><strong>ПРЕМИАЛЬНЫЕ<br/>МАТЕРИАЛЫ</strong><p>от ведущих производителей</p></div><div className="fact guarantee"><strong>5 ЛЕТ</strong><p>гарантии на любое эксплуатационное повреждение</p></div></div></div><Consultation/></div></section></main></>}

export function Detail({path}:{path:string}){const clean=path.split('?')[0].replace(/^\/+|\/+$/g,'');const parts=clean.split('/');const service=parts[0]==='services'&&parts.length===3?services.find(s=>s.direction===parts[1]&&s.slug===parts[2]):undefined;const project=parts[0]==='projects'&&parts.length===2?projects.find(p=>p.slug===parts[1]):undefined;const model=parts[0]==='cars'?models.find(m=>m.id===parts[2]&&m.brand===parts[1]):undefined;const catalog=parts[0]==='services'&&parts.length<3;const valid=service||project||model||pageInfo[clean]||(catalog&&(!parts[1]||['styling','digital'].includes(parts[1])));const title=service?.title??project?.title??model?.name??(catalog?(parts[1]==='styling'?'Автостайлинг и детейлинг':parts[1]==='digital'?'Цифровые решения':'Услуги студии'):pageInfo[clean]?.[0]??'Страница не найдена');if(project)return <><Header/><ProjectArticle project={project} booking={<Booking context={project.title}/>}/></>;if(service?.direction==='digital'&&digitalPages[service.slug])return <><Header/><ServiceArticle page={digitalPages[service.slug]} booking={<Booking context={service.title}/>}/></>;if(service?.direction==='styling'&&servicePages[service.slug])return <><Header/><ServiceArticle page={servicePages[service.slug]} booking={<Booking context={service.title}/>}/></>;return <><Header/><main id="main" className="inner"><div className="container"><div className="breadcrumbs"><a href="/">Главная</a><ChevronRight size={12}/><span>{title}</span></div>{(service||project)?<><section className="detail-hero"><Art tile={service?serviceTiles[service.slug]:project!.tile}/><div className="detail-shade"/><div className="detail-hero-content"><span className="eyebrow">{service?(service.direction==='styling'?'АВТОСТАЙЛИНГ И ДЕТЕЙЛИНГ':'ЦИФРОВЫЕ РЕШЕНИЯ'):'ДЕМОНСТРАЦИЯ ПРОЕКТА'}</span><h1>{title}</h1><p>{service?.intro??project?.description}</p><Booking context={title} label="Обсудить мой автомобиль"/></div></section><div className="detail-columns"><div><span className="eyebrow">ИНДИВИДУАЛЬНЫЙ ПОДХОД</span><h2>Продумано<br/>для вашего автомобиля.</h2><p>{service?'Каждый автомобиль и каждая задача требуют своего решения. На консультации обсудим ваши пожелания, оценим возможности и согласуем объём работ.':'Этот раздел показывает, как будет выглядеть история проекта. Сейчас здесь сгенерированная визуализация; реальные автомобили, фотографии и описание работ добавим при наполнении.'}</p><div className="feature-list"><span><Check/> Подбор под ваши задачи</span><span><Check/> Согласование деталей до начала работ</span><span><Check/> Внимание к результату</span></div></div><div className="faq"><h3>Частые вопросы</h3>{[['Как определяется стоимость?','Стоимость и сроки зависят от автомобиля, его состояния и выбранного объёма работ. Итоговые условия согласовываются после консультации.'],['Подойдёт ли услуга моему автомобилю?',service?.direction==='digital'?'Совместимость проверяется по модели, году выпуска и версии программного обеспечения. Демонстрационный каталог не подтверждает доступность услуги.':'Возможность и способ выполнения работ определяются индивидуально после оценки автомобиля.'],['Как записаться?', 'Откройте форму консультации. В текущей дизайн-версии можно проверить её заполнение; реальная отправка будет подключена после подтверждения контактных и юридических данных.']].map(([q,a])=><details key={q}><summary>{q}<ChevronDown size={16}/></summary><p>{a}</p></details>)}</div></div></>:<><span className="eyebrow">AVTOLAB77 / {catalog?'УСЛУГИ':'СТУДИЯ'}</span><h1 className="page-title">{title}</h1><p className="page-intro">{pageInfo[clean]?.[1]??(catalog?'Внешний вид, защита и новые возможности вашего автомобиля.':model?'Выберите направление для консультации. Совместимость требует проверки.':'Вернитесь на главную и выберите нужный раздел.')}</p>{catalog&&<><div className="filter-tabs"><a className={!parts[1]?'active':''} href="/services">Все направления</a><a className={parts[1]==='styling'?'active':''} href="/services/styling">Автостайлинг</a><a className={parts[1]==='digital'?'active':''} href="/services/digital">Цифровые решения</a></div>{parts[1]==='digital'&&<VehicleSelector/>}<div className="catalog-grid">{services.filter(s=>!parts[1]||s.direction===parts[1]).map(s=><a href={`/services/${s.direction}/${s.slug}`} className="catalog-card" key={s.slug}><Art tile={serviceTiles[s.slug]} className={s.slug==='glass'?'glass-art-v11':''}/><div><span className="eyebrow">{s.direction==='styling'?'ЗАЩИТА И СТИЛЬ':'ТЕХНОЛОГИИ'}</span><h2>{s.title}</h2><p>{s.intro}</p></div></a>)}</div></>}{clean==='projects'&&<><ProjectGrid/></>}{clean==='about'&&<><div className="about-image"/><div className="detail-columns"><div><h2>Ваш автомобиль.<br/>Наше внимание.</h2><p>Автостайлинг, детейлинг и цифровые решения объединены в одном пространстве. Для нас важны и внешний вид, и комфорт, и то, как автомобиль работает каждый день.</p></div><div className="about-values"><div><Shield/><h3>Защита и уход</h3><p>Продуманные решения для кузова и салона.</p></div><div><Cpu/><h3>Технологии и комфорт</h3><p>Настройка цифровых возможностей автомобиля.</p></div></div></div></>}{clean==='contacts'&&<div className="contact-grid"><div className="contact-card"><h2>Обсудим вашу задачу</h2><p>Оставьте информацию о вашем автомобиле в демонстрационной форме.</p><Booking label="Получить консультацию"/><div className="contact-item"><MapPin/><div><h3>Адрес студии</h3><p>{studio.address}</p></div></div><div className="contact-item"><Clock/><div><h3>Режим работы</h3><p>{studio.hours}</p></div></div><div className="contact-item"><Phone/><div><h3>Телефон и мессенджеры</h3><p>Контакты появятся после подтверждения</p></div></div></div><div className="contact-visual"><div className="map-grid"/><MapPin size={42}/><h3>Здесь начинается<br/>новая история вашего авто.</h3><span>AVTOLAB77</span></div></div>}{['privacy','consent'].includes(clean)&&<div className="legal"><h2>Демонстрационная версия</h2><p>Форма не передаёт введённые сведения на сервер и не сохраняет их. Аналитика и рекламные трекеры не подключены.</p><h2>Перед началом приёма заявок</h2><p>Здесь будут размещены согласованные юридические документы, сведения об операторе персональных данных и порядок обработки обращений.</p><a className="secondary" href="/">Вернуться на главную</a></div>}{model&&<VehicleSelector/>}{!valid&&<a className="primary" href="/">На главную</a>}</>}{valid&&!['privacy','consent'].includes(clean)&&<Consultation/>}</div></main></>}
