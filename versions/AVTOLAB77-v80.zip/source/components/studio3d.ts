import * as T from 'three';
import {RoundedBoxGeometry} from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import {RoomEnvironment} from 'three/examples/jsm/environments/RoomEnvironment.js';
import {Reflector} from 'three/examples/jsm/objects/Reflector.js';

/** Entirely geometric cars: no image planes, sprites or baked vehicle photographs. */
function createSUV(kind:'classic'|'electric'){
 const car=new T.Group();car.name=kind+'-suv';
 const paint=new T.MeshPhysicalMaterial({color:0x101317,metalness:.75,roughness:.32,clearcoat:1,clearcoatRoughness:.13});
 const chrome=new T.MeshStandardMaterial({color:0xaeb9c2,metalness:1,roughness:.32});
 const black=new T.MeshStandardMaterial({color:0x040506,roughness:.6});
 const rubber=new T.MeshStandardMaterial({color:0x08090a,roughness:.85});
 const glass=new T.MeshPhysicalMaterial({color:0x081018,metalness:.65,roughness:.12,clearcoat:1});
 const led=new T.MeshStandardMaterial({color:0xe4f5ff,emissive:0xc5eaff,emissiveIntensity:4});
 const red=new T.MeshStandardMaterial({color:0xff1730,emissive:0xff1025,emissiveIntensity:2});
 function box(name:string,w:number,h:number,d:number,x:number,y:number,z:number,mat:T.Material=paint,r=.05){
  const mesh=new T.Mesh(new RoundedBoxGeometry(w,h,d,2,Math.min(r,w/3,h/3,d/3)),mat);mesh.position.set(x,y,z);mesh.castShadow=['lower body','front hood','rear body','roof'].includes(name);mesh.receiveShadow=true;mesh.name=name;car.add(mesh);return mesh;
 }
 function quad(name:string,points:number[],mat:T.Material){const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(points,3));g.setIndex([0,1,2,0,2,3]);g.computeVertexNormals();const m=new T.Mesh(g,mat);m.name=name;car.add(m);return m}
 box('lower body',2.12,.68,4.72,0,.98,0,paint,.19);
 box('front hood',2.08,.23,1.59,0,1.43,1.52,paint,.12);
 box('rear body',2.1,.7,1.0,0,1.51,-1.82,paint,.12);
 box('roof',1.86,.14,2.63,0,2.08,-.65,paint,.07);
 // Cabin surfaces with a raked windshield; outward normals on all glass faces.
 quad('windshield',[-.91,2.01,.63,-1.01,1.56,1.07,1.01,1.56,1.07,.91,2.01,.63],glass);
 quad('rear glass',[.91,2.01,-1.95,1.01,1.61,-2.26,-1.01,1.61,-2.26,-.91,2.01,-1.95],glass);
 for(const side of [-1,1]){
  const pts=[side*1.018,1.57,1.02,side*.92,2.01,.6,side*.92,2.01,-1.92,side*1.018,1.57,-2.2];
  const q=quad('side glazing',pts,glass);if(side>0)q.geometry.setIndex([2,1,0,3,2,0]);q.geometry.computeVertexNormals();
  box('window sill',.035,.035,3.19,side*1.04,1.57,-.55,chrome,.008);
  box('roof rail',.035,.045,2.6,side*.91,2.18,-.65,chrome,.009);
  for(const z of [-1.42,-.46,.52])box('window pillar',.08,.45,.065,side*.975,1.80,z,paint,.015);
  const pillar=box('A pillar',.08,.64,.08,side*.97,1.80,.84,chrome,.02);pillar.rotation.x=-.52;
  box('mirror arm',.24,.055,.07,side*1.1,1.66,.63,black,.02);
  box('mirror housing',.3,.18,.31,side*1.24,1.74,.64,paint,.06);
  box('running board',.18,.065,2.85,side*1.05,.52,-.1,chrome,.02);
  for(const z of [-1.1,.25]){
   box('door handle',.035,.045,.24,side*1.075,1.44,z,chrome,.01);
   box('door seam',.008,.67,.012,side*1.065,1.05,z-.55,black,.003);
  }
  for(const z of [-1.57,1.57]){
   const wheel=new T.Group();wheel.position.set(side*1.03,.55,z);car.add(wheel);wheel.name='wheel';
   const tire=new T.Mesh(new T.TorusGeometry(.405,.14,12,40),rubber);tire.rotation.y=Math.PI/2;tire.castShadow=true;wheel.add(tire);
   const rim=new T.Mesh(new T.CylinderGeometry(.385,.385,.19,32),black);rim.rotation.z=Math.PI/2;wheel.add(rim);
   const ring=new T.Mesh(new T.TorusGeometry(.355,.023,6,40),chrome);ring.rotation.y=Math.PI/2;ring.position.x=side*.13;wheel.add(ring);
   for(let i=0;i<12;i++){
    const a=i*Math.PI/6;const spoke=new T.Mesh(new T.BoxGeometry(.035,.30,.037),chrome);spoke.position.set(side*.14,Math.cos(a)*.19,Math.sin(a)*.19);spoke.rotation.x=a;wheel.add(spoke);
   }
   const hub=new T.Mesh(new T.CylinderGeometry(.09,.09,.045,16),chrome);hub.rotation.z=Math.PI/2;hub.position.x=side*.16;wheel.add(hub);
   const brake=new T.Mesh(new T.BoxGeometry(.07,.26,.13),red);brake.position.set(side*.10,.04,.24);wheel.add(brake);
   const arch=new T.Mesh(new T.TorusGeometry(.59,.035,6,32,Math.PI),paint);arch.rotation.y=Math.PI/2;arch.rotation.z=Math.PI/2;arch.position.set(side*.06,.04,0);wheel.add(arch);
  }
 }
 box('front bumper',2.12,.23,.22,0,.59,2.38,paint,.08);
 box('lower intake',1.55,.14,.025,0,.68,2.51,black,.02);
 box('bumper chrome',1.96,.035,.03,0,.48,2.48,chrome,.01);
 const grilleW=kind==='classic'?1.12:1.52;
 box('grille frame',grilleW+.10,.93,.08,0,1.15,2.4,chrome,.05);
 box('grille dark core',grilleW,.85,.09,0,1.15,2.45,black,.025);
 for(let i=0;i<25;i++)box('vertical grille blade',.017,.79,.045,-grilleW/2+.035+i*(grilleW-.07)/24,1.15,2.51,chrome,.004);
 if(kind==='classic'){
  for(const side of [-1,1]){
   box('headlight surround',.55,.31,.06,side*.82,1.39,2.4,chrome,.055);
   box('headlight dark inset',.47,.24,.065,side*.82,1.39,2.44,black,.04);
   for(const yy of [1.30,1.48])box('headlight horizontal',.39,.025,.025,side*.82,yy,2.48,led,.01);
   for(const xx of [side*.82-.19,side*.82+.19])box('headlight vertical',.025,.18,.025,xx,1.39,2.48,led,.01);
  }
  box('hood center line',.012,.008,1.40,0,1.554,1.51,chrome,.003);
  const ornament=new T.Mesh(new T.ConeGeometry(.035,.16,5),chrome);ornament.position.set(0,1.65,2.14);car.add(ornament);
 }else{
  box('continuous light signature',1.94,.045,.04,0,1.64,2.33,led,.012);
  for(const side of [-1,1]){
   box('vertical headlight housing',.22,.62,.08,side*.94,1.13,2.4,black,.04);
   for(const yy of [.97,1.25])box('vertical light module',.105,.19,.04,side*.94,yy,2.47,led,.025);
  }
 }
 box('number plate',.62,.14,.03,0,.72,2.54,black,.01);
 box('tail signature',1.94,.045,.04,0,1.45,-2.39,red,.012);
 return car;
}

const fogFragment=`
precision highp float;
uniform sampler2D colorMap,depthMap;uniform mat4 inverseProjection,cameraWorld;uniform vec3 eye;uniform float time,lamp;
varying vec2 vUv;
float hash(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}
float noise3(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}
float density(vec3 p){vec3 q=p*vec3(.65,2.7,.65)+vec3(time*.16,0,time*.055);float n=noise3(q)*.62+noise3(q*2.1+3.)*.26+noise3(q*4.2)*.12;return smoothstep(.29,.70,n)*exp(-p.y*2.3 )*.17;}
void main(){vec3 base=texture2D(colorMap,vUv).rgb;float depth=texture2D(depthMap,vUv).x;vec4 p=inverseProjection*vec4(vUv*2.-1.,depth*2.-1.,1.);p/=p.w;vec3 hit=(cameraWorld*p).xyz;vec3 ray=normalize(hit-eye);float maxDist=min(length(hit-eye),35.);
 vec3 lo=(vec3(-12.,.03,-12.)-eye)/ray,hi=(vec3(12.,1.65,10.)-eye)/ray;vec3 mn=min(lo,hi),mx=max(lo,hi);float enter=max(0.,max(mn.x,max(mn.y,mn.z)));float leave=min(maxDist,min(mx.x,min(mx.y,mx.z)));float stepSize=max(0.,leave-enter)/16.;float trans=1.;vec3 scatter=vec3(0.);
 for(int i=0;i<16;i++){vec3 q=eye+ray*(enter+(float(i)+.5)*stepSize);float d=density(q)*stepSize;float side=exp(-abs(abs(q.x)-7.5)*.6);vec3 light=vec3(.27,.32,.38)+vec3(.75,.025,.04)*side*lamp;scatter+=trans*(1.-exp(-d))*light;trans*=exp(-d);}
 gl_FragColor=vec4(base*trans+scatter,1.);
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
}`;

export function mountStudio(host:HTMLDivElement){
 const renderer=new T.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1));renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFShadowMap;renderer.shadowMap.autoUpdate=false;renderer.shadowMap.needsUpdate=true;host.appendChild(renderer.domElement);
 const scene=new T.Scene();scene.background=new T.Color(0x050609);scene.fog=new T.FogExp2(0x080b10,.027);
 const camera=new T.PerspectiveCamera(43,1,.1,60);camera.position.set(0,3.2,11.8);camera.lookAt(0,1.9,0);
 const pmrem=new T.PMREMGenerator(renderer);const roomEnv=new RoomEnvironment();const environment=pmrem.fromScene(roomEnv,.05);scene.environment=environment.texture;scene.environmentIntensity=.32;roomEnv.dispose();pmrem.dispose();
 const classic=createSUV('classic');classic.position.set(-3.05,0,0);classic.rotation.y=-.38;scene.add(classic);
 const electric=createSUV('electric');electric.position.set(3.05,0,0);electric.rotation.y=.38;scene.add(electric);
 const wallMaterial=new T.MeshStandardMaterial({color:0x080a0d,metalness:.35,roughness:.65});
 function block(w:number,h:number,d:number,x:number,y:number,z:number,mat:T.Material){const m=new T.Mesh(new T.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);m.receiveShadow=true;scene.add(m);return m}
 block(18,8,.15,0,4,-7,wallMaterial);for(const side of [-1,1]){block(.15,8,22,side*8,4,1,wallMaterial);for(let z=-7;z<11;z+=2)block(.025,8,.025,side*7.91,4,z,new T.MeshStandardMaterial({color:0x020304}));}
 const reflector=new Reflector(new T.PlaneGeometry(40,60),{color:0x202830,textureWidth:768,textureHeight:768,clipBias:.003});reflector.rotation.x=-Math.PI/2;reflector.position.set(0,-.018,1);scene.add(reflector);
 const mirrorMat=reflector.material as T.ShaderMaterial;
 mirrorMat.fragmentShader=mirrorMat.fragmentShader.replace('vec4 base = texture2DProj( tDiffuse, vUv );', `vec2 uv=vUv.xy/vUv.w;float ripple=sin(uv.y*850.)*sin(uv.x*290.)*.0009;uv.x+=ripple;vec4 base=vec4(0.);for(int j=-2;j<=2;j++){base+=texture2D(tDiffuse,uv+vec2(float(j)*.0015,float(j)*.0008))*.2;}`);

 // Procedural wet-floor microtexture modulates roughness and surface normals.
 const size=128,data=new Uint8Array(size*size*4);let seed=77;for(let i=0;i<data.length;i+=4){seed=(seed*1664525+1013904223)>>>0;const v=80+(seed>>>24)*.35;data[i]=data[i+1]=data[i+2]=v;data[i+3]=255}const texture=new T.DataTexture(data,size,size);texture.wrapS=texture.wrapT=T.RepeatWrapping;texture.repeat.set(12,15);texture.needsUpdate=true;
 const floorMat=new T.MeshStandardMaterial({color:0x10151a,metalness:.5,roughness:.3,transparent:true,opacity:.5,bumpMap:texture,bumpScale:.025});const floor=new T.Mesh(new T.PlaneGeometry(40,60),floorMat);floor.rotation.x=-Math.PI/2;floor.receiveShadow=true;scene.add(floor);
 const ambient=new T.HemisphereLight(0xc4d9ed,0x101015,1.0);scene.add(ambient);
 const key=new T.DirectionalLight(0xe5f0ff,2.2);key.position.set(-3,7,4);key.castShadow=true;key.shadow.mapSize.set(1024,1024);Object.assign(key.shadow.camera,{left:-9,right:9,top:7,bottom:-7,near:.5,far:25});key.shadow.bias=-.0003;key.shadow.normalBias=.025;scene.add(key);
 const fill=new T.DirectionalLight(0xacc6e0,1.3);fill.position.set(5,5,-3);scene.add(fill);
 const strips:T.MeshStandardMaterial[]=[];const lights:T.PointLight[]=[];
 for(const side of [-1,1]){for(let level=0;level<3;level++){
  const material=new T.MeshStandardMaterial({color:0xff1231,emissive:0xff071b,emissiveIntensity:1.84});strips.push(material);block(.045,.027,16,side*7.87,1.8+level*.64,1,material);
  const light=new T.PointLight(0xff1028,5.6,15,1.4);light.position.set(side*7.1,1.8+level*.64,2-level*3);scene.add(light);lights.push(light);
 }}
 // Soft overhead fixtures also appear in the cars' material reflections.
 for(const x of [-4,4]){const light=new T.PointLight(0xd9eaff,18,14,2);light.position.set(x,5,1);scene.add(light);}
 const target=new T.WebGLRenderTarget(1,1,{type:T.HalfFloatType,depthBuffer:true,samples:4});target.depthTexture=new T.DepthTexture(1,1,T.UnsignedIntType);
 const fogMaterial=new T.ShaderMaterial({uniforms:{colorMap:{value:target.texture},depthMap:{value:target.depthTexture},inverseProjection:{value:camera.projectionMatrixInverse},cameraWorld:{value:camera.matrixWorld},eye:{value:camera.position},time:{value:0},lamp:{value:.7}},vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}',fragmentShader:fogFragment,depthTest:false,depthWrite:false});
 const screen=new T.Scene();screen.add(new T.Mesh(new T.PlaneGeometry(2,2),fogMaterial));const screenCamera=new T.Camera();
 let running=false,disposed=false,frame=0,last=0,elapsed=0,visible=true;const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 function render(){renderer.setRenderTarget(target);renderer.render(scene,camera);renderer.setRenderTarget(null);renderer.render(screen,screenCamera);host.dataset.drawCalls=String(renderer.info.render.calls);}
 function resize(){const w=host.clientWidth,h=host.clientHeight;if(!w||!h)return;renderer.setPixelRatio(Math.min(devicePixelRatio,1200/w));renderer.setSize(w,h,false);target.setSize(Math.round(w*renderer.getPixelRatio()),Math.round(h*renderer.getPixelRatio()));camera.aspect=w/h;camera.fov=w<h?57:40;camera.position.z=w<h?17:11.8;camera.lookAt(0,1.9,0);camera.updateProjectionMatrix();camera.updateMatrixWorld();render();}
 function tick(now:number){if(disposed)return;frame=requestAnimationFrame(tick);if(!running||!visible||document.hidden||now-last<40)return;const dt=last?Math.min((now-last)/1000,.5):0;last=now;elapsed+=dt;if(!reduced){const pulse=.7+.3*Math.sin(elapsed*.9)+.12*Math.pow(Math.max(0,Math.sin(elapsed*1.8)),12);lights.forEach(l=>l.intensity=8*pulse);strips.forEach(m=>m.emissiveIntensity=1.0+1.2*pulse);fogMaterial.uniforms.time.value=elapsed;fogMaterial.uniforms.lamp.value=pulse;}render();host.dataset.time=elapsed.toFixed(2);host.dataset.light=lights[0].intensity.toFixed(3);}
 const sizes=new ResizeObserver(resize);sizes.observe(host);const visibility=new IntersectionObserver(es=>{visible=es[0].isIntersecting});visibility.observe(host);resize();
 host.dataset.engine='three-scene';host.dataset.meshes=String(scene.children.reduce((n,c)=>{let count=0;c.traverse(o=>{if((o as T.Mesh).isMesh)count++});return n+count},0));
 const enter=()=>{if(reduced){render();host.dataset.time="0.00";return}running=true;last=performance.now();if(!frame)frame=requestAnimationFrame(tick)};
 if(!document.querySelector('.intro'))enter();window.addEventListener('avtolab:entered',enter);window.dispatchEvent(new Event('avtolab:atmosphere-ready'));
 const lose=(e:Event)=>{e.preventDefault();host.dataset.engine='fallback';host.style.opacity='0'};renderer.domElement.addEventListener('webglcontextlost',lose);
 return()=>{disposed=true;cancelAnimationFrame(frame);window.removeEventListener('avtolab:entered',enter);sizes.disconnect();visibility.disconnect();scene.traverse(o=>{const m=o as T.Mesh;if(m.isMesh){m.geometry.dispose();const mats=Array.isArray(m.material)?m.material:[m.material];mats.forEach(v=>v.dispose())}});reflector.getRenderTarget().dispose();target.dispose();fogMaterial.dispose();environment.dispose();texture.dispose();renderer.dispose();renderer.domElement.remove()};
}
