'use client';
import {Clock,MapPin,Navigation,Phone} from 'lucide-react';
import {LocationMap} from './LocationMap';
import {studio,studioRoute} from '../content/studio';

export function BookingLocation({active}:{active:boolean}){
 return <section className="booking-location" aria-label="Как нас найти">
  <h2>Как нас найти</h2>
  <div className="booking-studio-logo" role="img" aria-label="AVTOLAB77 — студия премиум автостайлинга"><span className="logo-art"/></div>
  <div className="booking-location-item"><MapPin aria-hidden="true"/><address><a href={studio.mapUrl} target="_blank" rel="noopener noreferrer">{studio.address}</a></address></div>
  <div className="booking-location-item booking-phone"><Phone aria-hidden="true"/><a href={studio.phoneHref}>{studio.phone}</a></div>
  <div className="booking-location-item"><Clock aria-hidden="true"/><div><p>{studio.hours}</p></div></div>
  <LocationMap active={active}/>
  <a className="booking-route" href={studioRoute} target="_blank" rel="noopener noreferrer"><Navigation size={19} aria-hidden="true"/>Построить маршрут</a>
 </section>;
}
