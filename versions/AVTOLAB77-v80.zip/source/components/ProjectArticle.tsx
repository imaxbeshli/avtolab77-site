'use client';
import {useEffect,useRef,type ReactNode,type CSSProperties} from 'react';
import type {Project} from '../content/projects';
import {useRail} from './Motion';

export function ProjectArticle({project,booking}:{project:Project;booking:ReactNode}){
 const root=useRef<HTMLElement>(null);
 useRail();
 useEffect(()=>{
  if(matchMedia('(prefers-reduced-motion: reduce)').matches||!('IntersectionObserver' in window))return;
  const nodes=root.current?.querySelectorAll<HTMLElement>('[data-project-reveal]');
  const animations:Animation[]=[];let next=0;
  const observer=new IntersectionObserver(entries=>{
   entries.filter(e=>e.isIntersecting).sort((a,b)=>a.target.compareDocumentPosition(b.target)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1).forEach(entry=>{
    observer.unobserve(entry.target);entry.target.classList.remove('project-reveal-pending');
    const now=performance.now(),start=Math.max(now,next);next=start+120;
    animations.push(entry.target.animate([{opacity:0,transform:'translateY(18px)'},{opacity:1,transform:'translateY(0)'}],{duration:750,delay:start-now,easing:'cubic-bezier(.22,.7,.25,1)',fill:'backwards'}));
   });
  },{threshold:.06});
  nodes?.forEach(node=>{node.classList.add('project-reveal-pending');observer.observe(node)});
  return()=>{observer.disconnect();animations.forEach(a=>a.cancel());nodes?.forEach(node=>node.classList.remove('project-reveal-pending'))};
 },[project.slug]);
 return <main ref={root} id="main" className="service-article project-article">
  <div className="service-article-heading" data-project-reveal>
   <a className="service-return project-return" href="/?section=projects">К проектам</a>
   <h1>{project.title}</h1>
  </div>
  <div className="project-hero" data-project-reveal><img src={project.hero} alt={`${project.title} — визуализация автомобиля`} width={1672} height={941} fetchPriority="high"/></div>
  <div className="service-article-copy">
   <section className="service-copy-section" data-project-reveal><p>{project.description}</p></section>
   <section className="service-copy-section" data-project-reveal><h2>Что сделали</h2><ul className="project-work">{project.work.map(work=><li key={work}>{work}</li>)}</ul></section>
  </div>
  <section className="service-examples project-gallery" aria-labelledby={`gallery-${project.slug}`}>
   <div data-project-reveal><h2 id={`gallery-${project.slug}`}>Фотографии проекта</h2></div>
   <div className="work-rail" tabIndex={0} role="region" aria-label="Фотографии проекта — горизонтальная лента" data-project-reveal>{project.photos.map(photo=><figure key={photo.src} className="work-photo project-photo" style={{'--photo-brightness':photo.brightness,'--photo-saturation':.94} as CSSProperties}>
    <img src={photo.src} alt={photo.alt} width={photo.width} height={photo.height} loading="lazy" decoding="async" draggable={false}/>
   </figure>)}</div>
  </section>
  <section className="service-booking" data-project-reveal><h2>Обсудим ваш автомобиль</h2>{booking}</section>
 </main>;
}
