'use client';
import {useEffect,useRef,useState} from 'react';
import {WebGLRenderer,Scene,OrthographicCamera,PlaneGeometry,ShaderMaterial,Mesh} from 'three';
/** A transparent GPU atmosphere layer; the underlying cars remain photographic. */
export function Atmosphere(){
 const host=useRef<HTMLDivElement>(null);
 const [ready,setReady]=useState(false);
 useEffect(()=>{const enter=()=>setReady(true);if(!document.querySelector('.intro'))enter();window.addEventListener('avtolab:prepare-atmosphere',enter);return()=>window.removeEventListener('avtolab:prepare-atmosphere',enter)},[]);
 useEffect(()=>{
  const el=host.current;if(!el||!ready)return;
  let renderer:WebGLRenderer;
  try{renderer=new WebGLRenderer({alpha:true,antialias:false,powerPreference:'low-power'})}catch{el.dataset.engine='fallback';window.dispatchEvent(new Event('avtolab:atmosphere-ready'));return}
  renderer.setClearColor(0,0);renderer.setPixelRatio(1);el.appendChild(renderer.domElement);
  const scene=new Scene(),camera=new OrthographicCamera(-1,1,1,-1,0,2);camera.position.z=1;
  const geometry=new PlaneGeometry(2,2);
  const material=new ShaderMaterial({transparent:true,depthWrite:false,uniforms:{uTime:{value:0}},vertexShader:`varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}`,fragmentShader:`
   precision mediump float;varying vec2 vUv;uniform float uTime;
   float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
   float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
   float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<5;i++){v+=a*noise(p);p=p*2.03+3.1;a*=.5;}return v;}
   void main(){vec2 uv=vUv;float t=uTime;float phase=t*6.2831853/90.+.7;vec2 drift=vec2(cos(phase),sin(phase));float n=fbm(vec2(uv.x*5.,uv.y*8.)+drift*1.35);float n2=fbm(vec2(uv.x*8.,uv.y*12.)-drift*.95);
    float band=exp(-pow((uv.y-.22)/.11,2.));float low=exp(-pow((uv.y-.11)/.08,2.));
    float edges=smoothstep(0.,.09,uv.x)*(1.-smoothstep(.91,1.,uv.x));
    float fog=(smoothstep(.32,.7,n)*band*.36+smoothstep(.35,.72,n2)*low*.18)*edges;
    gl_FragColor=vec4(vec3(.62,.66,.7),min(.4,fog));}
  `});scene.add(new Mesh(geometry,material));
  const reduce=matchMedia('(prefers-reduced-motion: reduce)');
  let id=0,visible=true,previous=performance.now(),lastRender=0,disposed=false;
  const resize=()=>{renderer.setSize(Math.max(1,Math.min(900,el.clientWidth*.4)),Math.max(1,Math.min(600,el.clientHeight*.4)),false);renderer.render(scene,camera)};
  const draw=(now:number)=>{if(disposed)return;const dt=Math.min((now-previous)/1000,.12);previous=now;if(visible&&!document.hidden&&!reduce.matches){material.uniforms.uTime.value+=dt;if(now-lastRender>33){renderer.render(scene,camera);lastRender=now;el.dataset.time=material.uniforms.uTime.value.toFixed(2)}}id=requestAnimationFrame(draw)};
  const sizes=new ResizeObserver(resize);sizes.observe(el);
  const visibility=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting});visibility.observe(el);
  const lost=(event:Event)=>{event.preventDefault();el.dataset.engine='fallback';renderer.domElement.style.opacity='0'};
  renderer.domElement.addEventListener('webglcontextlost',lost);
  resize();el.dataset.engine='webgl';window.dispatchEvent(new Event('avtolab:atmosphere-ready'));
  const begin=()=>{if(!id){previous=performance.now();id=requestAnimationFrame(draw)}};
  if(!document.querySelector('.intro'))begin();window.addEventListener('avtolab:entered',begin); 
  return()=>{disposed=true;window.removeEventListener('avtolab:entered',begin);cancelAnimationFrame(id);sizes.disconnect();visibility.disconnect();renderer.domElement.removeEventListener('webglcontextlost',lost);geometry.dispose();material.dispose();renderer.dispose();renderer.domElement.remove()};
 },[ready]);
 return <div ref={host} className="hero-atmosphere" aria-hidden="true"><i className="fog-fallback"/></div>;
}
