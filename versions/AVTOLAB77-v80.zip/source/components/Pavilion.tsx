'use client';
import {useEffect,useRef} from 'react';
/** One persistent environment shared by all sections, not a background per card. */
export function Pavilion(){
 const ref=useRef<HTMLDivElement>(null);
 useEffect(()=>{const el=ref.current;if(!el)return;let frame=0;
 const update=()=>{frame=0;const hero=document.querySelector('.pavilion-hero');const end=hero?.getBoundingClientRect().bottom??0;const depth=Math.max(0,Math.min(1,1-end/innerHeight));(el.firstElementChild as HTMLElement).style.setProperty('--room-visibility',String(.32+depth*.48));(el.firstElementChild as HTMLElement).style.setProperty('--room-travel',`${-Math.min(40,scrollY*.008)}px`);};
 const schedule=()=>{if(!frame)frame=requestAnimationFrame(update)};update();addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule);return()=>{cancelAnimationFrame(frame);removeEventListener('scroll',schedule);removeEventListener('resize',schedule)};
 },[]);
 return <div className="pavilion-environment" ref={ref} aria-hidden="true"><div className="pavilion-room"/><div className="pavilion-light"/><div className="pavilion-haze"/></div>
}
