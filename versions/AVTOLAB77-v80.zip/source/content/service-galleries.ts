// Original files and page provenance: service-gallery-sources.json.
// Only display filters change tonality; original photographs are untouched.
export const serviceGalleries = {
  "ppf": [
    {
      "src": "/assets/gallery-b174a7dc26b4.webp",
      "alt": "Оклейка авто пленкой",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-ed1143576cdc.webp",
      "alt": "Оклейка автомобиля пленкой",
      "brightness": 0.98,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-6e44421b67b7.webp",
      "alt": "Оклейка авто пленкой",
      "brightness": 0.98,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-27f93a8f240c.webp",
      "alt": "Оклейка авто защитной пленкой в Москве",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-d62bb1090b4c.webp",
      "alt": "Оклейка авто полиуретановой пленкой",
      "brightness": 0.98,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-8aa4bf468fb4.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.84,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-8b5dbaab6217.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-1b8c3f1a6cd8.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-879df6c74f38.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-a339fc44c719.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-1e81d040f1d9.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-92a8d0473531.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-9dd29bda7445.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-e0f5cd934cf1.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-bb93cbf43605.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-cef4217c9618.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-ee72479a6026.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    }
  ],
  "tinting": [
    {
      "src": "/assets/gallery-fd8aa358920d.webp",
      "alt": "Тонировка авто в Москве",
      "brightness": 0.98,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-45dbb60229cb.webp",
      "alt": "Тонировка стекол авто",
      "brightness": 0.98,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-8aa4bf468fb4.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.84,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-8b5dbaab6217.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-1b8c3f1a6cd8.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-879df6c74f38.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-a339fc44c719.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-1e81d040f1d9.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-92a8d0473531.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-9dd29bda7445.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-e0f5cd934cf1.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-bb93cbf43605.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-cef4217c9618.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-ee72479a6026.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    }
  ],
  "polishing": [
    {
      "src": "/assets/gallery-32b0d0c734c3.webp",
      "alt": "Покрытие авто керамикой",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-04ef85dba758.webp",
      "alt": "Покрытие автомобиля керамикой",
      "brightness": 0.98,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-46ed0e0fe985.webp",
      "alt": "Покрытие авто керамикой москва",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-8aa4bf468fb4.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.84,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-8b5dbaab6217.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-1b8c3f1a6cd8.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-879df6c74f38.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-a339fc44c719.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-1e81d040f1d9.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-92a8d0473531.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-9dd29bda7445.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-e0f5cd934cf1.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-bb93cbf43605.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-cef4217c9618.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-ee72479a6026.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    }
  ],
  "glass": [
    {
      "src": "/assets/gallery-8aa4bf468fb4.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.84,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-8b5dbaab6217.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-1b8c3f1a6cd8.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-879df6c74f38.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-a339fc44c719.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-1e81d040f1d9.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-92a8d0473531.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-9dd29bda7445.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-e0f5cd934cf1.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-bb93cbf43605.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-cef4217c9618.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-ee72479a6026.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    }
  ],
  "pdr": [
    {
      "src": "/assets/gallery-8aa4bf468fb4.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.84,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-8b5dbaab6217.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-1b8c3f1a6cd8.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-879df6c74f38.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-a339fc44c719.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-1e81d040f1d9.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-92a8d0473531.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-9dd29bda7445.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-e0f5cd934cf1.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-bb93cbf43605.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-cef4217c9618.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-ee72479a6026.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    }
  ],
  "soundproofing": [
    {
      "src": "/assets/gallery-2ab0d0a0b87c.webp",
      "alt": "Шумоизоляция авто в Москве",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-81a35e8b96cf.webp",
      "alt": "Шумоизоляция автомобиля Москва",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-854ab6ee5571.webp",
      "alt": "Шумоизоляция салона автомобиля",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-8aa4bf468fb4.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.84,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-8b5dbaab6217.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-1b8c3f1a6cd8.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-879df6c74f38.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-a339fc44c719.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-1e81d040f1d9.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-92a8d0473531.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-9dd29bda7445.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-e0f5cd934cf1.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.94,
      "saturation": 0.96
    },
    {
      "src": "/assets/gallery-bb93cbf43605.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-cef4217c9618.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    },
    {
      "src": "/assets/gallery-ee72479a6026.webp",
      "alt": "Фотография из галереи AVTOLAB77",
      "brightness": 0.88,
      "saturation": 0.91
    }
  ]
};
