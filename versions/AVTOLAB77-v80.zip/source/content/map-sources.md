# Studio map sources

- Marker coordinates supplied by the owner on 2026-11-06: latitude 55.758385, longitude 37.529670. `studio-map.ts` stores MapLibre order `[longitude, latitude]`.
- Renderer: MapLibre GL JS 6.16.0 (BSD-3-Clause), license preserved in `content/licenses/MapLibre.txt` and standalone HTML stylesheet comment.
- Basemap: OpenFreeMap public instance; OpenStreetMap data using OpenMapTiles schema. Provider documents free public usage without keys, registration, cookies or map-view limits: https://github.com/hyperknot/openfreemap . Not an SLA.
- Tile URL: https://tiles.openfreemap.org/planet/latest/{z}/{x}/{y}.pbf (documented provider endpoint); fonts hosted by the same provider.
- Original custom style authored for this project, not copied from another commercial style. No unrelated business-POI layer. Railway stations and Moscow City labels come from vector data, not invented coordinates.
- Visible attribution links for OpenFreeMap, OpenMapTiles and OpenStreetMap are retained.
- `check-v64.cjs` uses synthetic geometry ONLY to test MapLibre rendering/input/resource lifecycle. It does not validate live tile availability or actual Moscow geography; no fixture is included in the production style.
- Routing remains the user's Yandex address link, outside the panel. No Yandex iframe, ad integration, geolocation or geocoding requests.
