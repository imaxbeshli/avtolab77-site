# Digital service content

Prepared 2026-11-07. Scope and final wording follow the owner's explicit corrections.
Descriptions are brand-neutral. No FAQs, invented work examples or master-account registration offer.

## References consulted

- https://dazysoft.ru/solutions/Rusifikatsiya-Zeekr/Rusifikatsiya-ZEEKR-001/ — localization, voice assistance, app stores. Provider describes language restoration after some updates; not evidence of permanent preservation through every factory update.
- https://www.zeekr.eu/en-nl/connected — purposes of connected services. European subscriptions and compatibility conditions were not transferred to Chinese-market vehicles.
- https://rucars.ru/magazine/articles/detail/zeekr-001-setting/ — number +86 and account access.
- https://ruszeekr.ru/blog/master-akkaunt-zeekr-kakie-daet-vozmozhnosti-i-kak-ego-poluchit/ — owner vs family account. No provider guarantees or account-registration service copied.
- https://www.autounit.pro/blog/detail/ustanovka-simkarty-v-zeekr-lixiang-/ — example of physical SIM-chip replacement and SIM interface installation.
- https://support.apple.com/ru-ru/118283 — App Store regional availability.

The owner specified full localization, Russian voice assistance, an app store, localization updates over the air, a telematics check, hardware SIM adaptation, help registering a Chinese number and phone app setup. On 2026-11-08 the owner explicitly specified and approved independent localization that preserves Russian after manufacturer updates, does not interfere with official updates, and updates over the air without return visits. The published OTA wording follows that business-provided description; the external sources above do not independently establish this property for every solution. Master-account content is explanatory only. Customers obtain their own operator SIM after receiving requirements.

## Generated illustrations

Six independent image_gen illustrations, 1672 × 941, generated for these pages. They are illustrative, not customer work photos or documentation of a particular hardware model. Original PNGs remain in /workspace/generated_images. WebP copies are optimized without visual edits.

| Page | Original filename | Web asset |
| --- | --- | --- |
| firmware (v78, owner-approved replacement) | exec-086a9675-f716-4a5c-9fac-c40387d59db9.png | digital-firmware-map-hero.webp |
| tcam | exec-c6f378ef-7290-4759-a69d-16257969b874.png | digital-tcam-hero.webp |
| number | exec-f231470e-d6be-45f7-8ccf-7c82dcd4ac82.png | digital-number-hero.webp |
| account | exec-7a11ec69-0c66-42d9-a6bd-d074fd1afdcf.png | digital-account-hero.webp |
| sim | exec-13280414-54a8-4ea9-bace-46fa87511702.png | digital-sim-hero.webp |
| apps | exec-84b62b8c-4262-486d-adac-3e16f1e01385.png | digital-apps-hero.webp |

The v78 illustration is an approved concept with Yandex-style navigation, music, menus and climate controls. It is not an exact screenshot of production vehicle software or a navigationally accurate map. Earlier firmware artwork remains available in historical versions.

2026-11-08, v79: the owner confirmed personal attendance for Chinese number registration, verification on the customer's device and the studio's non-retention of passport data/document copies. The copy refers to AVTOLAB77's handling, not third-party operators' retention policies. The SIM selection section was removed at the owner's request.
