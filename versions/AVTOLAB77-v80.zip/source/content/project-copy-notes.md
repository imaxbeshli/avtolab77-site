# Project copy, v80

2026-11-08: descriptions expanded from content/project-source-pages.json. Each project's source URL is kept in content/projects.ts. Descriptions explain the scope and purpose of the recorded work without introducing unrelated services from the general catalogue.

- Bentley: LEGEND PPF full wrap, windshield protection, interior surfaces.
- Lexus: LEGEND PPF, glass protection, underbody anti-corrosion, crankcase protection, protective mesh, alarm, dashcam, interior surfaces.
- Mercedes: full protective body wrap. No extra detailing or insulation attributed.
- Range Rover: polishing, full LEGEND PPF wrap, interior surfaces.
- Voyah: full protective wrap, glass/headlights and interior protection.
- BMW: original source identifies E31 (1995) and preservation of original paint with LEGEND PPF. The owner explicitly confirmed interior restoration and paintwork restoration in the conversation on 2026-11-08. Those two operations were added; E31 identity retained.

No timelines, additional warranties, repainting, specific upholstery replacement or measured restoration outcomes were invented. General descriptions of protective films explain their purpose rather than promise protection from all damage.
