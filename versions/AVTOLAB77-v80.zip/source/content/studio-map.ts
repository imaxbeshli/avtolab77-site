import type {StyleSpecification,ExpressionSpecification} from 'maplibre-gl';

// Coordinates supplied by the studio owner, 6 November 2026; MapLibre uses [longitude, latitude].
export const studioCoordinates:[number,number]=[37.529670,55.758385];
export const studioMapBounds:[[number,number],[number,number]]=[[37.517,55.7455],[37.548,55.763]];
const name:ExpressionSpecification=['coalesce',['get','name:ru'],['get','name'],['get','name_en'],''];
const rail:ExpressionSpecification=['all',['==',['get','class'],'railway'],['!=',['get','subclass'],'tram_stop']];
export function studioMapStyle():StyleSpecification{return {
 version:8,
 glyphs:'https://tiles.openfreemap.org/fonts/{fontstack}/{range}.pbf',
 sources:{openmaptiles:{type:'vector',tiles:['https://tiles.openfreemap.org/planet/latest/{z}/{x}/{y}.pbf'],maxzoom:14,
  attribution:'<a href="https://openfreemap.org/" target="_blank" rel="noopener">OpenFreeMap</a> · <a href="https://www.openmaptiles.org/" target="_blank" rel="noopener">OpenMapTiles</a> · <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">© OpenStreetMap</a>'}},
 layers:[
  {id:'background',type:'background',paint:{'background-color':'#151619'}},
  {id:'land',type:'fill',source:'openmaptiles','source-layer':'landuse',paint:{'fill-color':'#202125'}},
  {id:'park',type:'fill',source:'openmaptiles','source-layer':'park',paint:{'fill-color':'#242629'}},
  {id:'water',type:'fill',source:'openmaptiles','source-layer':'water',paint:{'fill-color':'#0c0e12'}},
  {id:'waterway',type:'line',source:'openmaptiles','source-layer':'waterway',paint:{'line-color':'#0c0e12','line-width':2}},
  {id:'buildings',type:'fill',source:'openmaptiles','source-layer':'building',minzoom:13,paint:{'fill-color':'#38383d','fill-outline-color':'#48484d'}},
  {id:'road-casing',type:'line',source:'openmaptiles','source-layer':'transportation',filter:['!',['in',['get','class'],['literal',['rail','transit']]]],layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#242429','line-width':['interpolate',['linear'],['zoom'],12,2,16,9,19,22]}},
  {id:'roads',type:'line',source:'openmaptiles','source-layer':'transportation',filter:['!',['in',['get','class'],['literal',['rail','transit']]]],layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':['match',['get','class'],['motorway','trunk','primary'],'#77767c','#55545a'],'line-width':['interpolate',['linear'],['zoom'],12,.7,16,5,19,15]}},
  {id:'rail',type:'line',source:'openmaptiles','source-layer':'transportation',filter:['in',['get','class'],['literal',['rail','transit']]],paint:{'line-color':'#8e4252','line-width':['interpolate',['linear'],['zoom'],12,.6,17,2.2],'line-opacity':.75}},
  {id:'road-names',type:'symbol',source:'openmaptiles','source-layer':'transportation_name',minzoom:14,layout:{'symbol-placement':'line','text-field':name,'text-font':['Noto Sans Regular'],'text-size':11,'text-max-angle':30},paint:{'text-color':'#c2bec3','text-halo-color':'#18191c','text-halo-width':1.5}},
  {id:'station-points',type:'circle',source:'openmaptiles','source-layer':'poi',minzoom:12,filter:rail,paint:{'circle-radius':4,'circle-color':'#b5425a','circle-stroke-color':'#f0e7e9','circle-stroke-width':1}},
  {id:'station-names',type:'symbol',source:'openmaptiles','source-layer':'poi',minzoom:12,filter:rail,layout:{'text-field':name,'text-font':['Noto Sans Regular'],'text-size':12,'text-anchor':'top','text-offset':[0,.8],'text-max-width':12},paint:{'text-color':'#f2ecee','text-halo-color':'#17171b','text-halo-width':2}},
  {id:'city-landmark',type:'symbol',source:'openmaptiles','source-layer':'poi',filter:['in',name,['literal',['Москва-Сити','Moscow City','Московский международный деловой центр «Москва-Сити»']]],layout:{'text-field':name,'text-font':['Noto Sans Regular'],'text-size':13,'text-max-width':14},paint:{'text-color':'#f2ecee','text-halo-color':'#17171b','text-halo-width':2}},
  {id:'places',type:'symbol',source:'openmaptiles','source-layer':'place',maxzoom:15,layout:{'text-field':name,'text-font':['Noto Sans Regular'],'text-size':['interpolate',['linear'],['zoom'],10,11,15,13],'text-max-width':12},paint:{'text-color':'#bab6bd','text-halo-color':'#18191c','text-halo-width':2}},
 ]
};}
