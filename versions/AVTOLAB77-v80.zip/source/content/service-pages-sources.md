# Sources for all six styling service pages

Fetched successfully on 2026-11-07 after the owner published the network configuration. The six canonical URLs and extracted source text are preserved in `original-service-copy.json`. The asset URL/provenance mapping is in `service-assets-sources.json`.

## Source mapping and editorial choices
- Antigravel protection: https://avtolab77.ru/services/antigravijnaya-zashchita-kuzova/ — transparent polyurethane, partial/full coverage, LEGEND PPF, heat-assisted smoothing of minor top-coat scratches. Avoided absolute protection, longevity and market-leadership claims.
- Tinting: https://avtolab77.ru/services/tonirovanie-avtomobilej/ — inside installation, glare/solar comfort, 3M Color Stable and Crystalline. No promise that a film alone ensures legal light transmission; the glass/film combination must be considered. No inherited lifetime warranty or percentage claim.
- Polishing: https://avtolab77.ru/services/keramicheskaya-polirovka-kuzova/ — polishing and ceramic protection are distinct stages. servFaces Ceramic Coat Ultima is described as a coating after preparation, not as a polishing abrasive. No suggestion that ceramic replaces PPF or removes deep damage.
- Glass protection: https://avtolab77.ru/services/bronirovanie-stekol/ — 3M film and retention of fragments on side glass. Excluded bullet/blast-proof implications, assured prevention of injury, soundproofing promises, and the ambiguous outside-windshield 3M claim.
- Dent repair: https://avtolab77.ru/services/udalenie-vmyatin-bez-pokraski/ — PDR, rods and glue pulling, preserving the existing coating when suitable. Requires assessment of paint condition, sharp creases and stretched metal. No fixed turnaround or guaranteed repair of every dent.
- Soundproofing: https://avtolab77.ru/services/shumoizolyatsiya-salona-avtomobilya/ — fetched copy matches the owner's previously pasted source. Approved three-section text and hero retained; generated gallery replaced with photos from the original soundproofing article. Comfort Mat usage was explicitly confirmed by the owner. No 60–70% reduction or market-leadership claim.

No prices, FAQ, production stages, unrelated services, new warranties or broad promotional slogans were imported. All six use the approved centered template.

## Images
Article photos from the original PPF, tinting, polishing and soundproofing pages are reused locally, converted to WebP without altering their content. PPF gallery photos showing film installation are also taken from the original site's shared works gallery.

The original site repeats the same shared gallery on several service pages. Generic studio photos are NOT verified examples of specific glass-protection or dent-repair jobs. The original draft identified these as general photographs. In v70, the owner requested removing the explanatory gallery subtitles. Provenance remains recorded here and in service-gallery-sources.json; no service-specific completion claim has been added to individual photographs. Alt text describes what is actually shown.

Five generated illustrative hero images are not client case studies:
- `service-glass-hero.webp`: exec-c022bead-59a5-49fe-b046-626ca6432646.png
- `service-pdr-hero.webp`: exec-a9714268-b5a5-4138-8074-83602c0bf839.png

For v69, the owner requested new illustrations for the three remaining heroes:
- `service-ppf-illustration.webp`: exec-97c571c5-1250-40a9-b628-8b7c5bbf9c56.png
- `service-tinting-illustration.webp`: exec-fa3a0622-2e64-4d28-b030-bb52329d4cd2.png
- `service-polishing-illustration.webp`: exec-a7d0bfdb-277e-430b-8801-6529ce188469.png

The previously approved illustrative soundproofing hero remains unchanged. Original photos remain in the work galleries; replacing a hero does not replace gallery photos. No generated image is presented in a gallery as real completed work.

## Typography
UnboundedService is a Latin/Cyrillic WOFF subset of the existing unbounded.ttf, under the existing license in public/assets/fonts. The small original homepage font subset remains untouched.

## Publication
The first six-page draft was kept local as requested. The owner subsequently approved replacing three heroes and hiding gallery scrollbars, and explicitly requested applying these changes to the live site. This is the v69 release prepared under that authorization. Environment configuration is unchanged.

## v70 gallery expansion and reversible tonality
All 25 unique article/gallery photographs were downloaded again from the six original service URLs. Icons, logos and unrelated decorative banners are excluded. Gallery counts: PPF 17, tinting 14, polishing 15, PDR 12, soundproofing 15. The original glass-protection page has no article/gallery photographs, so its previously approved general studio selection is expanded to the full shared 12-photo gallery. This fallback is explicitly recorded in service-gallery-sources.json.

Exact downloaded originals and SHA256 checksums are retained in content/original-service-photos and the source manifest. Display WebP copies are resized without upscaling; CSS brightness (0.84–0.98) and saturation (0.91–0.96) provide reversible grading. No photographs were regenerated, redrawn or content-edited. The same source URL is included once per gallery.
