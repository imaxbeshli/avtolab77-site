import gallery from './project-gallery-sources.json';

export type Project = {
 slug:string;brand:string;title:string;category:string;description:string;
 hero:string;thumbnail:string;tile:number;source:string;work:string[];
 photos:{src:string;width:number;height:number;brightness:number;alt:string}[];
};
const covers:Record<string,{hero:string;thumbnail:string}> = {
 "bentley": {hero:"/assets/project-bentley-r72.webp",thumbnail:"/assets/project-bentley-card-r72.webp"},
 "lexus": {hero:"/assets/project-lexus-r72.webp",thumbnail:"/assets/project-lexus-card-r72.webp"},
 "mercedes": {hero:"/assets/project-mercedes-r72.webp",thumbnail:"/assets/project-mercedes-card-r72.webp"},
 "range-rover": {hero:"/assets/project-range-rover-r72.webp",thumbnail:"/assets/project-range-rover-card-r72.webp"},
 "voyah": {hero:"/assets/project-voyah-r72.webp",thumbnail:"/assets/project-voyah-card-r72.webp"},
 "bmw": {hero:"/assets/project-bmw-r72.webp",thumbnail:"/assets/project-bmw-card-r72.webp"},
};
const cases = [
 {
  slug:'bentley-continental-gt',brand:'bentley',title:'Bentley Continental GT',category:'Защита кузова и салона',
  description:'Для Bentley Continental GT выполнили защиту кузова, лобового стекла и отделки салона. Задача проекта — сохранить внешний вид купе и защитить поверхности, которые сталкиваются с дорожным песком, мелкими камнями и повседневными касаниями.',
  source:'https://avtolab77.ru/works/bentley/bentley-motors-continental-gt/',
  work:[
   'Полностью оклеили кузов прозрачной полиуретановой плёнкой LEGEND PPF. Она помогает защитить лакокрасочное покрытие от сколов и мелких царапин, сохраняя исходный цвет автомобиля.',
   'Выполнили бронирование лобового стекла — дополнительную защиту от дорожных воздействий для детали, замена которой требует значительных затрат.',
   'Защитили чувствительные и часто используемые элементы интерьера плёнкой и специальными материалами без изменения их цвета.',
  ],
 },
 {
  slug:'lexus-lx500',brand:'lexus',title:'Lexus LX500',category:'Комплексная защита',
  description:'Lexus LX500 подготовили к повседневной эксплуатации и дальним поездкам. В одном проекте объединили защиту кузова, стёкол и днища, работу с интерьером и установку дополнительного оборудования. Учли дорожные воздействия, зимние реагенты и задачи безопасности.',
  source:'https://avtolab77.ru/works/lexus/lexus-lx500/',
  work:[
   'Оклеили кузов антигравийной плёнкой LEGEND PPF и выполнили бронирование стёкол.',
   'Установили защиту картера и защитные сетки, провели антикоррозийную обработку днища.',
   'Установили сигнализацию и видеорегистратор: дополнили защиту автомобиля средствами охраны и фиксации дорожной обстановки.',
   'Оклеили уязвимые элементы салона, чтобы уменьшить появление потёртостей и царапин при ежедневном использовании.',
  ],
 },
 {
  slug:'mercedes-g450d',brand:'mercedes',title:'Mercedes-Benz G 450 d',category:'Антигравийная защита',
  description:'Для Mercedes-Benz G 450 d выполнили полную защитную оклейку кузова. У G-Class крупные плоские панели, выраженные грани и характерные переходы между деталями — на таком автомобиле особенно заметно качество работы с плёнкой. Основной задачей стала защита лакокрасочного покрытия с сохранением внешнего облика внедорожника.',
  source:'https://avtolab77.ru/works/mercedes/mercedes-benz-g-%D1%81lass-450d/',
  work:[
   'Кузов целиком закрыли защитной плёнкой. Полная оклейка помогает снизить риск сколов от дорожного песка и мелких камней, а также поверхностных царапин при эксплуатации. Защита охватывает кузов в целом, включая боковые и задние поверхности автомобиля.',
  ],
 },
 {
  slug:'range-rover-autobiography',brand:'range-rover',title:'Range Rover Autobiography',category:'Полировка и защита',
  description:'В проекте Range Rover Autobiography 2023 года совместили восстановление внешнего вида и последующую защиту покрытия. Сначала привели в порядок лакокрасочную поверхность, затем выполнили полную оклейку кузова. Отдельное внимание уделили деталям интерьера, на которых особенно заметны следы использования.',
  source:'https://avtolab77.ru/works/range-rover/range-rover-autobiography-2023/',
  work:[
   'Выполнили полировку лакокрасочного покрытия, чтобы восстановить ровный блеск и сделать цвет кузова более выразительным.',
   'Полностью оклеили кузов прозрачной полиуретановой плёнкой LEGEND PPF для сохранения результата полировки и защиты от повседневных дорожных воздействий.',
   'Нанесли защитную плёнку на отдельные элементы салона, подверженные появлению царапин и потёртостей.',
  ],
 },
 {
  slug:'voyah-taishan',brand:'voyah',title:'Voyah Taishan',category:'Кузов, оптика и интерьер',
  description:'Для Voyah Taishan собрали комплекс защиты внешних поверхностей и интерьера. Работы охватили кузов, стёкла, фары и чувствительные детали салона. Такой подход помогает сохранить аккуратный вид автомобиля как снаружи, так и внутри при регулярной эксплуатации.',
  source:'https://avtolab77.ru/works/voyah/voyah-taishan/',
  work:[
   'Выполнили полную оклейку кузова антигравийной плёнкой для защиты лакокрасочного покрытия от мелких повреждений.',
   'Провели бронирование стёкол и фар. Дополнительная защита этих поверхностей дополняет оклейку кузова.',
   'Защитили чувствительные элементы салона, которые чаще соприкасаются с руками и личными вещами владельца.',
  ],
 },
 {
  slug:'bmw-e31',brand:'bmw',title:'BMW E31',category:'Восстановление и сохранение',
  description:'Коллекционное купе BMW E31 1995 года — проект с акцентом на бережное восстановление и сохранение оригинального облика. Работы затронули лакокрасочное покрытие и салон. После восстановления кузов защитили плёнкой, чтобы сохранить результат и снизить риск новых повреждений при эксплуатации.',
  source:'https://avtolab77.ru/works/bmw/bmw-e31/',
  work:[
   'Выполнили работы по восстановлению лакокрасочного покрытия с вниманием к сохранению оригинального ЛКП автомобиля.',
   'Провели реставрацию салона с сохранением характера и оригинального облика интерьера классического купе.',
   'Полностью оклеили кузов защитной плёнкой LEGEND PPF — для дополнительной защиты покрытия и сохранения внешнего вида автомобиля.',
  ],
 },
];
// Cover illustrations are separate from documentary photographs of actual work.
export const projects:Project[]=cases.map((item,tile)=>({...item,tile,
 ...covers[item.brand],
 photos:gallery.filter(photo=>photo.brand===item.brand).map(photo=>({src:photo.src,width:photo.width,height:photo.height,brightness:photo.brightness,alt:`${item.title} — работа студии AVTOLAB77, фото ${photo.index}`}))
}));
