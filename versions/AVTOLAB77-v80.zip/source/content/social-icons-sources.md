# Social marks, v47
Telegram, VK, YouTube, Instagram: Simple Icons, CC0, via @iconify-json/simple-icons 1.2.101.
https://github.com/simple-icons/simple-icons
MAX Messenger: Arcticons max-messenger, CC BY-SA 4.0, via @iconify-json/arcticons 1.2.59. Stroke adjusted for the 22px header display; shape unchanged.
https://github.com/Arcticons-Team/Arcticons
https://creativecommons.org/licenses/by-sa/4.0/
All marks use currentColor. No external runtime icon requests.
v54: links point to the five studio accounts supplied by the owner; external destinations open in a new tab.

## v53 update
MAX: the white even-odd vector glyph from @alex_rexby/n8n-nodes-max 0.4.43, dist/nodes/Max/max.svg (MIT package). Only the vector mark is reused; the bitmap gradient background is excluded. The viewBox crops unused padding. https://www.npmjs.com/package/@alex_rexby/n8n-nodes-max
Telegram: existing Simple Icons glyph extracted from its enclosing disk and optically scaled. Other Simple Icons glyphs retained, with consistent white rendering and optical sizes.

## v66 — precise brand vectors
YouTube, VK and Instagram now use the unrounded paths from simple-icons 16.0.0 (CC0), fetched from https://cdn.jsdelivr.net/npm/simple-icons@16.0.0/icons/{youtube,vk,instagram}.svg. YouTube retains its original geometry; its viewport crops the empty top/bottom margins to display the full 28×19.7 px mark inside a 28×21 px slot. No nonuniform scaling, raster images or runtime requests. Telegram and MAX retain their previously approved vectors. All five destinations are unchanged.
