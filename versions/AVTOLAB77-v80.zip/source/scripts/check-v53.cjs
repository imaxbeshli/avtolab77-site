const {chromium}=require('@playwright/test'),assert=require('node:assert/strict');
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});try{for(const [width,height] of [[390,844],[1440,1000],[3440,1440]]){
 const p=await b.newPage({viewport:{width,height},isMobile:width<650,hasTouch:width<650}),errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.goto('http://localhost:4176/AVTOLAB77.html');await p.waitForSelector('.intro[data-phase="opening"]',{timeout:60000});
 const title=p.locator('.hero-text-title'),visual=p.locator('.hero-visual');const w1=(await title.boundingBox()).width;
 await p.waitForSelector('.intro',{state:'detached'});const mid=await visual.evaluate(e=>+getComputedStyle(e).scale);assert(mid>1&&mid<1.025);
 await p.waitForFunction(()=>+getComputedStyle(document.querySelector('.hero-visual')).scale>=1.025);await p.waitForSelector('.hero-headlights[data-state="on"]');
 const w2=(await title.boundingBox()).width;assert(Math.abs(w2-w1)<.1);assert.equal(await visual.evaluate(e=>+getComputedStyle(e).scale),1.025);
 const bounds=await p.locator('.approved-artwork,.hero-neon77,.hero-headlights').evaluateAll(es=>es.map(e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,w:r.width,h:r.height}}));for(const rect of bounds.slice(1))for(const k of ['x','y','w','h'])assert(Math.abs(bounds[0][k]-rect[k])<1);
 const max=p.locator('.social-marks a[aria-label="MAX"]');assert.equal(await max.locator('path').getAttribute('fill-rule'),'evenodd');assert.equal(await max.locator('svg').getAttribute('viewBox'),'6 6 48 48');assert.equal(await max.locator('image').count(),0);assert.equal(await p.locator('.social-marks a').count(),5);
 assert.equal(await p.locator('.neon77-breathe').evaluate(e=>getComputedStyle(e).animationDuration),'10s');
 await p.screenshot({path:`/workspace/previews/v53-${width}-hero.png`});if(width===1440)await p.locator('.header').screenshot({path:'/workspace/previews/v53-header.png'});
 assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));assert.deepEqual(errors,[]);console.log('PASS',width,'zoom continued after intro, stable title, aligned lights, vector MAX, no JS errors');await p.close();
 }
 const p=await b.newPage({viewport:{width:390,height:844},reducedMotion:'reduce'});await p.goto('http://localhost:4176/AVTOLAB77.html');await p.waitForSelector('.hero-headlights[data-state="on"]');assert.equal(await p.locator('.hero-visual').evaluate(e=>getComputedStyle(e).scale),'1');assert.equal(await p.locator('.neon77-breathe').evaluate(e=>getComputedStyle(e).animationName),'none');console.log('PASS reduced motion');await p.close();
}finally{await b.close()}})().catch(e=>{console.error(e);process.exit(1)});
