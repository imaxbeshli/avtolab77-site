"""Archive an already committed standalone release without rewriting older versions.
Usage: python3 scripts/archive-version.py v13 'Description' /tmp/avtolab77-pages
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import sys, subprocess, json, hashlib, html
version, description, checkout = sys.argv[1:]
assert version.startswith('v') and version[1:].isdigit()
repo=Path(checkout).resolve(); dest=repo/'versions'; src=Path(__file__).resolve().parents[1]
data=(repo/'index.html').read_bytes(); commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
r={'version':version,'commit':commit,'description':description,'index_sha256':hashlib.sha256(data).hexdigest(),'source_included':True,'archive':f'AVTOLAB77-{version}.zip'}
assert not (dest/r['archive']).exists(), 'Historical archives are immutable'
(dest/f'{version}.html').write_bytes(data)
# The live export leaves project photographs external and lazy-loaded. The
# saved HTML still embeds them, so older snapshots and offline rollback work.
live=Path('/workspace/previews/AVTOLAB77-live.html')
if live.exists() and (src/'public/project-media').exists():
 live_data=live.read_bytes();(dest/f'{version}.live.html').write_bytes(live_data)
 r['live_index_sha256']=hashlib.sha256(live_data).hexdigest()
 r['project_media']=[{'path':str(p.relative_to(src/'public')),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((src/'public/project-media').rglob('*')) if p.is_file()]
# Keep unmodified camera originals in a companion archive, avoiding GitHub's
# 100 MiB per-file limit. Optimized real photos remain in the main source ZIP.
originals=src/'content/original-project-photos'
if originals.exists():
 r['original_photos_archive']=f'AVTOLAB77-{version}-original-photos.zip'
 with ZipFile(dest/r['original_photos_archive'],'w',ZIP_DEFLATED) as z:
  for p in sorted(originals.iterdir()):
   if p.is_file():z.write(p,Path('content/original-project-photos')/p.name)
 r['original_photos_sha256']=hashlib.sha256((dest/r['original_photos_archive']).read_bytes()).hexdigest()
with ZipFile(dest/r['archive'],'w',ZIP_DEFLATED) as z:
 z.writestr('index.html',data);z.writestr('VERSION.json',json.dumps(r,ensure_ascii=False,indent=2))
 z.writestr('README.txt',f'AVTOLAB77 {version}\nОткройте index.html для просмотра. Для отката пришлите этот архив или напишите «Верни {version}». Исходники в source/. Восстановление новым коммитом gh-pages без удаления истории.\nВсе фотографии для сайта включены в source/public. Неизменённые оригиналы съёмки дополнительно сохранены в архиве '+r.get('original_photos_archive','исходников')+'.\n')
 for folder in ['app','components','content','styles','scripts','public']:
  for p in (src/folder).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts and 'original-project-photos' not in p.parts:z.write(p,Path('source')/p.relative_to(src))
 for name in ['package.json','package-lock.json','tsconfig.json','next.config.ts','next-env.d.ts','README.md','AGENTS.md','.gitignore']:
  p=src/name
  if p.is_file():z.write(p,Path('source')/name)
with ZipFile(dest/r['archive']) as z:
 assert z.testzip() is None
 assert hashlib.sha256(z.read('index.html')).hexdigest()==r['index_sha256']
r['archive_sha256']=hashlib.sha256((dest/r['archive']).read_bytes()).hexdigest()
p=dest/'manifest.json';records=json.loads(p.read_text());assert not any(x['version']==version for x in records);previous=records[-1]['version'];records.append(r);p.write_text(json.dumps(records,ensure_ascii=False,indent=2))
p=dest/'index.html';s=p.read_text().replace(previous+' — текущая',previous)
entry=f'<article><h2>{version} — текущая</h2><p>{html.escape(description)}</p><a href="{version}.html">Посмотреть</a><a href="{r["archive"]}" download>Скачать ZIP</a><small>Сайт + исходники</small></article>'
p.write_text(s.replace('<article>',entry+'<article>',1))
print(f'{version}: archive and source verified; previous versions untouched')
