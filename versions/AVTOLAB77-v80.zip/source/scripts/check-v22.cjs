const {chromium}=require('@playwright/test');const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 const p=await browser.newPage({viewport:{width:1440,height:1000}});const errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.goto('http://localhost:4173/AVTOLAB77.html');await p.waitForSelector('.intro',{state:'detached',timeout:60000});
 assert.equal(await p.locator('.service-card').count(),6);assert.equal(await p.locator('.digital-grid a').count(),6);
 for(const width of [1440,390,320,768,1920]){
  await p.setViewportSize({width,height:1000});
  assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),`page overflows at ${width}`);
  for(const sel of ['.styling-panel','.digital-panel']){
   const styles=await p.locator(sel).evaluate(el=>{const s=getComputedStyle(el);return [s.borderTopWidth,s.backgroundColor,s.borderRadius]});assert.deepEqual(styles,['0px','rgba(0, 0, 0, 0)','0px']);
  }
  for(let y=0;y<await p.evaluate(()=>document.body.scrollHeight);y+=650){await p.evaluate(y=>window.scrollTo({top:y,behavior:'instant'}),y);await p.waitForTimeout(90)}
  await p.waitForTimeout(1300);
  await p.locator('.service-rail').evaluate(el=>el.scrollLeft=0);
  await p.locator('.projects-rail').evaluate(el=>el.scrollLeft=0);
  await p.evaluate(()=>window.scrollTo({top:0,behavior:'instant'}));
  if(width===1440||width===390)await p.screenshot({path:`/workspace/previews/v22-${width}-full.png`,fullPage:true});
 }
 await p.setViewportSize({width:1440,height:1000});
 for(const selector of ['.service-card','.project-card']){
  const c=p.locator(selector).first();await c.scrollIntoViewIfNeeded();await p.mouse.move(0,0);await p.waitForTimeout(1450);
  const scale=()=>c.locator('.art').evaluate(el=>new DOMMatrix(getComputedStyle(el,'::before').transform).a);
  const bounds=await c.boundingBox();assert(Math.abs(await scale()-1)<.001);
  await c.hover();await p.waitForTimeout(250);const mid=await scale();assert(mid>1.002&&mid<1.054,`${selector} intermediate zoom ${mid}`);
  await p.waitForTimeout(1300);assert(Math.abs(await scale()-1.055)<.002);assert.deepEqual(await c.boundingBox(),bounds);
  await p.mouse.move(0,0);await p.waitForTimeout(1450);assert(Math.abs(await scale()-1)<.002);
 }
 const rail=p.locator('.service-rail');await rail.scrollIntoViewIfNeeded();await p.waitForTimeout(200);await rail.hover();
 await p.mouse.wheel(0,230);await p.waitForTimeout(600);assert(await rail.evaluate(el=>el.scrollLeft)>50,'wheel scrolls service rail');
 // Appending future cards must extend the rail without resizing existing cards.
 const widthBefore=await rail.locator('a').first().evaluate(el=>el.getBoundingClientRect().width);
 await rail.evaluate(el=>{for(let i=0;i<8;i++){const card=el.children[i%6].cloneNode(true);card.dataset.test='extra';el.append(card)}});
 assert.equal(await rail.locator('a').first().evaluate(el=>el.getBoundingClientRect().width),widthBefore);
 await rail.focus();await rail.press('End');await p.waitForTimeout(700);assert(await rail.evaluate(el=>Math.abs(el.scrollWidth-el.clientWidth-el.scrollLeft)<2));
 await rail.press('Home');await p.waitForTimeout(700);
 const bounds=await rail.boundingBox();const x=bounds.x+170,y=bounds.y+80;
 await p.mouse.move(x,y);await p.mouse.down();await p.mouse.move(x-120,y,{steps:12});await p.mouse.up();await p.waitForTimeout(150);
 assert(await rail.evaluate(el=>el.scrollLeft)>80,'drag scrolls rail');assert(!p.url().includes('#/services/'),'drag does not activate service link');
 await rail.evaluate(el=>{el.querySelectorAll('[data-test]').forEach(c=>c.remove());el.scrollLeft=0});
 // Wheel at the end must pass through so the page can continue scrolling.
 await rail.evaluate(el=>el.scrollLeft=el.scrollWidth);await rail.hover();const top=await p.evaluate(()=>scrollY);await p.mouse.wheel(0,240);await p.waitForTimeout(350);assert(await p.evaluate(()=>scrollY)>top);
 const car=p.locator('.vehicle-carousel');await car.scrollIntoViewIfNeeded();await car.press('ArrowRight');await p.waitForTimeout(1750);assert.equal(await car.getAttribute('data-moving'),'false');
 const c=p.locator('.service-card').first();await rail.evaluate(el=>el.scrollLeft=0);await c.click();await p.waitForSelector('.detail-hero h1');assert((await p.locator('.detail-hero h1').textContent()).includes('Антигравийная'));
 assert.deepEqual(errors,[]);await browser.close();console.log('PASS: seamless sections at 5 widths; image-only eased hover; growing rail, wheel, drag, keyboard, edge release; carousel and service navigation; no browser errors');
})().catch(e=>{console.error(e);process.exit(1)});
