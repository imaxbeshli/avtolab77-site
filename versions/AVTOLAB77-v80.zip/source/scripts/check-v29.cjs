const {chromium}=require('@playwright/test'),assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 for(const width of [390,320,768,1440]){
  const context=await browser.newContext({viewport:{width,height:width<650?844:900},isMobile:width<650,hasTouch:width<650});const page=await context.newPage(),errors=[],assets=[];
  page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(r.url().includes('/assets/'))assets.push(r.url())});
  await page.goto('http://localhost:4173/AVTOLAB77.html');await page.waitForSelector('.intro',{state:'detached',timeout:60000});
  await page.locator('.digital-transformation').scrollIntoViewIfNeeded();await page.waitForTimeout(1400);
  await page.evaluate(()=>document.fonts.ready);
  assert(await page.evaluate(()=>document.fonts.check('22px TabletChinese','导航空调设置')));
  const base=await page.locator('.digital-transformation').evaluate(el=>el.getBoundingClientRect().top+scrollY);
  const place=async p=>{await page.evaluate(({base,p})=>{const h=document.documentElement.clientHeight,start=h*.82,end=Math.max(78,h*.16);scrollTo({top:base-start+(start-end)*p,behavior:'instant'})},{base,p});await page.waitForTimeout(1100)};
  for(const p of [0,.29,.49,.69,1]){
   await place(p);const state=await page.locator('.digital-transformation').evaluate(el=>({p:+el.dataset.progress,z:+el.dataset.zoom,ru:[...el.querySelectorAll('.screen-ru')].map(x=>+x.getAttribute('opacity')),cn:[...el.querySelectorAll('.screen-cn')].map(x=>+x.getAttribute('opacity'))}));
   assert(Math.abs(state.p-p)<.003,JSON.stringify(state));assert(state.ru[0]>=state.ru[1]&&state.ru[1]>=state.ru[2]);
   state.ru.forEach((x,i)=>assert(Math.abs(x+state.cn[i]-1)<.0001));
   if(p===0)assert.deepEqual(state.ru,[0,0,0]);if(p===1){assert.deepEqual(state.ru,[1,1,1]);assert.equal(state.z,1.1)}
   if([390,1440].includes(width)&&(p===0||p===1))await page.screenshot({path:`/workspace/previews/v29-${width}-${p}.png`});
  }
  await place(.49);const initial=await page.locator('.digital-transformation').boundingBox();await page.mouse.wheel(0,100);await page.waitForTimeout(500);const end=await page.locator('.digital-transformation').boundingBox();assert(initial.y-end.y>80,'no pinned scene or wheel interception');
  await place(0);assert.equal(await page.locator('.screen-ru').first().getAttribute('opacity'),'0');
  await page.emulateMedia({reducedMotion:'reduce'});await place(1);assert.equal(await page.locator('.digital-transformation').getAttribute('data-zoom'),'1.0000');
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));assert.deepEqual(errors,[]);assert.deepEqual(assets,[]);
  await page.locator('.brand-logo').click();await page.waitForSelector('.digital-transformation');await page.waitForTimeout(300);assert.equal(await page.locator('.digital-transformation').getAttribute('data-progress'),'0.0000');
  console.log('PASS',width,'sequential language fade, 10% camera, reverse, native scroll, reduced motion, local font/images, remount');await context.close();
 }
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
