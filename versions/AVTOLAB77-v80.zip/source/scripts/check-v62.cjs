const {chromium}=require('@playwright/test'),assert=require('node:assert/strict');
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});try{
 for(const width of [390,1440]){
  const p=await browser.newPage({viewport:{width,height:740},hasTouch:width<600,isMobile:width<600});const errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.goto('http://localhost:4176/AVTOLAB77.html');await p.waitForTimeout(4200);await p.locator('.header button.primary').first().click();
  const d=p.locator('dialog[open]'),v=d.locator('.booking-map-viewport'),im=v.locator('img'),plus=d.getByRole('button',{name:'Приблизить карту'}),minus=d.getByRole('button',{name:'Отдалить карту'});
  await v.scrollIntoViewIfNeeded();await im.evaluate(e=>e.decode());assert(await minus.isDisabled());
  await plus.click();await p.waitForTimeout(260);assert.equal(await v.getAttribute('data-scale'),'1.400');
  let box=await v.boundingBox();await p.mouse.move(box.x+box.width/2,box.y+box.height/2);await p.mouse.down();await p.mouse.move(box.x+box.width*.9,box.y+box.height*.8,{steps:12});await p.mouse.up();
  let ib=await im.boundingBox();box=await v.boundingBox();assert(ib.x<=box.x+1&&ib.y<=box.y+1&&ib.x+ib.width>=box.x+box.width-1&&ib.y+ib.height>=box.y+box.height-1,'image always covers viewport');
  // Wheel over the map scrolls the panel, never the image.
  await d.locator('.booking-scroll').evaluate(e=>e.scrollTop=e.scrollHeight);box=await v.boundingBox();await p.mouse.move(box.x+box.width/2,Math.max(box.y+20,Math.min(box.y+box.height/2,650)));
  const oldScroll=await d.locator('.booking-scroll').evaluate(e=>e.scrollTop),oldScale=await v.getAttribute('data-scale');await p.mouse.wheel(0,-110);await p.waitForTimeout(250);assert(await d.locator('.booking-scroll').evaluate(e=>e.scrollTop)<oldScroll);assert.equal(await v.getAttribute('data-scale'),oldScale);
  await v.focus();await p.keyboard.press('Home');await p.waitForTimeout(250);assert.equal(await v.getAttribute('data-scale'),'1.000');
  for(let i=0;i<5;i++){if(await plus.isEnabled())await plus.click()}assert.equal(await v.getAttribute('data-scale'),'3.000');assert(await plus.isDisabled());
  await v.focus();await p.keyboard.press('Home');await p.waitForTimeout(250);
  if(width===390){
   await v.scrollIntoViewIfNeeded();box=await v.boundingBox();const x=box.x+box.width/2,y=box.y+box.height/2;const c=await p.context().newCDPSession(p);
   const touch=(type,spread)=>c.send('Input.dispatchTouchEvent',{type,touchPoints:spread?[{x:x-spread,y,id:1},{x:x+spread,y,id:2}]:[]});
   await touch('touchStart',25);for(const spread of [30,36,42,48,55])await touch('touchMove',spread);await touch('touchEnd',0);
   assert(Number(await v.getAttribute('data-scale'))>2,'native pinch zoom');assert.equal(await v.getAttribute('data-dragging'),'false');
   await touch('touchStart',55);for(const spread of [48,40,32,25,20])await touch('touchMove',spread);await touch('touchEnd',0);assert.equal(await v.getAttribute('data-scale'),'1.000');
   // Cancel releases captured state and subsequent gestures remain usable.
   await touch('touchStart',25);await c.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]});assert.equal(await v.getAttribute('data-dragging'),'false');
   await c.detach();
  }
  await plus.click();await d.locator('.close').click();await p.locator('.header button.primary').first().click();assert.equal(await v.getAttribute('data-scale'),'1.000');
  assert.match(await d.locator('.booking-route').getAttribute('href'),/yandex.ru\/maps/);assert.equal(await d.locator('iframe').count(),0);assert(await d.locator('.booking-scroll').evaluate(e=>e.scrollWidth<=e.clientWidth));
  await v.scrollIntoViewIfNeeded();await p.screenshot({path:`/workspace/previews/v62-map-${width}.png`});assert.deepEqual(errors,[]);console.log('PASS',width,'zoom limits, pan bounds, wheel, keyboard, reopen, route',width<600?'native pinch/cancel':'');await p.close();
 }
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exit(1)});
