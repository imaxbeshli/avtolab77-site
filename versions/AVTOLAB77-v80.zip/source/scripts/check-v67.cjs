const {chromium,expect}=require('@playwright/test'),assert=require('node:assert/strict');
(async()=>{
 const {GeoJSONVT}=await import('@maplibre/geojson-vt'),{fromGeojsonVt}=await import('@maplibre/vt-pbf');
 // Explicit synthetic test geometry: exercises the real renderer and gestures, not geographic correctness.
 const fixture=new GeoJSONVT({type:'FeatureCollection',features:[{type:'Feature',properties:{class:'minor'},geometry:{type:'LineString',coordinates:[[37.50,55.74],[37.56,55.77]]}},{type:'Feature',properties:{class:'primary'},geometry:{type:'LineString',coordinates:[[37.50,55.77],[37.56,55.74]]}}]},{maxZoom:14,indexMaxZoom:14});
 const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader']});
 try{for(const [width,height] of [[1440,900],[1366,768],[390,844],[320,640]]){
 const p=await b.newPage({viewport:{width,height},hasTouch:width<600,isMobile:width<600,reducedMotion:'reduce'}),errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.route('https://tiles.openfreemap.org/**',async r=>{const m=r.request().url().match(/latest\/(\d+)\/(\d+)\/(\d+)\.pbf/);if(!m)return r.abort();const t=fixture.getTile(...m.slice(1).map(Number));await r.fulfill({status:200,contentType:'application/x-protobuf',body:Buffer.from(fromGeojsonVt({transportation:t||{features:[]}}))});});
 await p.goto('http://localhost:4176/AVTOLAB77.html');await p.locator('.header button.primary').first().click();
 const d=p.locator('dialog[open]'),sc=d.locator('.booking-scroll'),map=d.locator('.booking-map'),canvas=d.locator('.maplibregl-canvas'),marker=d.locator('.studio-map-marker');
 await p.waitForFunction(()=>document.querySelector('dialog[open] .booking-map')?.dataset.mapStatus==='ready',{},{timeout:15000});
 assert.equal(await d.locator('.booking-phone a').getAttribute('href'),'tel:+74955065550');assert.equal(await d.locator('.booking-phone a').innerText(),'+7 (495) 506-55-50');
 assert.equal(await d.locator('.booking-socials a').count(),5);
 assert.equal(await d.locator('.booking-socials [aria-label="MAX"] svg').innerHTML(),await p.locator('.header-social .social-marks [aria-label="MAX"] svg').innerHTML());
 assert.equal(await d.locator('.maplibregl-ctrl-zoom-in,.maplibregl-ctrl-zoom-out').count(),0);
 assert(await sc.evaluate(e=>e.scrollWidth<=e.clientWidth));assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 if(width>820){const heads=await d.locator('.booking-layout h2').evaluateAll(es=>es.map(e=>e.getBoundingClientRect().top));assert(Math.abs(heads[0]-heads[1])<1);assert(await sc.evaluate(e=>e.scrollHeight<=e.clientHeight+1),'desktop panel fits');}
 await d.screenshot({path:'/tmp/v67-'+width+'.png'});
 // Other service still reveals required free-text input; layout remains scrollable if needed.
 await d.locator('select').selectOption('other');assert(await d.locator('textarea[required]').isVisible());await d.locator('select').selectOption('ppf');
 await map.scrollIntoViewIfNeeded();const attr=d.locator('.maplibregl-ctrl-attrib'),summary=attr.locator('summary');
 assert(!(await attr.locator('.maplibregl-ctrl-attrib-inner').isVisible()));
 const a=await attr.boundingBox(),s=await summary.boundingBox();assert(Math.abs(a.x+a.width/2-s.x-s.width/2)<.1&&Math.abs(a.y+a.height/2-s.y-s.height/2)<.1,'attribution centered');assert.equal(await summary.evaluate(e=>getComputedStyle(e).backgroundPosition),'50% 50%');
 await summary.click();assert(await attr.locator('.maplibregl-ctrl-attrib-inner').isVisible());assert.equal(await attr.locator('a').count(),3);await summary.click();
 if(width>820){
  let before=await marker.boundingBox();const cb=await canvas.boundingBox();const old=await sc.evaluate(e=>e.scrollTop);await p.mouse.move(cb.x+cb.width*.5,cb.y+cb.height*.65);await p.mouse.wheel(0,-180);await p.waitForTimeout(700);let after=await marker.boundingBox();assert(Math.abs(after.y-before.y)>3,'wheel zooms actual camera');assert.equal(await sc.evaluate(e=>e.scrollTop),old,'wheel over map does not scroll panel');before=after;await p.mouse.wheel(0,180);await p.waitForTimeout(700);after=await marker.boundingBox();assert(Math.abs(after.y-before.y)>3,'wheel zooms out');
 }else{
  await canvas.scrollIntoViewIfNeeded();const c=await p.context().newCDPSession(p);const box=await canvas.boundingBox(),x=box.x+box.width/2,y=box.y+box.height/2;let before=await marker.boundingBox();const old=await sc.evaluate(e=>e.scrollTop);
  const touch=async(type,pts)=>c.send('Input.dispatchTouchEvent',{type,touchPoints:pts});
  await touch('touchStart',[{x:x-25,y,id:1},{x:x+25,y,id:2}]);for(const n of [32,40,48,56])await touch('touchMove',[{x:x-n,y,id:1},{x:x+n,y,id:2}]);await touch('touchEnd',[]);await p.waitForTimeout(450);let after=await marker.boundingBox();assert(Math.abs(after.y-before.y)>3,'touch pinch zooms');assert.equal(await sc.evaluate(e=>e.scrollTop),old);
  before=after;await touch('touchStart',[{x,y,id:1}]);for(const n of [10,20,30,40])await touch('touchMove',[{x:x+n,y,id:1}]);await touch('touchEnd',[]);await p.waitForTimeout(450);after=await marker.boundingBox();assert(after.x>before.x+15,'one finger pans map');
  await sc.evaluate(e=>e.scrollTop=e.scrollHeight);const outside=await sc.boundingBox();const scrollBefore=await sc.evaluate(e=>e.scrollTop);const xx=outside.x+8,yy=height*.55;await touch('touchStart',[{x:xx,y:yy,id:1}]);for(const n of [20,40,60,80])await touch('touchMove',[{x:xx,y:yy+n,id:1}]);await touch('touchEnd',[]);await p.waitForTimeout(300);assert((await sc.evaluate(e=>e.scrollTop))<scrollBefore,'touch outside map scrolls panel');await c.detach();
 }
 await d.locator('.close').click();await p.waitForFunction(()=>!document.querySelector('dialog[open]'));await expect.poll(()=>p.workers().length).toBe(0);assert.deepEqual(errors,[]);console.log('PASS',width,height,'layout, phone, original MAX, attribution alignment/toggle, map gestures, cleanup');await p.close();
 }}finally{await b.close()}
})().catch(e=>{console.error(e);process.exit(1)});
