import React,{useEffect,useRef,useState} from 'react';
import {flushSync} from 'react-dom';
import {createRoot} from 'react-dom/client';
import {Home,Detail} from '../components/Site';
import {pageInfo,projects} from '../content/site';
import {services} from '../content/services';
import {createRouteTransition,isArticlePage,isHome,rememberServicePosition,resetHomeEntry} from '../components/service-navigation';
const locationPath=()=>window.location.hash.startsWith('#/')?window.location.hash.slice(1):'/';
function App(){
 const[route,setRoute]=useState(()=>({path:locationPath(),returnToServices:false}));
 const current=useRef(route.path);
 useEffect(()=>{
  const previousRestoration=history.scrollRestoration;history.scrollRestoration='manual';let requested=current.current;
  const commit=(href:string)=>{
   const returning=isHome(href)&&(isArticlePage(current.current)||/section=(services|projects|digital)/.test(href));
   current.current=href;
   document.querySelectorAll('dialog[open]').forEach(d=>(d as HTMLDialogElement).close());document.body.classList.remove('dialog-open');
   flushSync(()=>setRoute({path:href,returnToServices:returning}));
   if(!returning)window.scrollTo({top:0,behavior:'instant'});
  };
  const transition=createRouteTransition(commit);
  const navigate=(href:string,push=false)=>{
   if(href===requested)return;requested=href;
   if(push)history.pushState(null,'','#'+href);
   if(isArticlePage(href)||isArticlePage(current.current)||document.documentElement.dataset.routeTransition)void transition.run(href);else commit(href);
  };
  const handle=()=>navigate(locationPath());
  const click=(e:MouseEvent)=>{
   if(e.defaultPrevented||e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return;
   const a=(e.target as Element).closest<HTMLAnchorElement>('a'),href=a?.getAttribute('href');
   if(!a||!href?.startsWith('/')||a.hasAttribute('download')||(a.target&&a.target!=='_self'))return;
   e.preventDefault();if(isArticlePage(href))rememberServicePosition(a);navigate(href,true);
  };
  addEventListener('hashchange',handle);addEventListener('popstate',handle);document.addEventListener('click',click);
  return()=>{removeEventListener('hashchange',handle);removeEventListener('popstate',handle);document.removeEventListener('click',click);transition.destroy();history.scrollRestoration=previousRestoration};
 },[]);
 useEffect(()=>{const clean=route.path.split('?')[0].replace(/^\/+|\/+$/g,'');const title=pageInfo[clean]?.[0]??services.find(s=>clean.endsWith('/'+s.slug))?.title??projects.find(p=>clean==='projects/'+p.slug)?.title;document.title=(title?title+' — ':'')+'AVTOLAB77'},[route.path]);
 return isHome(route.path)?<Home key={route.path} returnToServices={route.returnToServices}/>:<Detail key={route.path} path={route.path}/>;
}
history.scrollRestoration='manual';
if(isHome(locationPath()))resetHomeEntry();
createRoot(document.getElementById('root')!).render(<App/>);
