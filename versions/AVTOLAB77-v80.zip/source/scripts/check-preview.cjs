const {chromium,expect}=require('@playwright/test');
const assert=require('node:assert/strict');
const preview='http://localhost:4173/AVTOLAB77.html';
const nextModel={'ZEEKR 9X':'ZEEKR 8X','ZEEKR 8X':'Lynk & Co 900','Lynk & Co 900':'ZEEKR 9X'};
async function settlePaint(page){
  await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
}
async function screenshot(page,file){
  await page.locator('.studio').scrollIntoViewIfNeeded();
  await settlePaint(page);
  await page.evaluate(()=>{document.documentElement.style.scrollBehavior='auto';window.scrollTo({top:0,behavior:'instant'});document.activeElement instanceof HTMLElement&&document.activeElement.blur()});
  await settlePaint(page);
  await page.screenshot({path:file,fullPage:true,animations:'disabled'});
}
(async()=>{
  const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking'],timeout:20000});
  try{
    const page=await browser.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1});
    const errors=[];page.on('pageerror',e=>errors.push(e.message));
    await page.goto(preview,{waitUntil:'load'});await page.evaluate(()=>document.fonts.ready);
    assert.equal(await page.locator('.header nav,.menu-toggle,.hero p,.hero .primary,.compatibility,.project-demo,.card-hover-arrow,.studio-link,footer').count(),0);
    assert.equal(await page.locator('.directions .round-arrow').count(),0);
    assert.equal(await page.locator('.projects-rail').innerText(),'');
    assert.deepEqual((await page.locator('.vehicle-card[aria-hidden="false"] .vehicle-name').allTextContents()).sort(),Object.keys(nextModel).sort());
    await expect(page.getByRole('heading',{name:'Услуги студии',exact:true})).toBeVisible();
    assert.equal(await page.locator('.studio-facts .fact').count(),4);
    await expect(page.locator('.guarantee')).toContainText('5 ЛЕТ');
    await expect(page.locator('.guarantee')).toContainText('гарантии на любое эксплуатационное повреждение');
    assert(await page.locator('.logo-art').evaluate(el=>getComputedStyle(el).backgroundImage.includes('data:image/webp')));
    await screenshot(page,'/workspace/previews/AVTOLAB77-desktop.png');
    for(const width of [320,360,390,430,768,1024,1280,1440,1920]){
      await page.setViewportSize({width,height:1000});
      const dims=await page.evaluate(()=>({scroll:document.documentElement.scrollWidth,width:innerWidth}));
      assert(dims.scroll<=dims.width,`Overflow at ${width}: ${dims.scroll}`);
      console.log('Layout',width,'OK');
    }
    await page.setViewportSize({width:1440,height:1000});
    const selected=page.locator('.selected .vehicle-name');
    const carousel=page.locator('.vehicle-carousel');
    await carousel.scrollIntoViewIfNeeded();
    await carousel.hover();
    let before=await selected.innerText();
    const scroll=await page.evaluate(()=>scrollY);
    await page.mouse.wheel(0,125);
    await expect(selected).toHaveText(nextModel[before]);
    assert.equal(await page.evaluate(()=>scrollY),scroll,'Wheel must select vehicle while over carousel');
    console.log('Mouse wheel: PASS');
    // Full forward and reverse cycles must wrap without crossing the visible stage.
    for(const direction of [1,-1]){
      for(let count=0;count<3;count++){
        before=await selected.innerText();
        const expected=direction===1?nextModel[before]:Object.keys(nextModel).find(key=>nextModel[key]===before);
        const leaving=page.locator('.vehicle-card[data-slot="-1"]');
        await page.getByRole('button',{name:direction===1?'Следующий автомобиль':'Предыдущий автомобиль'}).click();
        if(direction===1){
          const position=await leaving.evaluate(el=>getComputedStyle(el).getPropertyValue('--position').trim());
          assert.equal(position,'-2','Outgoing left vehicle must move further left, not across the centre');
        }
        await expect(selected).toHaveText(expected);
        await expect(carousel).toHaveAttribute('data-moving','false');
      }
    }
    console.log('Circular animation in both directions: PASS');
    await carousel.focus();before=await selected.innerText();
    await page.keyboard.press('ArrowRight');await expect(selected).toHaveText(nextModel[before]);
    const box=await carousel.boundingBox();before=await selected.innerText();
    await page.mouse.move(box.x+box.width/2+70,box.y+box.height/2);
    await page.mouse.down();await page.mouse.move(box.x+box.width/2-90,box.y+box.height/2,{steps:12});await page.mouse.up();
    await expect(selected).toHaveText(nextModel[before]);
    assert.equal(await page.locator('.is-dragging').count(),0);
    console.log('Keyboard and mouse drag: PASS');
    await page.setViewportSize({width:390,height:844});
    await screenshot(page,'/workspace/previews/AVTOLAB77-mobile.png');
    await page.locator('.directions a').first().click();
    await expect(page.getByRole('heading',{name:'Автостайлинг и детейлинг',exact:true})).toBeVisible();
    await page.locator('.catalog-card').first().click();
    await expect(page.getByRole('heading',{name:'Антигравийная защита',exact:true})).toBeVisible();
    await page.getByRole('button',{name:'Обсудить мой автомобиль'}).click();
    const dialog=page.locator('dialog[open]');
    await dialog.getByLabel('Ваше имя').fill('Тест');await dialog.getByLabel('Телефон',{exact:true}).fill('+7 999 123 45 67');
    await dialog.getByRole('button',{name:'Проверить заявку'}).click();await expect(page.getByText('Всё заполнено правильно')).toBeVisible();
    await page.keyboard.press('Escape');assert.equal(await page.locator('dialog[open]').count(),0);
    await page.locator('.header .logo').click();await page.locator('.projects-rail a').first().click();
    await expect(page.getByRole('heading',{name:'Защита без компромиссов',exact:true})).toBeVisible();
    console.log('Navigation, form, ESC and project details: PASS');

    const mobileContext=await browser.newContext({viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:1});
    const mobile=await mobileContext.newPage();mobile.on('pageerror',e=>errors.push(e.message));
    await mobile.goto(preview,{waitUntil:'load'});await mobile.evaluate(()=>document.fonts.ready);
    await mobile.locator('.vehicle-carousel').scrollIntoViewIfNeeded();
    await mobile.evaluate(()=>document.documentElement.style.scrollBehavior='auto');
    const region=await mobile.locator('.vehicle-carousel').boundingBox();
    const x=region.x+region.width/2,y=region.y+region.height/2;
    const cdp=await mobileContext.newCDPSession(mobile);
    before=await mobile.locator('.selected .vehicle-name').innerText();
    await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:x+65,y}]});
    for(let step=1;step<=8;step++)await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x+65-step*18,y:y+2}]});
    await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
    await expect(mobile.locator('.selected .vehicle-name')).toHaveText(nextModel[before]);
    console.log('Touch swipe: PASS');
    const top=await mobile.evaluate(()=>scrollY);
    await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y:y+50}]});
    for(let step=1;step<=8;step++)await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x+1,y:y+50-step*20}]});
    await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
    await expect.poll(()=>mobile.evaluate(()=>scrollY)).toBeGreaterThan(top+30);
    console.log('Vertical touch scrolling remains available: PASS');
    await mobileContext.close();assert.deepEqual(errors,[]);console.log('No JavaScript errors. All checks passed.');
  }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exit(1)});
