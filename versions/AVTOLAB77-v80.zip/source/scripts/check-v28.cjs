const {chromium}=require('@playwright/test');
const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 for(const [width,height,mobile] of [[390,844,true],[320,640,true],[844,390,true],[768,1024,true],[1440,900,false],[1920,1080,false]]){
  const context=await browser.newContext({viewport:{width,height},isMobile:mobile,hasTouch:mobile});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://localhost:4173/AVTOLAB77.html');
  await page.waitForSelector('.intro',{state:'detached',timeout:60000});
  await page.waitForSelector('.styling-sequence[data-scene-state="ready"]');
  if(!mobile)assert(await page.locator('.styling-heading').evaluate(el=>el.getBoundingClientRect().top>=innerHeight),'desktop hero unchanged');
  if(mobile&&width<650){const bounds=await page.locator('.hero').boundingBox();assert(bounds.height<500,'compact mobile opening');const heading=await page.locator('.hero h1').boundingBox();assert(heading.y<160,'heading near header');}
  if(width===390||width===1440)await page.screenshot({path:`/workspace/previews/v28-hero-${width}.png`});
  const top=await page.locator('.styling-sequence').evaluate(el=>el.getBoundingClientRect().top+scrollY);
  const scroll=async y=>{await page.evaluate(y=>scrollTo({top:y,behavior:'instant'}),y);await page.waitForTimeout(900)};
  if(mobile){
   assert.equal(await page.locator('.styling-stage').evaluate(el=>getComputedStyle(el).position),'relative');
   const heroHeight=await page.locator('.hero').evaluate(el=>el.clientHeight);
   await scroll(top-heroHeight*.76);
   assert.equal(await page.locator('.styling-stage').getAttribute('data-coat'),'0.0000');
   const before=await page.locator('.styling-transform-photo').boundingBox();
   await scroll(top-heroHeight*.76+100);
   const after=await page.locator('.styling-transform-photo').boundingBox();
   assert(Math.abs(before.y-after.y-100)<1,'photo follows page, no pinning');
   await scroll(top-Math.max(64,heroHeight*.15));
   assert.equal(await page.locator('.styling-stage').getAttribute('data-lights'),'1.0000');
   const spacing=await page.evaluate(()=>{const h=document.querySelector('.styling-heading').getBoundingClientRect(),img=document.querySelector('.styling-transform-photo').getBoundingClientRect(),stage=document.querySelector('.styling-stage').getBoundingClientRect(),rail=document.querySelector('.service-rail').getBoundingClientRect();return{carGap:img.y+img.height*.30-h.bottom,railGap:rail.y-stage.bottom}});
   assert(spacing.carGap<70,JSON.stringify(spacing));assert(spacing.railGap<40,JSON.stringify(spacing));
   if(width===390)await page.screenshot({path:'/workspace/previews/v28-mobile-scene.png'});
   // Native touch must move both the page and the BMW by the same amount.
   await scroll(top-heroHeight*.5);
   const initial=await page.evaluate(()=>({y:scrollY,scene:document.querySelector('.styling-stage').getBoundingClientRect().y}));
   const cdp=await context.newCDPSession(page);
   await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:width/2,y:height*.7}]});
   for(let i=1;i<=8;i++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:width/2,y:height*.7-i*12}]});await page.waitForTimeout(25)}
   await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await page.waitForTimeout(800);
   const end=await page.evaluate(()=>({y:scrollY,scene:document.querySelector('.styling-stage').getBoundingClientRect().y}));
   assert(end.y>initial.y+30);assert(Math.abs((end.y-initial.y)-(initial.scene-end.scene))<2);
  }else{
   const dims=await page.locator('.styling-sequence').evaluate(el=>{const stage=el.firstElementChild;return{travel:el.offsetHeight-stage.offsetHeight,inset:parseFloat(getComputedStyle(stage).top)}});
   for(const p of [0,.45,.76,.97]){
    await scroll(top-dims.inset+dims.travel*p);
    const state=await page.locator('.styling-stage').evaluate(el=>({y:el.getBoundingClientRect().y,p:+el.dataset.progress,lights:+el.dataset.lights}));
    assert(Math.abs(state.y-dims.inset)<1);assert(Math.abs(state.p-p)<.003);
    if(p===.97){assert.equal(state.lights,1);if(width===1440)await page.screenshot({path:'/workspace/previews/v28-desktop-scene.png'});}
   }
  }
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'horizontal overflow');assert.deepEqual(errors,[]);
  console.log('PASS',width,height,mobile?'native mobile scene':'desktop sticky sequence');await context.close();
 }
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
