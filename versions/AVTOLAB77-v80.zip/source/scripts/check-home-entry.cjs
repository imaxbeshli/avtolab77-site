const {chromium}=require('@playwright/test'),assert=require('node:assert/strict');
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader']});try{
for(const width of [390,1440])for(const suffix of ['', '?v=71#/?section=services','?section=services']){
 const p=await b.newPage({viewport:{width,height:900},reducedMotion:'reduce'});
 await p.addInitScript(()=>sessionStorage.setItem('avtolab:service-position-v70',JSON.stringify({y:1800,left:400,card:'/services/styling/polishing',top:100})));
 await p.goto('http://localhost:4176/AVTOLAB77.html'+suffix);await p.locator('.home-scene').waitFor();await p.waitForTimeout(250);assert.equal(await p.evaluate(()=>scrollY),0);assert(!p.url().includes('section=services'));
 await p.evaluate(()=>scrollTo(0,600));assert(await p.evaluate(()=>scrollY)>100);await p.reload();await p.locator('.home-scene').waitFor();await p.waitForTimeout(250);assert.equal(await p.evaluate(()=>scrollY),0);console.log('PASS fresh/reload starts at hero',width,suffix||'root');await p.close();
}
const p=await b.newPage({viewport:{width:390,height:844}});await p.goto('http://localhost:4176/AVTOLAB77.html#/?section=services');await p.locator('.intro').waitFor();assert.equal(await p.evaluate(()=>scrollY),0);await p.locator('.intro').waitFor({state:'detached',timeout:20000});assert.equal(await p.evaluate(()=>scrollY),0);console.log('PASS opening logo and hero retained on legacy link');await p.close();
const next=await b.newPage({reducedMotion:'reduce'});await next.goto('http://localhost:4178/?section=services');await next.locator('.home-scene').waitFor();await next.waitForTimeout(400);assert.equal(await next.evaluate(()=>scrollY),0);assert(!next.url().includes('section=services'));console.log('PASS Next fresh home entry');
}finally{await b.close()}})().catch(e=>{console.error(e);process.exit(1)});
