const {chromium}=require('@playwright/test');
const assert=require('node:assert/strict');
const slugs=['firmware','tcam','number','account','sim','apps'];
const idle=p=>p.waitForFunction(()=>!document.documentElement.dataset.routeTransition);
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader']});
 try{
  for(const width of [320,390,1440,2560]){
   const p=await browser.newPage({viewport:{width,height:900},reducedMotion:'reduce'}),errors=[];
   p.on('pageerror',e=>errors.push(e.message));
   for(const slug of slugs){
    await p.goto('http://localhost:4178/services/digital/'+slug+'/');
    await p.locator('.service-article--digital').waitFor();
    await p.evaluate(()=>document.fonts.ready);
    const result=await p.evaluate(()=>{
     const article=document.querySelector('.service-article'),img=article.querySelector('.service-article-hero img'),h=article.querySelector('h1');
     return {overflow:document.documentElement.scrollWidth>innerWidth,text:article.textContent,loaded:img.complete&&img.naturalWidth>0,align:getComputedStyle(h).textAlign,examples:article.querySelectorAll('.service-examples').length,returns:article.querySelectorAll('.service-return').length};
    });
    assert.equal(result.overflow,false,slug+' overflow '+width);assert(result.loaded,slug+' hero');assert.equal(result.align,'center');assert.equal(result.examples,0);assert.equal(result.returns,1);assert(!/ZEEKR|ZICER|Частые вопросы|ДЕМОНСТРАЦИЯ/.test(result.text));
    await p.locator('.service-booking').scrollIntoViewIfNeeded();await p.locator('.service-booking > button.primary').click();await p.locator('dialog[open]').waitFor();await p.keyboard.press('Escape');
    await p.evaluate(()=>scrollTo(0,0));
    if(width===390||width===1440||(width===2560&&slug==='firmware'))await p.screenshot({path:'/workspace/previews/digital-'+slug+'-'+width+'.png',fullPage:true});
   }
   assert.deepEqual(errors,[]);console.log('PASS all digital pages: content, layout, images and booking',width);await p.close();
  }
  for(const [base,hash] of [['http://localhost:4176/AVTOLAB77-live.html',true],['http://localhost:4178/',false]]){
   for(const width of [390,1440]){
    const p=await browser.newPage({viewport:{width,height:900}}),errors=[];p.on('pageerror',e=>errors.push(e.message));
    await p.goto(base);await p.locator('.intro').waitFor({state:'detached',timeout:20000});
    const card=p.locator('.home-scene .digital-grid a').nth(1);await card.scrollIntoViewIfNeeded();await p.waitForTimeout(1200);
    const top=await p.locator('.digital-grid').evaluate(e=>e.getBoundingClientRect().top);
    await card.click();await p.waitForTimeout(80);assert.equal(await p.locator('.home-scene').count(),1,'old page visible during fade');
    await p.locator('.service-article').waitFor();await idle(p);assert.equal(await p.evaluate(()=>scrollY),0);
    await p.locator('.service-return').click();await p.locator('.home-scene').waitFor();await idle(p);
    assert.equal(await p.locator('.intro').count(),0);const restored=await p.locator('.digital-grid').evaluate(e=>e.getBoundingClientRect().top);assert(Math.abs(top-restored)<4,JSON.stringify({top,restored}));
    if(hash){await p.goBack();await p.locator('.service-article').waitFor();await idle(p);await p.goForward();await p.locator('.home-scene').waitFor();await idle(p)}
    assert.deepEqual(errors,[]);console.log('PASS smooth digital navigation and scroll restoration',hash?'standalone':'Next',width);await p.close();
   }
  }
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exit(1)});
