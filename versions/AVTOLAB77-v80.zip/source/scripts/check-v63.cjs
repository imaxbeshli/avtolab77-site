const {chromium}=require('@playwright/test'),assert=require('node:assert/strict');
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});try{for(const width of [320,390,1440]){
 const p=await b.newPage({viewport:{width,height:844},reducedMotion:'reduce'}),errors=[];p.on('pageerror',e=>errors.push(e.message));
 // Yandex is blocked by workspace network policy. Check integration and hit-testing,
 // not the third-party map's contents or zoom behavior.
 await p.route('https://yandex.ru/**',r=>r.abort());await p.goto('http://localhost:4176/AVTOLAB77.html');assert.equal(await p.locator('.booking-map iframe').count(),0);
 await p.locator('.header button.primary').first().click();const d=p.locator('dialog[open]'),frame=d.locator('.booking-map iframe');await frame.scrollIntoViewIfNeeded();
 const src=new URL(await frame.getAttribute('src'));assert.equal(src.hostname,'yandex.ru');assert.equal(src.searchParams.get('oid'),'98750739355');
 assert.equal(await frame.getAttribute('aria-hidden'),null);assert.equal(await frame.getAttribute('tabindex'),null);assert.equal(await frame.evaluate(e=>getComputedStyle(e).pointerEvents),'auto');
 assert.equal(await d.locator('.booking-map-image,.booking-map-link,.booking-map-controls').count(),0);
 const hit=await frame.evaluate(e=>{const r=e.getBoundingClientRect();return document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)===e});assert(hit,'iframe receives input directly');
 assert.equal(await d.locator('.booking-map').evaluate(e=>getComputedStyle(e,'::after').pointerEvents),'none');await frame.focus();assert(await frame.evaluate(e=>document.activeElement===e));
 assert(await d.locator('.booking-scroll').evaluate(e=>e.scrollWidth<=e.clientWidth));assert.match(await d.locator('.booking-route').getAttribute('href'),/rtext=/);
 await d.locator('.close').click();await p.waitForFunction(()=>document.querySelectorAll('.booking-map iframe').length===0);
 await p.locator('.header button.primary').first().click();assert.equal(await d.locator('iframe').count(),1);await p.keyboard.press('Escape');await p.waitForFunction(()=>document.querySelectorAll('.booking-map iframe').length===0);
 assert.deepEqual(errors,[]);console.log('PASS',width,'live widget URL, direct pointer/focus access, route, open/close lifecycle, no overflow');await p.close();
 }}finally{await b.close()}})().catch(e=>{console.error(e);process.exit(1)});
