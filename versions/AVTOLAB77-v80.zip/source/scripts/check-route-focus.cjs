const {chromium}=require('@playwright/test');
const assert=require('node:assert/strict');
const idle=p=>p.waitForFunction(()=>!document.documentElement.dataset.routeTransition);
const focusState=p=>p.evaluate(()=>({tag:document.activeElement.tagName,outline:getComputedStyle(document.activeElement).outlineStyle,visible:document.activeElement.matches(':focus-visible')}));
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader']});
 try{
  const urls=process.env.FOCUS_TEST_URL?[process.env.FOCUS_TEST_URL]:['http://localhost:4176/AVTOLAB77-live.html','http://localhost:4178/'];
  for(const url of urls)for(const width of [390,1440]){
   const mobile=width===390,p=await browser.newPage({viewport:{width,height:844},isMobile:mobile,hasTouch:mobile}),errors=[];
   p.on('pageerror',e=>errors.push(e.message));
   await p.goto(url);await p.locator('.intro').waitFor({state:'detached',timeout:20000});
   const activate=locator=>mobile?locator.tap():locator.click();
   for(const selector of ['.service-card[href="/services/styling/polishing"]','.digital-grid a','.projects-rail a']){
    const card=p.locator(selector).first();await card.scrollIntoViewIfNeeded();await p.waitForTimeout(1000);
    await activate(card);await p.locator('.service-article').waitFor();await idle(p);
    assert.equal((await focusState(p)).tag,'H1');assert.equal((await focusState(p)).outline,'none','pointer heading ring');
    // Simulate a browser retaining :focus-visible during programmatic focus.
    const cdp=await p.context().newCDPSession(p);await cdp.send('DOM.enable');await cdp.send('CSS.enable');
    const {root}=await cdp.send('DOM.getDocument');const {nodeId}=await cdp.send('DOM.querySelector',{nodeId:root.nodeId,selector:'.service-article h1'});
    await cdp.send('CSS.forcePseudoState',{nodeId,forcedPseudoClasses:['focus','focus-visible']});
    assert.equal((await focusState(p)).outline,'none','pointer heading ring with retained focus-visible');
    await cdp.send('CSS.forcePseudoState',{nodeId,forcedPseudoClasses:[]});await cdp.detach();
    await activate(p.locator('.service-return'));await p.locator('.home-scene').waitFor();await idle(p);
    assert.equal((await focusState(p)).tag,'A');assert.equal((await focusState(p)).outline,'none','pointer return ring');
    assert.equal(await p.locator('.intro').count(),0);
    // Keyboard interaction must restore its visible focus and allow Enter.
    await p.keyboard.press('Tab');assert.equal((await focusState(p)).outline,'solid','Tab focus must remain visible');
    await p.keyboard.press('Shift+Tab');await p.keyboard.press('Enter');await p.locator('.service-article').waitFor();await idle(p);
    assert.equal((await focusState(p)).tag,'H1');assert.equal((await focusState(p)).outline,'solid','keyboard heading ring');
    await p.locator('.service-return').focus();await p.keyboard.press('Enter');await p.locator('.home-scene').waitFor();await idle(p);
    assert.equal((await focusState(p)).outline,'solid','keyboard return ring');
   }
   assert.deepEqual(errors,[]);console.log('PASS pointer/touch focus, retained focus-visible and keyboard access for services/digital/projects',width,url);await p.close();
  }
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exit(1)});
