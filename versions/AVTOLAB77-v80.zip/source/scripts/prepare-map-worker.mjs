import {build} from 'esbuild';
import {writeFile} from 'node:fs/promises';
const result=await build({entryPoints:['node_modules/maplibre-gl/dist/maplibre-gl-worker.mjs'],bundle:true,minify:true,write:false,format:'esm',target:['es2022'],legalComments:'inline'});
await writeFile('content/map-worker.generated.json',JSON.stringify({code:result.outputFiles[0].text}));
console.log('MapLibre worker bundled for standalone and Next previews');
