// Check the actual Pages/standalone export, not only Next's public directory.
const {chromium}=require('@playwright/test');
const assert=require('node:assert/strict');
const slugs=['firmware','tcam','number','account','sim','apps'];
const titles=['Русификация и настройка','Телематика TCAM','Китайский номер','Мастер-аккаунт','SIM-карты для TCAM','Установка приложений'];
const bases=process.env.DIGITAL_EXPORT_URL?[process.env.DIGITAL_EXPORT_URL]:[
 'http://localhost:4176/AVTOLAB77-live.html',
 'http://localhost:4176/AVTOLAB77.html',
];
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 try{
  for(const base of bases){
   for(const width of [390,1440]){
    const p=await browser.newPage({viewport:{width,height:844},isMobile:width===390,hasTouch:width===390}),errors=[],missing=[];
    p.on('pageerror',e=>errors.push(e.message));
    p.on('requestfailed',r=>{if(r.resourceType()==='image')missing.push(r.url())});
    p.on('response',r=>{if(r.request().resourceType()==='image'&&r.status()>=400)missing.push(r.url())});
    await p.goto(base+'#/services/digital/firmware');
    for(const slug of slugs){
     if(slug!=='firmware')await p.evaluate(s=>{location.hash='/services/digital/'+s},slug);
     await p.waitForFunction(title=>document.querySelector('.service-article h1')?.textContent===title&&!document.documentElement.dataset.routeTransition,titles[slugs.indexOf(slug)]);
     const img=p.locator('.service-article-hero img');
     await img.evaluate(i=>i.decode());
     const data=await img.evaluate(i=>({width:i.naturalWidth,height:i.naturalHeight,embedded:i.currentSrc.startsWith('data:image/webp;base64,'),visible:i.getBoundingClientRect().width>0}));
     assert.equal(data.width,1672,slug);assert.equal(data.height,941,slug);assert(data.embedded,slug+' must be embedded in Pages/offline release');assert(data.visible);
     await p.waitForTimeout(900);
     assert.equal(await img.evaluate(i=>getComputedStyle(i.parentElement).opacity),'1');
     assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
     if(width===390&&slug==='firmware')await p.screenshot({path:'/workspace/previews/digital-export-fixed-mobile.png'});
    }
    assert.deepEqual(errors,[]);assert.deepEqual(missing,[]);console.log('PASS all six exported images decode, reveal, no failed image requests',width,base);await p.close();
   }
  }
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exit(1)});
