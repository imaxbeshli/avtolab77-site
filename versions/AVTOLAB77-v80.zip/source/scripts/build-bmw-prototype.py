from pathlib import Path
import base64
root=Path(__file__).resolve().parents[1];folder=root/'prototypes/bmw-scroll-v1'
s=(folder/'template.html').read_text()
for marker,path,mime in [('GLOSS',folder/'gloss-off.webp','image/webp'),('MATTE',folder/'matte-off.webp','image/webp'),('LIGHTS',folder/'gloss-on.webp','image/webp'),('FONT_CYR',root/'public/assets/fonts/manrope-cyrillic-500-normal.woff2','font/woff2'),('FONT_LAT',root/'public/assets/fonts/manrope-latin-500-normal.woff2','font/woff2')]:
 s=s.replace('__'+marker+'__','data:'+mime+';base64,'+base64.b64encode(path.read_bytes()).decode())
out=Path('/workspace/previews/bmw-scroll-v1.html');out.write_text(s);print(out,round(len(s)/1024),'KiB')
