const {chromium}=require('@playwright/test');
const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:1440,height:900}});
 const errors=[],externalAssets=[];
 page.on('pageerror',e=>errors.push(e.message));
 page.on('request',r=>{if(r.url().includes('/assets/'))externalAssets.push(r.url())});
 await page.goto('http://localhost:4173/AVTOLAB77.html');
 await page.waitForSelector('.intro',{state:'detached',timeout:60000});
 await page.waitForSelector('.styling-sequence[data-scene-state="ready"]');
 assert.equal(await page.getByText(/ПРОТОТИП|Прокрутите вниз|Глянец становится|Подготавливаем сцену/).count(),0);
 assert.equal(await page.locator('.styling-stage h2').textContent(),'Автостайлинг и детейлинг');
 const place=async progress=>{
  await page.evaluate(progress=>{
   const section=document.querySelector('.styling-sequence'),stage=document.querySelector('.styling-stage');
   const inset=parseFloat(getComputedStyle(stage).top);
   const top=section.getBoundingClientRect().top+scrollY;
   scrollTo({top:top-inset+(section.offsetHeight-stage.offsetHeight)*progress,behavior:'instant'});
  },progress);
  await page.waitForTimeout(1200);
 };
 for(const width of [1440,390,320,768]){
  await page.setViewportSize({width,height:width<650?844:900});
  for(const progress of [0,.45,.76,.97]){
   await place(progress);
   const state=await page.locator('.styling-stage').evaluate(el=>({p:+el.dataset.progress,coat:+el.dataset.coat,lights:+el.dataset.lights,y:el.getBoundingClientRect().y,inset:parseFloat(getComputedStyle(el).top)}));
   assert(Math.abs(state.p-progress)<.003,JSON.stringify(state));
   assert(Math.abs(state.y-state.inset)<1,'stage remains pinned');
   if(progress<=.76)assert.equal(state.lights,0);
   if(progress>.9)assert.equal(state.lights,1);
   assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'page overflow');
   if([1440,390].includes(width))await page.screenshot({path:`/workspace/previews/v26-${width}-${progress}.png`});
  }
  await place(1.2);
  assert(await page.locator('.styling-stage').evaluate(el=>el.getBoundingClientRect().y<parseFloat(getComputedStyle(el).top)-30),'stage releases');
  await page.locator('.service-rail').scrollIntoViewIfNeeded();await page.waitForTimeout(1200);
  if([1440,390].includes(width))await page.screenshot({path:`/workspace/previews/v26-exit-${width}.png`});
 }
 await place(.45);await place(0);
 assert.equal(await page.locator('.styling-stage').getAttribute('data-coat'),'0.0000');
 await page.locator('.service-card').first().click();await page.waitForSelector('.detail-hero h1');
 assert((await page.locator('.detail-hero h1').textContent()).includes('Антигравийная'));
 await page.locator('.brand-logo').click();await page.waitForSelector('.styling-sequence[data-scene-state="ready"]');
 await page.emulateMedia({reducedMotion:'reduce'});await place(.97);
 assert.equal(await page.locator('.styling-stage').getAttribute('data-lights'),'1.0000');
 assert.deepEqual(errors,[]);assert.deepEqual(externalAssets,[]);
 await browser.close();console.log('PASS: integrated 4-stage sequence at 4 widths; pinned/released correctly; no demo UI or external image requests; reverse scroll, detail/home remount and reduced motion');
})().catch(e=>{console.error(e);process.exit(1)});
