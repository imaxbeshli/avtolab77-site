"""Prepare lightweight Pages from an already pushed archive release.
Usage: python3 scripts/publish-archived.py /tmp/avtolab77-archives /tmp/avtolab77-pages
Does not commit or push. Keeps original release bytes in the archive branch.
"""
from pathlib import Path
import json,hashlib,subprocess,html,sys,shutil
arc,root=map(Path,sys.argv[1:]);records=json.loads((root/'versions/manifest.json').read_text());new=json.loads((arc/'versions/manifest.json').read_text())[-1];previous=records[-1]
assert not any(r['version']==new['version'] for r in records)
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=arc,text=True).strip();base=f'https://raw.githubusercontent.com/imaxbeshli/avtolab77-site/{sha}/versions/'
new.update(storage_commit=sha,archive_url=base+new['archive'])
page=(arc/'versions'/f"{new['version']}.html").read_bytes();assert hashlib.sha256(page).hexdigest()==new['index_sha256'];assert hashlib.sha256((arc/'versions'/new['archive']).read_bytes()).hexdigest()==new['archive_sha256']
if new.get('live_index_sha256'):
 page=(arc/'versions'/f"{new['version']}.live.html").read_bytes();assert hashlib.sha256(page).hexdigest()==new['live_index_sha256']
 for item in new['project_media']:
  source=Path(__file__).resolve().parents[1]/'public'/item['path'];assert hashlib.sha256(source.read_bytes()).hexdigest()==item['sha256']
  target=root/item['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
if new.get('original_photos_archive'):
 assert hashlib.sha256((arc/'versions'/new['original_photos_archive']).read_bytes()).hexdigest()==new['original_photos_sha256']
 new['original_photos_url']=base+new['original_photos_archive']
def redirect(url):
 return '<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="0;url='+html.escape(url,quote=True)+'"><title>AVTOLAB77</title><a href="'+html.escape(url,quote=True)+'">Открыть</a></html>'
def loader(r):
 url=f"https://raw.githubusercontent.com/imaxbeshli/avtolab77-site/{r['storage_commit']}/versions/{r['version']}.html"
 return '''<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AVTOLAB77 — VERSION</title><style>body{background:#050607;color:#ddd;font:16px system-ui;text-align:center;padding-top:15vh}a{color:#fff}</style><p id="status">Загружаем сохранённую версию…</p><a href="ARCHIVE">Скачать эту версию</a><script>(async()=>{try{const r=await fetch(URL);if(!r.ok)throw Error('load');const bytes=await r.arrayBuffer();const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(b=>b.toString(16).padStart(2,'0')).join('');if(hash!==HASH)throw Error('integrity');document.open();document.write(new TextDecoder().decode(bytes));document.close()}catch{document.getElementById('status').textContent='Не удалось загрузить страницу. Можно скачать сохранённую версию по ссылке ниже.'}})();</script></html>'''.replace('VERSION',r['version']).replace('ARCHIVE',html.escape(r['archive_url'],quote=True)).replace('URL',json.dumps(url)).replace('HASH',json.dumps(r['index_sha256']))
old=previous['version'];v=new['version']
(root/'versions'/f'{old}.html').write_text(loader(previous));(root/f'preview-r{old[1:]}.html').write_text(redirect(f'./versions/{old}.html'))
(root/'index.html').write_bytes(page);(root/f'preview-r{v[1:]}.html').write_text(redirect(f'./index.html?v={v[1:]}'));(root/'versions'/f'{v}.html').write_text(redirect(f'../index.html?v={v[1:]}'))
p=root/'versions'/new['archive'];p.mkdir();(p/'index.html').write_text(redirect(new['archive_url']))
p=root/'versions/index.html';s=p.read_text().replace(old+' — текущая',old);entry=f'<article><h2>{v} — текущая</h2><p>{html.escape(new["description"])}</p><a href="{v}.html">Посмотреть</a><a href="{new["archive_url"]}" download>Скачать ZIP</a><small>Сайт + исходники</small></article>';p.write_text(s.replace('<article>',entry+'<article>',1))
records.append(new);(root/'versions/manifest.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
# v72 adds 97 lazy project photos. Keep separate limits for initial HTML and
# total deployed assets; photos must never be embedded in the live HTML.
assert len(page)<19*1024*1024,'Initial page exceeds 19 MiB budget'
size=sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and '.git' not in p.parts);assert size<30*1024*1024, 'Pages assets exceed 30 MiB project-gallery budget';print(f'{v}: {size/1024/1024:.2f} MiB; {old} pinned to its original snapshot; archive verified')
