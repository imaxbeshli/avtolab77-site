const {chromium}=require('@playwright/test'),assert=require('node:assert/strict');
const idle=p=>p.waitForFunction(()=>!document.documentElement.dataset.routeTransition);
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader']});try{
for(const width of [390,1440]){
 const p=await b.newPage({viewport:{width,height:900}}),errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.goto('http://localhost:4176/AVTOLAB77.html#/?section=services');await p.locator('.service-rail').waitFor();await p.locator('.intro').waitFor({state:'detached',timeout:20000});await p.evaluate(()=>document.fonts.ready);await p.locator('.service-rail').scrollIntoViewIfNeeded();
 const card=p.locator('.service-card[href="/services/styling/polishing"]');await card.scrollIntoViewIfNeeded();await p.waitForTimeout(1100);
 const position=await p.evaluate(()=>({y:scrollY,left:document.querySelector('.service-rail').scrollLeft}));
 await card.click();await p.waitForTimeout(80);assert.equal(await p.locator('.route-curtain').evaluate(e=>e.hidden),false);assert.equal(await p.locator('.home-scene').count(),1,'old page remains during fade-out');
 await p.locator('.service-article').waitFor();await idle(p);assert.equal(await p.evaluate(()=>scrollY),0);assert.equal(await p.locator('.service-article h1').innerText(),'Полировка');
 await p.locator('.service-return').click();await p.waitForTimeout(80);assert.equal(await p.locator('.service-article').count(),1);await p.locator('.home-scene').waitFor();await idle(p);assert.equal(await p.locator('.intro').count(),0);
 const restored=await p.evaluate(()=>({y:scrollY,left:document.querySelector('.service-rail').scrollLeft}));assert(Math.abs(restored.y-position.y)<3,JSON.stringify({position,restored}));assert(Math.abs(restored.left-position.left)<3);
 await p.goBack();await p.locator('.service-article').waitFor();await idle(p);await p.goForward();await p.locator('.home-scene').waitFor();await idle(p);
 // A browser Back during fade-out must cancel the superseded destination.
 await card.click();await p.goBack();await idle(p);await p.waitForTimeout(350);assert.equal(await p.locator('.home-scene').count(),1);assert.equal(await p.locator('.route-curtain').evaluate(e=>e.hidden),true);
 assert.deepEqual(errors,[]);console.log('PASS dissolve, exact scroll/rail restoration, Back/Forward and interruption',width);await p.close();
}
const next=await b.newPage({viewport:{width:1440,height:900},reducedMotion:'reduce'});const errors=[];next.on('pageerror',e=>errors.push(e.message));await next.goto('http://localhost:4178/?section=services');await next.locator('.service-rail').waitFor();await next.locator('.service-card[href="/services/styling/tinting"]').click();await next.locator('.service-article').waitFor();await idle(next);await next.locator('.service-return').click();await next.locator('.home-scene').waitFor();await idle(next);assert.equal(await next.locator('.intro').count(),0);assert.deepEqual(errors,[]);console.log('PASS production Next routing and reduced motion');await next.close();
}finally{await b.close()}})().catch(e=>{console.error(e);process.exit(1)});
