const {chromium}=require('@playwright/test'),assert=require('node:assert/strict');
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});for(const [width,height,touch] of [[2048,1024,false],[3440,1440,false],[2560,1080,true],[1024,768,true],[390,844,true]]){
const p=await b.newPage({viewport:{width,height},hasTouch:touch,isMobile:width<650}),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto('http://localhost:4173/AVTOLAB77.html');await p.waitForSelector('.intro',{state:'detached',timeout:60000});await p.waitForSelector('.styling-sequence[data-scene-state="ready"]');
for(const [outer,inner,progress] of [['.styling-sequence','.styling-stage','.styling-stage'],['.digital-sequence','.digital-pinned','.digital-transformation']]){
 const dims=await p.locator(outer).evaluate(el=>{const t=el.firstElementChild;return{top:el.getBoundingClientRect().top+scrollY,travel:el.offsetHeight-t.offsetHeight,inset:parseFloat(getComputedStyle(t).top)||0,position:getComputedStyle(t).position}});
 if(width<650){assert.notEqual(dims.position,'sticky');continue}assert.equal(dims.position,'sticky','wide touch must retain desktop pin');
 const place=async v=>{await p.evaluate(y=>scrollTo({top:y,behavior:'instant'}),dims.top-dims.inset+dims.travel*v);await p.waitForTimeout(1200)};
 for(const v of [.05,.45,.98]){await place(v);assert(Math.abs((await p.locator(inner).boundingBox()).y-dims.inset)<1);assert(Math.abs(+(await p.locator(progress).getAttribute('data-progress'))-v)<.003);}
 if(outer==='.styling-sequence')assert.equal(await p.locator(inner).getAttribute('data-lights'),'1.0000');else assert.deepEqual(await p.locator('.screen-label').allTextContents(),['Навигация','Климат','Настройки']);
 if(width===2048||width===3440)await p.screenshot({path:`/workspace/previews/v34-${width}-${outer.includes('styling')?'bmw':'cabin'}.png`});
 await place(.4);await p.mouse.wheel(0,180);await p.waitForTimeout(1200);assert(Math.abs((await p.locator(inner).boundingBox()).y-dims.inset)<1,'wheel retains scene on screen');assert(+(await p.locator(progress).getAttribute('data-progress'))>.4);
 await place(1.15);assert((await p.locator(inner).boundingBox()).y<dims.inset-20,'release after animation');
}
assert(await p.locator('.digital-camera').evaluate(el=>getComputedStyle(el).maskImage!=='none'),'feather at actual SVG bounds');assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));assert.deepEqual(errors,[]);console.log('PASS',width,height,touch?'touch/hybrid':'mouse','both scenes, real wheel, completed animation/release, image feather, overflow');await p.close();}await b.close()})().catch(e=>{console.error(e);process.exit(1)});
