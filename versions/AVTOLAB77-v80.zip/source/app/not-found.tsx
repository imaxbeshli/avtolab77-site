import {Detail} from '../components/Site';
export default function NotFound(){return <Detail path="/404"/>}
