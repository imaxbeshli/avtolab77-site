import {Home} from '../components/Site';
export default function Page(){return <Home/>}
