import {notFound} from 'next/navigation';
import {Detail} from '../../components/Site';
import {services} from '../../content/services';
import {projects,models,pageInfo} from '../../content/site';
const paths=['services','services/styling','services/digital',...Object.keys(pageInfo),...services.map(s=>`services/${s.direction}/${s.slug}`),...projects.map(p=>`projects/${p.slug}`),...models.map(m=>`cars/${m.brand}/${m.id}`)];
export function generateStaticParams(){return paths.map(path=>({slug:path.split('/')}))}
export const dynamicParams=false;
export async function generateMetadata({params}:{params:Promise<{slug:string[]}>}){const{slug}=await params;const path=slug.join('/');const title=services.find(s=>s.slug===slug[2])?.title??projects.find(p=>p.slug===slug[1])?.title??pageInfo[path]?.[0]??'Услуги';return{title:`${title} — AVTOLAB77`}}
export default async function Page({params}:{params:Promise<{slug:string[]}>}){const{slug}=await params;const path=slug.join('/');if(!paths.includes(path))notFound();return <Detail path={path}/>}
