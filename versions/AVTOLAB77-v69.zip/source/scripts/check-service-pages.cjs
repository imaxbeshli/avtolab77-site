const {chromium}=require('@playwright/test'),assert=require('node:assert/strict');
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader']});try{for(const width of [320,390,1440,2560]){for(const slug of ['ppf','tinting','polishing','glass','pdr','soundproofing']){
 const p=await b.newPage({viewport:{width,height:900},hasTouch:width<600,isMobile:width<600,reducedMotion:'reduce'});const errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.route('https://tiles.openfreemap.org/**',r=>r.abort());
 await p.goto('http://localhost:4176/AVTOLAB77.html#/services/styling/'+slug);
 const article=p.locator('.service-article');await article.waitFor();await p.evaluate(()=>document.fonts.ready);
 assert((await article.locator('h1').innerText()).length>5);assert.equal(await article.locator('.service-copy-section').count(),3);assert.equal(await p.locator('.breadcrumbs,.faq').count(),0);
 for(const img of await article.locator('img').all()){await img.scrollIntoViewIfNeeded();await img.evaluate(e=>e.decode());assert(await img.evaluate(e=>e.naturalWidth>=e.getBoundingClientRect().width),"source image must cover its displayed width")}
 if(await article.locator('.service-article-hero--photo').count()){const hero=await article.locator('.service-article-hero').boundingBox(),copy=await article.locator('.service-article-copy').boundingBox();assert(copy.y>=hero.y+hero.height+10,'source photo must not overlap copy');}
 assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 const centered=await article.locator('h1,h2,p').evaluateAll(es=>es.map(e=>getComputedStyle(e).textAlign));assert(centered.every(x=>x==='center'));
 const rail=article.locator('.work-rail');assert.equal(await rail.evaluate(e=>getComputedStyle(e).scrollbarWidth),'none');assert.equal(await rail.evaluate(e=>getComputedStyle(e,'::-webkit-scrollbar').display),'none');await rail.scrollIntoViewIfNeeded();const limit=await rail.evaluate(e=>e.scrollWidth-e.clientWidth);assert(limit>0);const box=await rail.boundingBox();await p.mouse.move(box.x+box.width*.5,box.y+box.height*.5);await p.mouse.wheel(0,180);assert(await rail.evaluate(e=>e.scrollLeft)>0);
 await rail.focus();await p.keyboard.press('End');assert(Math.abs((await rail.evaluate(e=>e.scrollLeft))-limit)<2);await p.keyboard.press('Home');assert.equal(await rail.evaluate(e=>e.scrollLeft),0);
 await p.mouse.move(box.x+box.width*.6,box.y+box.height*.5);await p.mouse.down();await p.mouse.move(box.x+box.width*.3,box.y+box.height*.5,{steps:12});await p.mouse.up();assert(await rail.evaluate(e=>e.scrollLeft)>20);
 await article.locator('.service-booking>button').click();const dialog=p.locator('dialog[open]');assert.equal(await dialog.locator('select').inputValue(),slug);await dialog.locator('.close').click();
 await p.evaluate(()=>scrollTo({top:0,behavior:'instant'}));await p.screenshot({path:'/workspace/previews/services-'+slug+'-'+width+'.png',fullPage:true});
 await article.locator('.service-return').click();await p.locator('.home-scene').waitFor();await p.waitForTimeout(350);assert.equal(await p.locator('.intro').count(),0);const ret=await p.locator('#service-cards').boundingBox();assert(ret.y>=60&&ret.y<=150,'return lands on services: '+ret.y);
 await p.locator('.service-card[href="/services/styling/'+slug+'"]').click();await article.waitFor();assert.deepEqual(errors,[]);console.log('PASS',slug,width,'content, centering, images, wheel/drag/key rail, booking, return anchor');await p.close();
 }}}finally{await b.close()}})().catch(e=>{console.error(e);process.exit(1)});
