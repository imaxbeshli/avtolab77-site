'use client';
import {useEffect,useRef,type ReactNode} from 'react';
import type {ServicePage} from '../content/service-pages';
import {useRail} from './Motion';

export function ServiceArticle({page,booking}:{page:ServicePage;booking:ReactNode}){
 const examplesNote=page.examplesNote??(page.examplesArePlaceholders?'Временные изображения для макета':'');
 const root=useRef<HTMLElement>(null);
 useRail();
 useEffect(()=>{
  const nodes=root.current?.querySelectorAll<HTMLElement>('[data-service-reveal]');
  if(!nodes||matchMedia('(prefers-reduced-motion: reduce)').matches||!('IntersectionObserver' in window))return;
  const animations:Animation[]=[];let next=0;
  const observer=new IntersectionObserver(entries=>{
   const visible=entries.filter(e=>e.isIntersecting).sort((a,b)=>a.target.compareDocumentPosition(b.target)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1);
   visible.forEach(entry=>{
    observer.unobserve(entry.target);const element=entry.target as HTMLElement;
    element.classList.remove('service-reveal-pending');
    const now=performance.now(),start=Math.max(now,next);next=start+120;
    animations.push(element.animate([{opacity:0,transform:'translateY(18px)'},{opacity:1,transform:'translateY(0)'}],{duration:750,delay:start-now,easing:'cubic-bezier(.22,.7,.25,1)',fill:'backwards'}));
   });
  },{threshold:.08});
  nodes.forEach(node=>{node.classList.add('service-reveal-pending');observer.observe(node)});
  return()=>{observer.disconnect();animations.forEach(a=>a.cancel());nodes.forEach(node=>node.classList.remove('service-reveal-pending'))};
 },[page.slug]);
 return <main ref={root} id="main" className="service-article">
  <div className="service-article-heading" data-service-reveal>
   <a className="service-return" href="/?section=services">К услугам</a>
   <h1>{page.title}</h1>
  </div>
  <div className={'service-article-hero'+(page.heroWidth?' service-article-hero--photo':'')} style={page.heroWidth?{maxWidth:page.heroWidth}:undefined} data-service-reveal><img src={page.hero} alt={page.heroAlt} width={page.heroWidth??1672} height={page.heroHeight??941} fetchPriority="high"/></div>
  <div className="service-article-copy">
   {page.sections.map(section=><section className="service-copy-section" key={section.title} data-service-reveal>
    <h2>{section.title}</h2><p>{section.body}</p>{section.note&&<p className="service-copy-note">{section.note}</p>}
   </section>)}
  </div>
  <section className="service-examples" aria-labelledby={'examples-'+page.slug}>
   <div data-service-reveal><h2 id={'examples-'+page.slug}>Примеры работ</h2>{examplesNote&&<p className="service-copy-note">{examplesNote}</p>}</div>
   <div className="work-rail" tabIndex={0} role="region" aria-label="Примеры работ — горизонтальная лента" data-service-reveal>
    {page.examples.map(item=><figure className="work-photo" key={item.src}><img src={item.src} alt={item.alt} loading="lazy" width={1100} height={734} draggable={false}/></figure>)}
   </div>
  </section>
  <section className="service-booking" data-service-reveal><h2>Обсудим ваш автомобиль</h2>{booking}</section>
 </main>;
}
