# AVTOLAB77 — визуальная версия сайта

Адаптивный сайт на Next.js 16, React 19, TypeScript. Дизайн по утверждённому референсу: тёмная студия, автомобильный hero, два направления, услуги, выбор моделей, проекты, студия и консультация.

## Посмотреть без установки

Открыть `/workspace/previews/AVTOLAB77.html` в современном браузере. В одном файле встроены все изображения, шрифты и React-интерфейс. Работают внутренние страницы, карусель автомобилей, FAQ и демонстрационная форма. Доступ к интернету не требуется. Контакты и отправка заявок ожидают наполнения.

## Разработка

Node.js 24, npm 11. Из `/workspace/avtolab77-site/avtolab77-new`:

```sh
npm ci
npm run dev
```

Dev-сервер слушает порт 3000. `npm run build` создаёт статический сайт в `out/`. Его можно разместить на статическом хостинге. Для локальной проверки сборки: `python3 -m http.server 3001 --directory out`. `npm start` для режима static export не используется.

## Проверки

- `npm run typecheck`
- `npm run build`
- `node scripts/export-preview.mjs` — пересобрать автономный HTML
- `python3 -m http.server 4173 --directory /workspace/previews`
- `node scripts/check-preview.cjs` — Chromium; проверка 320/360/390/430/768/1024/1280/1440/1920, навигации, формы, ESC, выбора моделей и проектов, скриншоты

В проверенной версии проходят сборка и тесты интерфейса. Горизонтальный overflow отсутствует на всех девяти размерах. JS-ошибок в проверенных сценариях нет. Файловая навигация запрещена политикой браузера облачной среды, поэтому автономный документ проверен через локальный HTTP; сам документ не использует сетевые зависимости.

## Контент и изображения

- `content/services.ts` — 12 услуг.
- `content/site.ts` — модели, демонстрационные проекты, страницы.
- `public/assets/hero.webp`, `details.webp`, `vehicles-v2.webp`, `glass-backdrop.webp` — сгенерированные визуальные концепты; не фотографии реальных работ или подтверждённых моделей.
- `public/assets/fonts` — локальные Manrope и Montserrat с кириллицей, лицензии OFL приложены.
- `components/Site.tsx` — компоненты главной, страниц, навигации и формы.
- `app/globals.css` — стили, шрифты и адаптивность.

Изображения обозначены как демонстрационные. Совместимость всех моделей требует проверки. Контакты, цены и реальные кейсы не выдуманы. Социальные иконки ведут на страницу контактов до появления подтверждённых адресов. Индексация закрыта через metadata robots. Форма проверяет введённые поля, но не отправляет и не сохраняет данные.

## Перед публичным запуском

Наполнить подтверждёнными материалами и контактами, подключить CMS и реальную обработку заявок с серверной валидацией, утвердить юридические документы и таблицу совместимости, настроить SEO/домен/редиректы. Production-публикация не выполнялась.

## Согласованные визуальные правки — версия 2

- Убраны пункты верхней навигации, подзаголовок hero и кнопка выбора услуг.
- Заголовок секции — «Услуги студии»; удалены ссылки «Все услуги» и «Смотреть все работы».
- Карусель содержит ZEEKR 9X, ZEEKR 8X и Lynk & Co 900, с отдельными сгенерированными визуализациями.
- Иконки цифровых услуг контурные, без красного свечения. Строка совместимости и дополнительная CTA под каруселью убраны.
- Карточки проектов содержат только изображения. Доступные названия ссылок сохранены через aria-label.
- Нижняя часть страницы использует тёмный каменный фон и полупрозрачные поверхности с backdrop blur. Проверены desktop и mobile.
- Текущий текстовый логотип оставлен до получения нового файла от владельца.
- Новый файл для просмотра: `/workspace/previews/AVTOLAB77-v2.html`.

## Версия 3 — логотип, автомобили без фона и единый стиль

- Логотип подготовлен из присланного изображения; локальный ассет `brand-logo.webp`.
- `vehicles-cutout.webp` содержит автомобили с прозрачным фоном: без пола и отражений.
- Карусель поддерживает колёсико мыши/трекпада, перетаскивание мышью, горизонтальный жест пальцем, кнопки и клавиатуру. Вертикальная прокрутка на touch сохранена.
- Убраны декоративные стрелки на карточках услуг и направлений, ссылка «Больше о студии» и отдельный подвал.
- Обновлён текст о студии. К трём фактам добавлен предоставленный владельцем тезис «5 лет гарантии на любое эксплуатационное повреждение».
- Главная завершается блоком консультации. Плитки и поверхности используют общие графитовые цвета, рамки и радиусы.
- Файл просмотра: `/workspace/previews/AVTOLAB77-v3.html`. Изображения автомобилей остаются визуализациями; форма работает в демонстрационном режиме.
- Проверки: сборка/TypeScript, 9 размеров экрана, wheel, mouse drag, keyboard, CDP touch swipe и вертикальная touch-прокрутка, форма и переходы — успешно.

## Версия 4 — композиция по исходному референсу

- Новый `studio-panorama.webp`: автомобиль целиком, больше студийного пространства и красные световые линии. Изображение плавно растворяется в общем фоне страницы.
- `styles/studio.css` объединяет оформление первого экрана, фотографий, карточек, автомобильной сцены и блока студии. Нижняя часть использует мягкую световую полосу и сдержанный каменный фон.
- Поверх фотографии подготовлен отдельный SVG-слой свечения ламп (`hero-lamps`, `--lamp-intensity`) для последующей анимации; основное освещение остаётся частью изображения.
- `components/VehicleSelector.tsx`: циклическая карусель с пятью физическими позициями и незаметной перестановкой после перехода. Крайняя модель уходит за край, не пересекает центр при возврате. Поддерживается reduced motion.
- Проверены полный цикл вперёд и назад, wheel, drag, keyboard, touch, вертикальная прокрутка, навигация и форма. Девять ширин 320–1920 px без переполнения; TypeScript и production build успешны.
- Автономный просмотр: `/workspace/previews/AVTOLAB77-v4.html`. Все изображения, шрифты и интерактивность встроены. Форма остаётся демонстрационной.

## Version 6 — motion and smoked glass

Intro now replays on a full document load, not on internal navigation; sessionStorage no longer suppresses it. IntersectionObserver reveals section headings, direction cards, services, digital tiles, projects and studio facts. Hero fog and red lamps animate independently using CSS. All motion respects prefers-reduced-motion. Centered typography, glass overlays and a continuous studio/consultation backdrop are implemented in styles/studio.css.

Validation: npm run typecheck, npm run build, scripts/check-motion.cjs and scripts/check-v5.cjs. The latter includes desktop/mobile screenshots and overflow checks. Public preview is deployed from the gh-pages branch of imaxbeshli/avtolab77-site. Publish by exporting the standalone HTML and updating index.html in the existing gh-pages checkout (/tmp/avtolab77-pages). Do not replace the branch history. Latest revision: a0f7ef1. Site: https://imaxbeshli.github.io/avtolab77-site/ . GitHub Actions must complete before describing a change as published.

## Version 7 — text centering correction

Restored bold hero typography (weight 800). Removed inherited maximum widths and left-anchored layout from fact captions; reset card text widths so equal left/right offsets center actual text containers. Verified 320/360/390/650/768/1024/1440/1920 px in scripts/check-centering.cjs: no horizontal overflow, centered heading/paragraph alignment, matching caption/headline and card/title centers within 1 px. Deployment commit: 9d2bfcc on gh-pages.

## Version backup workflow

The user requires recoverable versions for each future published visual revision. Keep immutable ZIPs under gh-pages/versions, each containing standalone index.html, VERSION.json with its SHA-256 and source commit, and Russian viewing/rollback instructions. Include a source/ snapshot for each new revision; omit dependencies, build caches and credentials. Preserve all earlier ZIPs and version HTMLs. Update versions/index.html and manifest.json, verify ZIP integrity and matching index hashes, then publish and confirm Pages completion. Never overwrite a historical version or force-push to roll back. Restore a selected index.html via a new commit, verify in browser, and wait for deployment. Historical v5–v7 packages contain standalone sites only; v8 includes source. Public version catalog: https://imaxbeshli.github.io/avtolab77-site/versions/ .

## Version 9 — two-car scene and primary section hierarchy

Generated a shared studio scene with Rolls-Royce Cullinan on the left and ZEEKR 9X on the right (studio-duo.webp). Updated SVG light positions to both walls. Desktop and mobile preserve both complete vehicles. Renamed the services heading to «Автостайлинг и детейлинг» and enlarged it and «Русификация и цифровые решения» equally. Verified centering/overflow at eight widths, desktop/mobile hero screenshots and matching section font sizes. Previous archives remain immutable.

## Version 10 — reference-style ground and studio

The hero and direction cards no longer overlap. Added carousel-asphalt.webp as a shared floor, attached model-matched reflections and contact light to each moving carousel slot, and removed translucent side car bodies. Replaced the third/fourth project visuals with Porsche/Audi front-corner closeups, preserving BMW/Mercedes. Restored a compact studio row with subtle upper light, stone edges and red fact dividers; consultation remains the last block. Checked hero/card clearance at 6 widths, reflections and wheel/keyboard transitions, centering at 8 widths, and production build.

## Version 11 — feathered floor and independent animations

Viewport-wide asphalt with a radial feather mask and slight defocus replaces hard rectangular floor edges. Distant logo is a separate subdued screen-blended layer, ready for later neon animation. Replaced digital direction image and windshield protection image; reordered styling services to ppf/tinting/polishing/glass/pdr/soundproofing. Scroll reveal now uses Web Animations with per-section stagger, independent of hover transitions. All six digital cards have stable bounds during hover. Verified progressive opacity in actual intermediate frames, eight viewport widths, carousel reflection continuity and production build. Screenshot evidence: reveal-v11-start.png / reveal-v11-end.png in local previews. Reduced motion remains supported.

## Version 12 — reliable entrance and discrete selection

Removed distant scene logo, softened/lowered hero typography, replaced the studio introduction with four centered facts (17 years, 10,000+ cars, premium materials, 5-year warranty), and centered a narrower consultation panel with its button below. Intro exists at first render, waits for the logo decode/visible document, shows and fades the logo, then reveals the hero with a gentle camera scale. Reduced motion shows a short static logo. Full reload replays the entrance; internal navigation does not. Car gestures track intent only, with no visual movement while held; release/click/wheel triggers one 720ms transition, repeated input during motion is ignored. Checks: build, check-v12, check-centering, check-v5, progressive reveal and all six hover bounds, native mobile touch swipe. Prior versions remain immutable.

## Version 13 — slower logo entrance

The logo now fades in for approximately 1 second, stays readable for 1 second and fades out for 1 second. The black curtain dissolves over 0.7 seconds from 2.9s; the camera entry lasts 1.8s. Verified real opacity at 450/1400/2500ms, camera animation and scroll release in check-intro-timing.cjs. Other site design is unchanged. scripts/archive-version.py now provides the repeatable, non-overwriting archive workflow.

## Version 14 — continuous entrance and WebGL atmosphere

Replaced conflicting CSS/reduced-motion entrance branches with one frame-controlled timeline: logo fade in 1.2s, hold .9s, fade out 1.2s, curtain 1.1s and gentle scene entry 2.2s. Logo decode and fonts finish before the timeline starts; bounded per-frame progress prevents loading stalls from skipping the fade. Reduced motion keeps opacity transitions and removes camera movement. Scroll elements and icons reveal sequentially at 120ms intervals without hover transforms.

Three.js renders procedural moving fog and subtle red reflected light on a transparent shader plane over the photographic hero. It starts after the entrance, renders at capped resolution/rate and pauses offscreen; CSS atmosphere remains as fallback. Cars are still photographs, not 3D models. Verified normal/reduced intro intermediate opacity, changing WebGL frames, reveal timing, eight responsive widths/centering, hover stability, wheel interaction, console and production build (30 static routes). Control recording: motion-v14.webm.
