'use client';
import {useEffect,useRef,useState} from 'react';
import {WebGLRenderer,Scene,OrthographicCamera,PlaneGeometry,ShaderMaterial,Mesh} from 'three';
/** A transparent GPU atmosphere layer; the underlying cars remain photographic. */
export function Atmosphere(){
 const host=useRef<HTMLDivElement>(null);
 const [ready,setReady]=useState(false);
 useEffect(()=>{const enter=()=>setReady(true);if(!document.querySelector('.intro'))enter();window.addEventListener('avtolab:entered',enter);return()=>window.removeEventListener('avtolab:entered',enter)},[]);
 useEffect(()=>{
  const el=host.current;if(!el||!ready)return;
  let renderer:WebGLRenderer;
  try{renderer=new WebGLRenderer({alpha:true,antialias:false,powerPreference:'low-power'})}catch{el.dataset.engine='fallback';return}
  renderer.setClearColor(0,0);renderer.setPixelRatio(1);el.appendChild(renderer.domElement);
  const scene=new Scene(),camera=new OrthographicCamera(-1,1,1,-1,0,2);camera.position.z=1;
  const geometry=new PlaneGeometry(2,2);
  const material=new ShaderMaterial({transparent:true,depthWrite:false,uniforms:{uTime:{value:0}},vertexShader:`varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}`,fragmentShader:`
   precision mediump float;varying vec2 vUv;uniform float uTime;
   float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
   float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
   float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<5;i++){v+=a*noise(p);p=p*2.03+3.1;a*=.5;}return v;}
   void main(){vec2 uv=vUv;float t=uTime;float n=fbm(vec2(uv.x*5.-t*.035,uv.y*15.+t*.018));float n2=fbm(vec2(uv.x*8.+t*.025,uv.y*21.-t*.01));
    float band=exp(-pow((uv.y-.29)/.11,2.));float low=exp(-pow((uv.y-.18)/.08,2.));
    float edges=smoothstep(0.,.09,uv.x)*(1.-smoothstep(.91,1.,uv.x));
    float fog=(smoothstep(.32,.7,n)*band*.34+smoothstep(.35,.72,n2)*low*.15)*edges;
    float lamp=.5+.5*sin(t*.7);float red=(exp(-pow((uv.x-.1)/.12,2.))+exp(-pow((uv.x-.9)/.12,2.)))*low*.045*lamp;
    vec3 color=mix(vec3(.62,.67,.7),vec3(.85,.06,.1),red/(fog+red+.001));gl_FragColor=vec4(color,min(.32,fog+red));}
  `});scene.add(new Mesh(geometry,material));
  const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
  let id=0,visible=true,previous=performance.now(),lastRender=0,disposed=false;
  const resize=()=>{renderer.setSize(Math.max(1,Math.min(900,el.clientWidth*.4)),Math.max(1,Math.min(600,el.clientHeight*.4)),false);renderer.render(scene,camera)};
  const draw=(now:number)=>{if(disposed)return;const dt=Math.min((now-previous)/1000,.05);previous=now;if(visible&&!document.hidden&&!reduce){material.uniforms.uTime.value+=dt;if(now-lastRender>33){renderer.render(scene,camera);lastRender=now}}id=requestAnimationFrame(draw)};
  const sizes=new ResizeObserver(resize);sizes.observe(el);
  const visibility=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting});visibility.observe(el);
  const lost=(event:Event)=>{event.preventDefault();el.dataset.engine='fallback';renderer.domElement.style.opacity='0'};
  renderer.domElement.addEventListener('webglcontextlost',lost);
  resize();el.dataset.engine='webgl';if(!reduce)id=requestAnimationFrame(draw);
  return()=>{disposed=true;cancelAnimationFrame(id);sizes.disconnect();visibility.disconnect();renderer.domElement.removeEventListener('webglcontextlost',lost);geometry.dispose();material.dispose();renderer.dispose();renderer.domElement.remove()};
 },[ready]);
 return <div ref={host} className="hero-atmosphere" aria-hidden="true"/>;
}
