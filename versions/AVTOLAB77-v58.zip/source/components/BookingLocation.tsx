'use client';
import {Clock,MapPin,Navigation,ExternalLink} from 'lucide-react';
import {studio,studioRoute} from '../content/studio';

export function BookingLocation({loadMap}:{loadMap:boolean}){
 return <section className="booking-location" aria-label="Как нас найти">
  <h2>Как нас найти</h2>
  <div className="booking-studio-mark" aria-label="AVTOLAB77">AVTO<span>LAB</span>77</div>
  <div className="booking-location-item"><MapPin aria-hidden="true"/><address><a href={studio.mapUrl} target="_blank" rel="noopener noreferrer">{studio.address}</a></address></div>
  <div className="booking-location-item"><Clock aria-hidden="true"/><div><span className="booking-location-label">Работаем</span><p>{studio.hours}</p></div></div>
  <div className="booking-map">
   <div className="booking-map-placeholder" aria-hidden="true"><MapPin/><span>AVTOLAB77</span><small>Москва · Ермакова Роща</small></div>
   {loadMap&&<iframe src={studio.mapEmbed} title="AVTOLAB77 на Яндекс Картах" loading="lazy" tabIndex={-1} aria-hidden="true" referrerPolicy="strict-origin-when-cross-origin"/>}
   <a className="booking-map-link" href={studio.mapUrl} target="_blank" rel="noopener noreferrer" aria-label="Открыть расположение AVTOLAB77 в Яндекс Картах"><span>Открыть в Яндекс Картах <ExternalLink size={13} aria-hidden="true"/></span></a>
  </div>
  <a className="booking-route" href={studioRoute} target="_blank" rel="noopener noreferrer"><Navigation size={19} aria-hidden="true"/>Построить маршрут</a>
 </section>;
}
