# Digital service content

Prepared 2026-11-07. Scope and final wording follow the owner's explicit corrections.
Descriptions are brand-neutral. No FAQs, invented work examples or master-account registration offer.

## References consulted

- https://dazysoft.ru/solutions/Rusifikatsiya-Zeekr/Rusifikatsiya-ZEEKR-001/ — localization, voice assistance, app stores. Provider describes language restoration after some updates; not evidence of permanent preservation through every factory update.
- https://www.zeekr.eu/en-nl/connected — purposes of connected services. European subscriptions and compatibility conditions were not transferred to Chinese-market vehicles.
- https://rucars.ru/magazine/articles/detail/zeekr-001-setting/ — number +86 and account access.
- https://ruszeekr.ru/blog/master-akkaunt-zeekr-kakie-daet-vozmozhnosti-i-kak-ego-poluchit/ — owner vs family account. No provider guarantees or account-registration service copied.
- https://www.autounit.pro/blog/detail/ustanovka-simkarty-v-zeekr-lixiang-/ — example of physical SIM-chip replacement and SIM interface installation.
- https://support.apple.com/ru-ru/118283 — App Store regional availability.

The owner specified full localization, Russian voice assistance, an app store, localization updates over the air, a telematics check, hardware SIM adaptation, help registering a Chinese number and phone app setup. The OTA paragraph refers specifically to localization components, not a guarantee about all factory firmware updates. Master-account content is explanatory only. Customers obtain their own operator SIM after receiving requirements.

## Generated illustrations

Six independent image_gen illustrations, 1672 × 941, generated for these pages. They are illustrative, not customer work photos or documentation of a particular hardware model. Original PNGs remain in /workspace/generated_images. WebP copies are optimized without visual edits.

| Page | Original filename | Web asset |
| --- | --- | --- |
| firmware | exec-02f425a0-da33-497a-97d1-eb6916a50160.png | digital-firmware-hero.webp |
| tcam | exec-c6f378ef-7290-4759-a69d-16257969b874.png | digital-tcam-hero.webp |
| number | exec-f231470e-d6be-45f7-8ccf-7c82dcd4ac82.png | digital-number-hero.webp |
| account | exec-7a11ec69-0c66-42d9-a6bd-d074fd1afdcf.png | digital-account-hero.webp |
| sim | exec-13280414-54a8-4ea9-bace-46fa87511702.png | digital-sim-hero.webp |
| apps | exec-84b62b8c-4262-486d-adac-3e16f1e01385.png | digital-apps-hero.webp |
