import gallery from './project-gallery-sources.json';

export type Project = {
 slug:string;brand:string;title:string;category:string;description:string;
 hero:string;thumbnail:string;tile:number;source:string;work:string[];
 photos:{src:string;width:number;height:number;brightness:number;alt:string}[];
};
const covers:Record<string,{hero:string;thumbnail:string}> = {
 "bentley": {hero:"/assets/project-bentley-r72.webp",thumbnail:"/assets/project-bentley-card-r72.webp"},
 "lexus": {hero:"/assets/project-lexus-r72.webp",thumbnail:"/assets/project-lexus-card-r72.webp"},
 "mercedes": {hero:"/assets/project-mercedes-r72.webp",thumbnail:"/assets/project-mercedes-card-r72.webp"},
 "range-rover": {hero:"/assets/project-range-rover-r72.webp",thumbnail:"/assets/project-range-rover-card-r72.webp"},
 "voyah": {hero:"/assets/project-voyah-r72.webp",thumbnail:"/assets/project-voyah-card-r72.webp"},
 "bmw": {hero:"/assets/project-bmw-r72.webp",thumbnail:"/assets/project-bmw-card-r72.webp"},
};
const cases = [
 {slug:'bentley-continental-gt',brand:'bentley',title:'Bentley Continental GT',category:'Защита кузова и салона',description:'Защитили кузов, лобовое стекло и элементы салона Bentley Continental GT.',source:'https://avtolab77.ru/works/bentley/bentley-motors-continental-gt/',work:['Полная оклейка кузова антигравийной плёнкой LEGEND.','Бронирование лобового стекла.','Защитная плёнка на элементах интерьера.']},
 {slug:'lexus-lx500',brand:'lexus',title:'Lexus LX500',category:'Комплексная защита',description:'Комплекс работ для защиты кузова, салона и оснащения Lexus LX500.',source:'https://avtolab77.ru/works/lexus/lexus-lx500/',work:['Оклейка кузова плёнкой LEGEND и бронирование стёкол.','Защита картера, антикоррозийная обработка днища и защитная сетка.','Установка сигнализации и видеорегистратора.','Защита элементов салона.']},
 {slug:'mercedes-g450d',brand:'mercedes',title:'Mercedes-Benz G 450 d',category:'Антигравийная защита',description:'Полная оклейка кузова Mercedes-Benz G-Class 450 d защитной плёнкой.',source:'https://avtolab77.ru/works/mercedes/mercedes-benz-g-%D1%81lass-450d/',work:['Полная защитная оклейка кузова.']},
 {slug:'range-rover-autobiography',brand:'range-rover',title:'Range Rover Autobiography',category:'Полировка и защита',description:'Полировка и защитная оклейка Range Rover Autobiography 2023 года.',source:'https://avtolab77.ru/works/range-rover/range-rover-autobiography-2023/',work:['Полировка лакокрасочного покрытия.','Полная оклейка кузова антигравийной плёнкой LEGEND.','Защита отдельных элементов интерьера.']},
 {slug:'voyah-taishan',brand:'voyah',title:'Voyah Taishan',category:'Защита кузова и салона',description:'Защитная оклейка кузова, стёкол, фар и элементов интерьера Voyah Taishan.',source:'https://avtolab77.ru/works/voyah/voyah-taishan/',work:['Полная оклейка кузова антигравийной плёнкой.','Бронирование стёкол и фар.','Дополнительная защита уязвимых элементов салона.']},
 {slug:'bmw-e31',brand:'bmw',title:'BMW E31',category:'Сохранение оригинального покрытия',description:'Коллекционное купе 1995 года. Задача — сохранить оригинальное лакокрасочное покрытие автомобиля.',source:'https://avtolab77.ru/works/bmw/bmw-e31/',work:['Полная оклейка кузова защитной плёнкой LEGEND.']},
];
// Cover illustrations are separate from documentary photographs of actual work.
export const projects:Project[]=cases.map((item,tile)=>({...item,tile,
 ...covers[item.brand],
 photos:gallery.filter(photo=>photo.brand===item.brand).map(photo=>({src:photo.src,width:photo.width,height:photo.height,brightness:photo.brightness,alt:`${item.title} — работа студии AVTOLAB77, фото ${photo.index}`}))
}));
