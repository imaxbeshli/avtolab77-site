'use client';
import {useEffect,useState} from 'react';
let introPlayed=false;
export function Motion(){
 const [intro,setIntro]=useState(()=>!introPlayed);
 const [playing,setPlaying]=useState(false);
 useEffect(()=>{
  const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const play=intro;introPlayed=true;
  const animations:Animation[]=[];
  const timers:ReturnType<typeof setTimeout>[]=[];
  let disposed=false,started=false;
  const nodes=document.querySelectorAll('.home-scene .section-head,.direction,.styling-scene,.digital-interior,.vehicle-carousel,.service-card,.digital-grid a,.project-card,.fact,.consult');
  const observer='IntersectionObserver' in window?new IntersectionObserver(entries=>entries.forEach(e=>{
   if(!e.isIntersecting)return;
   const el=e.target as HTMLElement;observer?.unobserve(el);el.classList.remove('motion-pending');el.dataset.revealState='running';
   const delay=0; // Same row rises together: no left-to-right cascade.
   const animation=el.animate([{opacity:0,translate:reduced?'0 0':'0 24px'},{opacity:1,translate:'0 0'}],{duration:1100,delay,easing:'cubic-bezier(.22,.7,.25,1)',fill:'backwards'});
   animations.push(animation);animation.onfinish=()=>{el.classList.add('revealed');el.dataset.revealState='complete'};
   el.querySelectorAll('.service-line-icon,.direction-content>svg').forEach(icon=>animations.push(icon.animate([{opacity:0,translate:reduced?'0 0':'0 8px'},{opacity:1,translate:'0 0'}],{duration:600,delay:delay+120,fill:'backwards',easing:'ease-out'})));
  }),{threshold:.12,rootMargin:'0px 0px -30px 0px'}):null;
  if(observer)nodes.forEach(el=>{el.classList.add('reveal','motion-pending');el.setAttribute('data-reveal-state','pending')});
  const observe=()=>nodes.forEach(el=>observer?.observe(el));
  const animate=async(el:Element|null,frames:Keyframe[],options:KeyframeAnimationOptions)=>{
   if(!el||disposed)return;
   const animation=el.animate(frames,options);animations.push(animation);
   if(el.matches('.intro .logo-art')){
    animation.pause();
    await new Promise<void>(resolve=>{let elapsed=0,last=performance.now();const duration=(Number(options.duration)||0)+(Number(options.delay)||0);const tick=(now:number)=>{if(disposed){resolve();return}if(document.visibilityState==='visible')elapsed+=Math.min(now-last,34);last=now;animation.currentTime=Math.min(elapsed,duration);if(elapsed>=duration){resolve();return}requestAnimationFrame(tick)};requestAnimationFrame(tick)});
   }else{try{await animation.finished}catch{}}
  };
  const start=async()=>{
   if(started||disposed||document.visibilityState==='hidden')return;started=true;
   if(!play){setIntro(false);observe();return}
   document.body.classList.add('intro-running');setPlaying(true);
   await document.fonts.ready;
   await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
   if(disposed)return;
   const curtain=document.querySelector('.intro') as HTMLElement;
   const logo=curtain?.querySelector('.logo-art');
   if(curtain)curtain.dataset.phase='appearing';
   await animate(logo,[{opacity:0},{opacity:1}],{duration:1200,easing:'ease-in-out',fill:'forwards'});
   if(disposed)return;
   const atmosphereReady=new Promise<void>(resolve=>{const done=()=>{window.removeEventListener('avtolab:atmosphere-ready',done);resolve()};window.addEventListener('avtolab:atmosphere-ready',done);timers.push(setTimeout(done,4000));window.dispatchEvent(new Event('avtolab:prepare-atmosphere'))});
   if(curtain)curtain.dataset.phase='reading';
   await animate(logo,[{opacity:1},{opacity:1}],{duration:900,fill:'forwards'});
   if(disposed)return;if(curtain)curtain.dataset.phase='fading';
   await animate(logo,[{opacity:1},{opacity:0}],{duration:1200,easing:'ease-in-out',fill:'forwards'});
   await atmosphereReady;
   if(disposed)return;document.body.classList.add('intro-opening');
   await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
   if(disposed)return;if(curtain)curtain.dataset.phase='opening';
   const hero=document.querySelector('.hero-image');const title=document.querySelector('.hero-vector-title');
   // All opening layers finish before removing the curtain and unlocking scroll.
   await Promise.all([
    animate(hero,[{scale:reduced?'1':'.98',opacity:.5},{scale:'1',opacity:1}],{duration:2200,easing:'cubic-bezier(.2,.65,.3,1)',fill:'forwards'}),
    animate(title,[{opacity:0,translate:reduced?'0 0':'0 10px'},{opacity:1,translate:'0 0'}],{duration:1300,delay:250,fill:'both'}),
    animate(curtain,[{opacity:1},{opacity:0}],{duration:1600,easing:'ease-in-out',fill:'forwards'})
   ]);
   if(disposed)return;setIntro(false);document.body.classList.remove('intro-running','intro-opening');observe();requestAnimationFrame(()=>window.dispatchEvent(new Event('avtolab:entered')));
  };
  if(play)document.body.classList.add('intro-running');
  document.addEventListener('visibilitychange',start);
  // Wait for the logo itself, not just for the JavaScript bundle.
  const logo=document.querySelector('.intro .logo-art');
  const url=logo?getComputedStyle(logo).backgroundImage.match(/^url\(["']?(.*?)["']?\)$/)?.[1]:null;
  const asset=new Image();if(url)asset.src=url;
  Promise.race([url?asset.decode().catch(()=>{}):Promise.resolve(),new Promise(resolve=>timers.push(setTimeout(resolve,1800)))]).then(start);
  return()=>{disposed=true;timers.forEach(clearTimeout);document.removeEventListener('visibilitychange',start);observer?.disconnect();animations.forEach(a=>a.cancel());document.body.classList.remove('intro-running','intro-opening');nodes.forEach(el=>{el.classList.remove('reveal','revealed','motion-pending');el.removeAttribute('data-reveal-state')})};
 },[]);
 return intro?<div className={'intro'+(playing?' is-playing':'')} aria-label="AVTOLAB77"><div className="intro-brand"><div className="logo-art"/><span className="intro-rule"/></div></div>:null;
}
/** Native touch scrolling, eased mouse wheel and mouse dragging share fixed-size rails. */
export function useRail(){useEffect(()=>{
 const cleanups=Array.from(document.querySelectorAll<HTMLElement>('.service-rail,.projects-rail')).map(rail=>{
  let drag:{x:number;left:number;id:number}|null=null;
  let moved=false,ignoreClickUntil=0,frame=0,target=rail.scrollLeft,position=rail.scrollLeft,last=0;
  const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
  const limit=()=>Math.max(0,rail.scrollWidth-rail.clientWidth);
  const edges=()=>{
   const end=limit();rail.dataset.overflow=String(end>1);
   rail.style.setProperty('--fade-start',rail.scrollLeft>2?'24px':'0px');
   rail.style.setProperty('--fade-end',rail.scrollLeft<end-2?'32px':'0px');
  };
  const stop=()=>{cancelAnimationFrame(frame);frame=0;target=position=rail.scrollLeft};
  const tick=(now:number)=>{
   const dt=Math.min(now-last,40);last=now;
   // Keep subpixel progress separately: scrollLeft can round and stall 2px from the end.
   position+=(target-position)*(1-Math.exp(-dt/75));rail.scrollLeft=position;
   if(Math.abs(target-position)>.5){frame=requestAnimationFrame(tick)}
   else{rail.scrollLeft=target;frame=0;edges()}
  };
  const scrollTo=(left:number)=>{
   target=Math.max(0,Math.min(limit(),left));
   if(reduced()){rail.scrollLeft=target;edges();return}
   if(!frame){position=rail.scrollLeft;last=performance.now();frame=requestAnimationFrame(tick)}
  };
  const wheel=(e:WheelEvent)=>{
   if(e.ctrlKey||e.metaKey||!limit())return;
   const delta=(Math.abs(e.deltaX)>Math.abs(e.deltaY)?e.deltaX:e.deltaY)*(e.deltaMode===1?16:e.deltaMode===2?rail.clientWidth:1);
   const current=frame?target:rail.scrollLeft;
   if(!delta||(delta<0&&current<=1)||(delta>0&&current>=limit()-1))return;
   e.preventDefault();scrollTo(current+delta);
  };
  const press=(e:PointerEvent)=>{
   if(e.pointerType!=='mouse'||e.button!==0)return;
   stop();moved=false;drag={x:e.clientX,left:rail.scrollLeft,id:e.pointerId};
  };
  const move=(e:PointerEvent)=>{
   if(!drag||drag.id!==e.pointerId)return;
   if(Math.abs(e.clientX-drag.x)>5){
    moved=true;rail.classList.add('is-dragging');
    if(!rail.hasPointerCapture(e.pointerId))rail.setPointerCapture(e.pointerId);
    rail.scrollLeft=drag.left+drag.x-e.clientX;e.preventDefault();
   }
  };
  const release=()=>{
   if(drag&&rail.hasPointerCapture(drag.id))rail.releasePointerCapture(drag.id);
   if(moved)ignoreClickUntil=performance.now()+350;
   drag=null;rail.classList.remove('is-dragging');
  };
  const click=(e:MouseEvent)=>{if(performance.now()<ignoreClickUntil){e.preventDefault();e.stopPropagation()}};
  const preventDrag=(e:DragEvent)=>e.preventDefault();
  const key=(e:KeyboardEvent)=>{
   if(e.target!==rail||!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
   e.preventDefault();const step=(rail.firstElementChild?.getBoundingClientRect().width??200)+16;
   scrollTo(e.key==='Home'?0:e.key==='End'?limit():(frame?target:rail.scrollLeft)+(e.key==='ArrowRight'?step:-step));
  };
  const observer=new ResizeObserver(edges);observer.observe(rail);
  const children=new MutationObserver(edges);children.observe(rail,{childList:true});
  rail.addEventListener('wheel',wheel,{passive:false});rail.addEventListener('pointerdown',press);
  rail.addEventListener('pointermove',move);window.addEventListener('pointerup',release);rail.addEventListener('pointercancel',release);
  rail.addEventListener('lostpointercapture',release);rail.addEventListener('click',click,true);
  rail.addEventListener('dragstart',preventDrag);rail.addEventListener('keydown',key);rail.addEventListener('scroll',edges,{passive:true});edges();
  return()=>{stop();observer.disconnect();children.disconnect();rail.removeEventListener('wheel',wheel);rail.removeEventListener('pointerdown',press);rail.removeEventListener('pointermove',move);window.removeEventListener('pointerup',release);rail.removeEventListener('pointercancel',release);rail.removeEventListener('lostpointercapture',release);rail.removeEventListener('click',click,true);rail.removeEventListener('dragstart',preventDrag);rail.removeEventListener('keydown',key);rail.removeEventListener('scroll',edges)};
 });
 return()=>cleanups.forEach(cleanup=>cleanup());
},[])}
