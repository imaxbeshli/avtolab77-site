/** Service copy is kept separate from layout so all six pages share one template.
 * Only owner-supplied/verified source material is enabled here. */
export type ServicePage = {
 slug:string; title:string; hero:string; heroAlt:string;
 sections:{title:string;body:string;note?:string}[];
 examples:{src:string;alt:string}[];
 examplesArePlaceholders:boolean;
};
export const servicePages:Record<string,ServicePage>={
 soundproofing:{
  slug:'soundproofing',title:'Шумоизоляция',
  hero:'/assets/service-soundproofing-hero.webp',heroAlt:'Иллюстрация обработки внутренней панели двери шумоизоляционными материалами',
  sections:[
   {title:'Что такое шумоизоляция',body:'Обработка кузовных панелей специальными материалами, которые уменьшают вибрации металла и проникновение шума в салон.',note:'Виброизоляция · Звукоизоляция · Шумопоглощение'},
   {title:'Что вы получаете',body:'Меньше дорожного шума и гула в салоне. Комфортнее разговаривать и слушать музыку во время поездки.',note:'Результат зависит от автомобиля и объёма обработки.'},
   {title:'Материалы Comfort Mat',body:'Используем материалы российского бренда Comfort Mat. Возможна комплексная обработка автомобиля или отдельных зон.',note:'Объём работ и стоимость согласовываем перед началом.'},
  ],
  examples:[
   {src:'/assets/service-soundproofing-hero.webp',alt:'Временная иллюстрация: шумоизоляция двери'},
   {src:'/assets/service-soundproofing-floor.webp',alt:'Временная иллюстрация: шумоизоляция пола салона'},
   {src:'/assets/service-soundproofing-trunk.webp',alt:'Временная иллюстрация: шумоизоляция багажника'},
  ],examplesArePlaceholders:true,
 },
};
