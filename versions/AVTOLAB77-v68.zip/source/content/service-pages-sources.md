# Sources for the service-page template

## Soundproofing
Copy follows the original AVTOLAB77 text pasted by the owner into this conversation and the explicitly approved shortened three-section copy. Comfort Mat usage was also explicitly confirmed by the owner. No unverified percentage, market leadership, timetable, or warranty claims were retained.

The source site https://avtolab77.ru/ could not be fetched: the managed environment proxy denied access (403). This is not a completed crawl or migration of that site. The following five services still await source access: ppf, tinting, polishing, glass, pdr. Their existing pages have not been changed or presented as migrated.

## Images
Three generated illustrative placeholders, not real AVTOLAB77 projects:
- service-soundproofing-hero.webp: generated image exec-59c24d9d-51af-4042-bbd8-ba720481e1da.png
- service-soundproofing-floor.webp: exec-25dda53d-7e34-4270-943b-aebaebab036a.png
- service-soundproofing-trunk.webp: exec-63615e4d-1d5e-407e-bf03-dccbec2365d8.png
The gallery explicitly labels them temporary images. Replace `examples` in content/service-pages.ts with owner-provided photographs and accurate alt text, then set examplesArePlaceholders:false only when all example images are real.

## Typography
UnboundedService is a Latin/Cyrillic WOFF subset of the existing unbounded.ttf, under the existing Unbounded license in public/assets/fonts. The old hero subset contains only twelve characters and cannot display a complete service heading; it is preserved for the existing homepage.
