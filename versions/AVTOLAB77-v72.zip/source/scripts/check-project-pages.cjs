const {chromium}=require('@playwright/test'),assert=require('node:assert/strict'),fs=require('fs'),crypto=require('crypto');
const cases=[['bentley-continental-gt',17],['lexus-lx500',17],['mercedes-g450d',21],['range-rover-autobiography',18],['voyah-taishan',14],['bmw-e31',10]];
const idle=p=>p.waitForFunction(()=>!document.documentElement.dataset.routeTransition);
(async()=>{
 const sources=JSON.parse(fs.readFileSync('content/project-gallery-sources.json'));assert.equal(sources.length,97);for(const item of sources)assert.equal(crypto.createHash('sha256').update(fs.readFileSync(item.original)).digest('hex'),item.sha256);
 const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader']});
 try{
 for(const width of [320,390,1440,2560]){
  const p=await b.newPage({viewport:{width,height:900},reducedMotion:'reduce'}),errors=[];p.on('pageerror',e=>errors.push(e.message));
  for(const [slug,count] of cases){
   await p.goto('http://localhost:4176/AVTOLAB77-live.html#/projects/'+slug);await p.locator('.project-hero img').evaluate(e=>e.decode());await p.evaluate(()=>document.fonts.ready);
   assert.equal(await p.locator('.project-photo').count(),count);assert(await p.locator('h1').innerText());assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
   const list=await p.locator('.project-photo').evaluateAll(nodes=>nodes.map(e=>e.getBoundingClientRect().toJSON()));for(let i=1;i<list.length;i++){assert(list[i].top>=list[i-1].bottom);assert(Math.abs((list[i].left+list[i].right)/2-width/2)<2)}
   // Decode every actual file, not merely the currently visible lazy images.
   const decoded=await p.locator('.project-photo img').evaluateAll(async imgs=>Promise.all(imgs.map(e=>{const image=new Image();image.src=e.src;return image.decode().then(()=>image.naturalWidth>0).catch(()=>false)})));assert(decoded.every(Boolean),slug+' missing gallery asset');
   const h=await p.locator('h1').boundingBox();assert(Math.abs(h.x+h.width/2-width/2)<2);
   if(slug==='bentley-continental-gt'&&[390,1440].includes(width)){const img=p.locator('.project-photo img').first();await img.scrollIntoViewIfNeeded();await img.evaluate(e=>e.decode());await p.screenshot({path:'/tmp/project-real-gallery-'+width+'.png'});}
  }
  assert.deepEqual(errors,[]);console.log('PASS six project pages, all 97 photos, centered layout, no clipping',width);await p.close();
 }
 for(const width of [390,1440]){
  const p=await b.newPage({viewport:{width,height:900}}),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto('http://localhost:4176/AVTOLAB77-live.html');await p.locator('.intro').waitFor({state:'detached',timeout:20000});assert.equal(await p.locator('.projects-rail .project-card').count(),6);
  const card=p.locator('.project-card[href="/projects/voyah-taishan"]');await card.scrollIntoViewIfNeeded();await p.waitForTimeout(1100);const saved=await p.evaluate(()=>({y:scrollY,left:document.querySelector('.projects-rail').scrollLeft}));
  const box=await card.boundingBox();await p.mouse.click(box.x+box.width/2,box.y+box.height/2);await p.waitForTimeout(80);assert.equal(await p.locator('.home-scene').count(),1);await p.locator('.project-article').waitFor();await idle(p);assert.equal(await p.evaluate(()=>scrollY),0);
  await p.locator('.project-return').first().click();await p.locator('.home-scene').waitFor();await idle(p);assert.equal(await p.locator('.intro').count(),0);const restored=await p.evaluate(()=>({y:scrollY,left:document.querySelector('.projects-rail').scrollLeft}));assert(Math.abs(restored.y-saved.y)<3,JSON.stringify({saved,restored}));assert(Math.abs(restored.left-saved.left)<3);
  await p.goBack();await p.locator('.project-article').waitFor();await idle(p);await p.goForward();await p.locator('.home-scene').waitFor();await idle(p);
  await p.reload();await p.locator('.intro').waitFor({state:'detached',timeout:20000});assert.equal(await p.evaluate(()=>scrollY),0,'reload must open main scene');assert.deepEqual(errors,[]);console.log('PASS project dissolve, return position, history and root reload',width);await p.close();
 }
 const p=await b.newPage({viewport:{width:1440,height:900},reducedMotion:'reduce'});await p.goto('http://localhost:4178/');const card=p.locator('.project-card[href="/projects/bmw-e31"]');await card.click();await p.locator('.project-article').waitFor();await idle(p);await p.locator('.project-return').first().click();await p.locator('.home-scene').waitFor();await idle(p);assert.equal(await p.locator('.intro').count(),0);console.log('PASS Next project routing');await p.close();
 }finally{await b.close()}
})().catch(e=>{console.error(e);process.exit(1)});
