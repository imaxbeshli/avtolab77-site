'use client';
import {useEffect,useRef,useState} from 'react';
import * as T from 'three';
import {EffectComposer} from 'three/examples/jsm/postprocessing/EffectComposer.js';
import {RenderPass} from 'three/examples/jsm/postprocessing/RenderPass.js';
import {UnrealBloomPass} from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import {OutputPass} from 'three/examples/jsm/postprocessing/OutputPass.js';
const assets={room:'/assets/reference40.webp',occlusion:'/assets/hero-cars-v37.webp'};
const vertex=`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`;
const noise=`float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<5;i++){v+=a*noise(p);p=p*2.02+3.7;a*=.5;}return v;}`;
/** Preserve the approved photographic composition; depth effects never reposition its cars. */
export function CinematicHero(){
 const host=useRef<HTMLDivElement>(null),[start,setStart]=useState(false);
 useEffect(()=>{const prepare=()=>setStart(true);if(!document.querySelector('.intro'))prepare();window.addEventListener('avtolab:prepare-atmosphere',prepare);return()=>window.removeEventListener('avtolab:prepare-atmosphere',prepare)},[]);
 useEffect(()=>{
  const el=host.current;if(!el||!start)return;let disposed=false,frame=0,visible=true,entered=!document.querySelector('.intro');
  const announce=()=>window.dispatchEvent(new Event('avtolab:atmosphere-ready'));
  const textures:T.Texture[]=[],geometries:T.BufferGeometry[]=[],materials:T.Material[]=[];
  let renderer:T.WebGLRenderer|undefined,composer:EffectComposer|undefined,resize:ResizeObserver|undefined,observer:IntersectionObserver|undefined;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const enter=()=>{entered=true};window.addEventListener('avtolab:entered',enter);
  const build=async()=>{try{
   renderer=new T.WebGLRenderer({alpha:true,antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(1);renderer.setClearColor(0x000000,0);renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.NoToneMapping;
   const scene=new T.Scene(),camera=new T.OrthographicCamera(-8.36,8.36,4.705,-4.705,.1,100);camera.position.z=20;
   const loader=new T.TextureLoader();const loaded=await Promise.all(Object.values(assets).map(url=>loader.loadAsync(url)));textures.push(...loaded);if(disposed){loaded.forEach(t=>t.dispose());renderer.dispose();return}
   loaded.forEach(t=>{t.colorSpace=T.SRGBColorSpace;t.anisotropy=Math.min(8,renderer!.capabilities.getMaxAnisotropy())});
   const plane=(w:number,h:number,material:T.Material,x:number,y:number,z:number)=>{const g=new T.PlaneGeometry(w,h);geometries.push(g);materials.push(material);const mesh=new T.Mesh(g,material);mesh.position.set(x,y,z);mesh.renderOrder=z+10;scene.add(mesh);return mesh};
   plane(16.72,9.41,new T.MeshBasicMaterial({map:loaded[0],depthWrite:false}),0,0,-8);
   // Real extruded, bevelled geometry. Both sevens share the same construction.
   const sign=new T.Group();sign.position.set(-2.7,3.15,-5);sign.rotation.y=-.06;scene.add(sign);
   const shape=new T.Shape();shape.moveTo(.36,0);shape.lineTo(2.76,0);shape.lineTo(.88,-4.7);shape.lineTo(.2,-4.7);shape.lineTo(1.72,-.67);shape.lineTo(0,-.67);shape.closePath();
   const digit=new T.ExtrudeGeometry(shape,{depth:.12,bevelEnabled:true,bevelThickness:.018,bevelSize:.018,bevelSegments:2,steps:1});geometries.push(digit);
   const signMats:T.ShaderMaterial[]=[];
   for(const x of [0,2.86]){
    const mat=new T.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{pulse:{value:1}},vertexShader:`varying float height;varying vec3 n;void main(){height=position.y;n=normal;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,fragmentShader:`varying float height;varying vec3 n;uniform float pulse;void main(){float fade=smoothstep(-4.45,-1.2,height);float edge=1.-abs(n.z);vec3 c=mix(vec3(.0005,.0001,.00015),vec3(.035,.001,.002),edge);gl_FragColor=vec4(c*pulse,fade*.45);}`});materials.push(mat);signMats.push(mat);const m=new T.Mesh(digit,mat);m.position.x=x;m.renderOrder=4;sign.add(m);
    const eg=new T.EdgesGeometry(digit,30);geometries.push(eg);const em=new T.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{pulse:{value:1}},vertexShader:`varying float height;varying float horizontal;void main(){height=position.y;horizontal=position.x;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,fragmentShader:`varying float height;varying float horizontal;uniform float pulse;void main(){float fade=smoothstep(-4.4,-1.,height);float glint=exp(-pow(height/.035,2.))*exp(-pow((horizontal-1.5)/.48,2.));gl_FragColor=vec4(vec3(.12,.002,.006)*pulse+vec3(3.,.025,.045)*glint*pulse,fade*.5);}`});materials.push(em);signMats.push(em);const edges=new T.LineSegments(eg,em);edges.position.x=x;edges.renderOrder=5;sign.add(edges);
   }
   // Small bloom emitters on the top rims, matching the reference's restrained highlights.
   for(const x of [-1.2,1.66]){const glint=new T.ShaderMaterial({transparent:true,depthWrite:false,blending:T.AdditiveBlending,uniforms:{pulse:{value:1}},vertexShader:vertex,fragmentShader:`varying vec2 vUv;uniform float pulse;void main(){vec2 p=(vUv-.5)*vec2(5.,12.);float a=exp(-dot(p,p));gl_FragColor=vec4(vec3(1.4,.008,.018)*pulse,a*.38);}`});signMats.push(glint);plane(.9,.2,glint,x,3.15,-4.9);}
   // Continuously advected, soft-edged clouds at two different depths.
   const fogs:T.ShaderMaterial[]=[];
   for(const [z,amount,center,spread] of [[-3,.13,.46,.24],[-2,.09,.29,.16],[2,.035,.19,.09]]){
    const mat=new T.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{time:{value:0},amount:{value:amount},center:{value:center},spread:{value:spread}},vertexShader:vertex,fragmentShader:`varying vec2 vUv;uniform float time,amount,center,spread;${noise}void main(){vec2 p=vUv;float phase=time*6.2831853/90.;vec2 drift=vec2(cos(phase),sin(phase))*.8;float n=fbm(p*vec2(4.,5.)+drift);float cloud=smoothstep(.28,.75,n);float band=exp(-pow((p.y-center)/spread,2.));float edges=smoothstep(0.,.15,p.x)*(1.-smoothstep(.85,1.,p.x))*smoothstep(0.,.08,p.y)*(1.-smoothstep(.8,1.,p.y));gl_FragColor=vec4(vec3(.075,.085,.1),cloud*band*edges*amount);}`});fogs.push(mat);plane(16.72,9.41,mat,0,0,z);
   }
   // Reproject the SAME source pixels through the registered car matte. This preserves
   // the reference camera, contact shadows and reflections without floating cutouts.
   const foreground=new T.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{photo:{value:loaded[0]},matte:{value:loaded[1]}},vertexShader:vertex,fragmentShader:`varying vec2 vUv;uniform sampler2D photo,matte;void main(){vec4 c=texture2D(photo,vUv);float a=texture2D(matte,vUv).a;gl_FragColor=vec4(c.rgb,a);}`});plane(16.72,9.41,foreground,0,0,0);
   // Glow follows the photographic wall strips; no central decorative flare.
   const lights=new T.ShaderMaterial({transparent:true,depthWrite:false,blending:T.AdditiveBlending,uniforms:{time:{value:0}},vertexShader:vertex,fragmentShader:`varying vec2 vUv;uniform float time;float line(vec2 p,vec2 a,vec2 b){vec2 q=p-a,d=b-a;float h=clamp(dot(q,d)/dot(d,d),0.,1.);return length(q-d*h);}void main(){vec2 p=vec2(min(vUv.x,1.-vUv.x),vUv.y);float d=min(line(p,vec2(0.,.624),vec2(.13,.552)),min(line(p,vec2(0.,.543),vec2(.115,.502)),line(p,vec2(0.,.472),vec2(.11,.447))));float glow=exp(-pow(d/.002,2.))*.3+exp(-pow(d/.014,2.))*.045;float pulse=.55+.45*pow(.5+.5*sin(time*.65),5.);float fade=1.-smoothstep(.06,.14,p.x);gl_FragColor=vec4(vec3(.9,.002,.008),glow*pulse*fade);}`});plane(16.72,9.41,lights,0,0,-4);
   composer=new EffectComposer(renderer);composer.addPass(new RenderPass(scene,camera));const bloom=new UnrealBloomPass(new T.Vector2(1000,563),.12,.4,.85);composer.addPass(bloom);composer.addPass(new OutputPass());
   const size=()=>{const w=Math.min(2000,Math.round(el.clientWidth*Math.min(devicePixelRatio,1.5)));renderer!.setSize(w,Math.round(w*941/1672),false);composer!.setSize(w,Math.round(w*941/1672));composer!.render()};resize=new ResizeObserver(size);resize.observe(el);size();el.appendChild(renderer.domElement);el.dataset.engine='webgl';announce();
   observer=new IntersectionObserver(e=>{visible=e[0].isIntersecting});observer.observe(el);
   renderer.domElement.addEventListener('webglcontextlost',(e)=>{e.preventDefault();el.dataset.engine='fallback'});
   let previous=performance.now(),elapsed=0,last=0;
   const draw=(now:number)=>{if(disposed)return;const dt=Math.min((now-previous)/1000,.1);previous=now;if(visible&&!document.hidden&&entered&&!reduced.matches){elapsed+=dt;if(now-last>32){fogs.forEach((m,i)=>m.uniforms.time.value=elapsed+i*19);lights.uniforms.time.value=elapsed;signMats.forEach(m=>m.uniforms.pulse.value=.85+.15*Math.sin(elapsed*.55));composer!.render();el.dataset.time=elapsed.toFixed(2);last=now}}frame=requestAnimationFrame(draw)};frame=requestAnimationFrame(draw);
  }catch(error){el.dataset.engine='fallback';announce();console.warn('Hero WebGL fallback',error)}};
  build();return()=>{disposed=true;cancelAnimationFrame(frame);window.removeEventListener('avtolab:entered',enter);resize?.disconnect();observer?.disconnect();textures.forEach(t=>t.dispose());geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());composer?.dispose();renderer?.dispose();renderer?.domElement.remove()};
 },[start]);
 return <section className="hero cinema-hero"><div className="hero-image cinema-stage"><div ref={host} className="cinema-render"><div className="cinema-fallback" aria-hidden="true"><img className="cinema-room" src={assets.room} alt=""/></div></div></div><div className="hero-content cinema-title"><h1><span className="hero-title-main">ПРЕМИАЛЬНОЕ РЕШЕНИЕ</span><span className="hero-title-sub">ДЛЯ ВАШЕГО АВТОМОБИЛЯ</span></h1></div></section>;
}
