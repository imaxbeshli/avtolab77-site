# AVTOLAB77 — визуальная версия сайта

Адаптивный сайт на Next.js 16, React 19, TypeScript. Дизайн по утверждённому референсу: тёмная студия, автомобильный hero, два направления, услуги, выбор моделей, проекты, студия и консультация.

## Посмотреть без установки

Открыть `/workspace/previews/AVTOLAB77.html` в современном браузере. В одном файле встроены все изображения, шрифты и React-интерфейс. Работают внутренние страницы, карусель автомобилей, FAQ и демонстрационная форма. Доступ к интернету не требуется. Контакты и отправка заявок ожидают наполнения.

## Разработка

Node.js 24, npm 11. Из `/workspace/avtolab77-site/avtolab77-new`:

```sh
npm ci
npm run dev
```

Dev-сервер слушает порт 3000. `npm run build` создаёт статический сайт в `out/`. Его можно разместить на статическом хостинге. Для локальной проверки сборки: `python3 -m http.server 3001 --directory out`. `npm start` для режима static export не используется.

## Проверки

- `npm run typecheck`
- `npm run build`
- `node scripts/export-preview.mjs` — пересобрать автономный HTML
- `python3 -m http.server 4173 --directory /workspace/previews`
- `node scripts/check-preview.cjs` — Chromium; проверка 320/360/390/430/768/1024/1280/1440/1920, навигации, формы, ESC, выбора моделей и проектов, скриншоты

В проверенной версии проходят сборка и тесты интерфейса. Горизонтальный overflow отсутствует на всех девяти размерах. JS-ошибок в проверенных сценариях нет. Файловая навигация запрещена политикой браузера облачной среды, поэтому автономный документ проверен через локальный HTTP; сам документ не использует сетевые зависимости.

## Контент и изображения

- `content/services.ts` — 12 услуг.
- `content/site.ts` — модели, демонстрационные проекты, страницы.
- `public/assets/hero.webp`, `details.webp`, `vehicles-v2.webp`, `glass-backdrop.webp` — сгенерированные визуальные концепты; не фотографии реальных работ или подтверждённых моделей.
- `public/assets/fonts` — локальные Manrope и Montserrat с кириллицей, лицензии OFL приложены.
- `components/Site.tsx` — компоненты главной, страниц, навигации и формы.
- `app/globals.css` — стили, шрифты и адаптивность.

Изображения обозначены как демонстрационные. Совместимость всех моделей требует проверки. Контакты, цены и реальные кейсы не выдуманы. Социальные иконки ведут на страницу контактов до появления подтверждённых адресов. Индексация закрыта через metadata robots. Форма проверяет введённые поля, но не отправляет и не сохраняет данные.

## Перед публичным запуском

Наполнить подтверждёнными материалами и контактами, подключить CMS и реальную обработку заявок с серверной валидацией, утвердить юридические документы и таблицу совместимости, настроить SEO/домен/редиректы. Production-публикация не выполнялась.

## Согласованные визуальные правки — версия 2

- Убраны пункты верхней навигации, подзаголовок hero и кнопка выбора услуг.
- Заголовок секции — «Услуги студии»; удалены ссылки «Все услуги» и «Смотреть все работы».
- Карусель содержит ZEEKR 9X, ZEEKR 8X и Lynk & Co 900, с отдельными сгенерированными визуализациями.
- Иконки цифровых услуг контурные, без красного свечения. Строка совместимости и дополнительная CTA под каруселью убраны.
- Карточки проектов содержат только изображения. Доступные названия ссылок сохранены через aria-label.
- Нижняя часть страницы использует тёмный каменный фон и полупрозрачные поверхности с backdrop blur. Проверены desktop и mobile.
- Текущий текстовый логотип оставлен до получения нового файла от владельца.
- Новый файл для просмотра: `/workspace/previews/AVTOLAB77-v2.html`.

## Версия 3 — логотип, автомобили без фона и единый стиль

- Логотип подготовлен из присланного изображения; локальный ассет `brand-logo.webp`.
- `vehicles-cutout.webp` содержит автомобили с прозрачным фоном: без пола и отражений.
- Карусель поддерживает колёсико мыши/трекпада, перетаскивание мышью, горизонтальный жест пальцем, кнопки и клавиатуру. Вертикальная прокрутка на touch сохранена.
- Убраны декоративные стрелки на карточках услуг и направлений, ссылка «Больше о студии» и отдельный подвал.
- Обновлён текст о студии. К трём фактам добавлен предоставленный владельцем тезис «5 лет гарантии на любое эксплуатационное повреждение».
- Главная завершается блоком консультации. Плитки и поверхности используют общие графитовые цвета, рамки и радиусы.
- Файл просмотра: `/workspace/previews/AVTOLAB77-v3.html`. Изображения автомобилей остаются визуализациями; форма работает в демонстрационном режиме.
- Проверки: сборка/TypeScript, 9 размеров экрана, wheel, mouse drag, keyboard, CDP touch swipe и вертикальная touch-прокрутка, форма и переходы — успешно.

## Версия 4 — композиция по исходному референсу

- Новый `studio-panorama.webp`: автомобиль целиком, больше студийного пространства и красные световые линии. Изображение плавно растворяется в общем фоне страницы.
- `styles/studio.css` объединяет оформление первого экрана, фотографий, карточек, автомобильной сцены и блока студии. Нижняя часть использует мягкую световую полосу и сдержанный каменный фон.
- Поверх фотографии подготовлен отдельный SVG-слой свечения ламп (`hero-lamps`, `--lamp-intensity`) для последующей анимации; основное освещение остаётся частью изображения.
- `components/VehicleSelector.tsx`: циклическая карусель с пятью физическими позициями и незаметной перестановкой после перехода. Крайняя модель уходит за край, не пересекает центр при возврате. Поддерживается reduced motion.
- Проверены полный цикл вперёд и назад, wheel, drag, keyboard, touch, вертикальная прокрутка, навигация и форма. Девять ширин 320–1920 px без переполнения; TypeScript и production build успешны.
- Автономный просмотр: `/workspace/previews/AVTOLAB77-v4.html`. Все изображения, шрифты и интерактивность встроены. Форма остаётся демонстрационной.

## Version 6 — motion and smoked glass

Intro now replays on a full document load, not on internal navigation; sessionStorage no longer suppresses it. IntersectionObserver reveals section headings, direction cards, services, digital tiles, projects and studio facts. Hero fog and red lamps animate independently using CSS. All motion respects prefers-reduced-motion. Centered typography, glass overlays and a continuous studio/consultation backdrop are implemented in styles/studio.css.

Validation: npm run typecheck, npm run build, scripts/check-motion.cjs and scripts/check-v5.cjs. The latter includes desktop/mobile screenshots and overflow checks. Public preview is deployed from the gh-pages branch of imaxbeshli/avtolab77-site. Publish by exporting the standalone HTML and updating index.html in the existing gh-pages checkout (/tmp/avtolab77-pages). Do not replace the branch history. Latest revision: a0f7ef1. Site: https://imaxbeshli.github.io/avtolab77-site/ . GitHub Actions must complete before describing a change as published.

## Version 7 — text centering correction

Restored bold hero typography (weight 800). Removed inherited maximum widths and left-anchored layout from fact captions; reset card text widths so equal left/right offsets center actual text containers. Verified 320/360/390/650/768/1024/1440/1920 px in scripts/check-centering.cjs: no horizontal overflow, centered heading/paragraph alignment, matching caption/headline and card/title centers within 1 px. Deployment commit: 9d2bfcc on gh-pages.

## Version backup workflow

The user requires recoverable versions for each future published visual revision. Keep immutable ZIPs under gh-pages/versions, each containing standalone index.html, VERSION.json with its SHA-256 and source commit, and Russian viewing/rollback instructions. Include a source/ snapshot for each new revision; omit dependencies, build caches and credentials. Preserve all earlier ZIPs and version HTMLs. Update versions/index.html and manifest.json, verify ZIP integrity and matching index hashes, then publish and confirm Pages completion. Never overwrite a historical version or force-push to roll back. Restore a selected index.html via a new commit, verify in browser, and wait for deployment. Historical v5–v7 packages contain standalone sites only; v8 includes source. Public version catalog: https://imaxbeshli.github.io/avtolab77-site/versions/ .

## Version 9 — two-car scene and primary section hierarchy

Generated a shared studio scene with Rolls-Royce Cullinan on the left and ZEEKR 9X on the right (studio-duo.webp). Updated SVG light positions to both walls. Desktop and mobile preserve both complete vehicles. Renamed the services heading to «Автостайлинг и детейлинг» and enlarged it and «Русификация и цифровые решения» equally. Verified centering/overflow at eight widths, desktop/mobile hero screenshots and matching section font sizes. Previous archives remain immutable.

## Version 10 — reference-style ground and studio

The hero and direction cards no longer overlap. Added carousel-asphalt.webp as a shared floor, attached model-matched reflections and contact light to each moving carousel slot, and removed translucent side car bodies. Replaced the third/fourth project visuals with Porsche/Audi front-corner closeups, preserving BMW/Mercedes. Restored a compact studio row with subtle upper light, stone edges and red fact dividers; consultation remains the last block. Checked hero/card clearance at 6 widths, reflections and wheel/keyboard transitions, centering at 8 widths, and production build.

## Version 11 — feathered floor and independent animations

Viewport-wide asphalt with a radial feather mask and slight defocus replaces hard rectangular floor edges. Distant logo is a separate subdued screen-blended layer, ready for later neon animation. Replaced digital direction image and windshield protection image; reordered styling services to ppf/tinting/polishing/glass/pdr/soundproofing. Scroll reveal now uses Web Animations with per-section stagger, independent of hover transitions. All six digital cards have stable bounds during hover. Verified progressive opacity in actual intermediate frames, eight viewport widths, carousel reflection continuity and production build. Screenshot evidence: reveal-v11-start.png / reveal-v11-end.png in local previews. Reduced motion remains supported.

## Version 12 — reliable entrance and discrete selection

Removed distant scene logo, softened/lowered hero typography, replaced the studio introduction with four centered facts (17 years, 10,000+ cars, premium materials, 5-year warranty), and centered a narrower consultation panel with its button below. Intro exists at first render, waits for the logo decode/visible document, shows and fades the logo, then reveals the hero with a gentle camera scale. Reduced motion shows a short static logo. Full reload replays the entrance; internal navigation does not. Car gestures track intent only, with no visual movement while held; release/click/wheel triggers one 720ms transition, repeated input during motion is ignored. Checks: build, check-v12, check-centering, check-v5, progressive reveal and all six hover bounds, native mobile touch swipe. Prior versions remain immutable.

## Version 13 — slower logo entrance

The logo now fades in for approximately 1 second, stays readable for 1 second and fades out for 1 second. The black curtain dissolves over 0.7 seconds from 2.9s; the camera entry lasts 1.8s. Verified real opacity at 450/1400/2500ms, camera animation and scroll release in check-intro-timing.cjs. Other site design is unchanged. scripts/archive-version.py now provides the repeatable, non-overwriting archive workflow.

## Version 14 — continuous entrance and WebGL atmosphere

Replaced conflicting CSS/reduced-motion entrance branches with one frame-controlled timeline: logo fade in 1.2s, hold .9s, fade out 1.2s, curtain 1.1s and gentle scene entry 2.2s. Logo decode and fonts finish before the timeline starts; bounded per-frame progress prevents loading stalls from skipping the fade. Reduced motion keeps opacity transitions and removes camera movement. Scroll elements and icons reveal sequentially at 120ms intervals without hover transforms.

Three.js renders procedural moving fog and subtle red reflected light on a transparent shader plane over the photographic hero. It starts after the entrance, renders at capped resolution/rate and pauses offscreen; CSS atmosphere remains as fallback. Cars are still photographs, not 3D models. Verified normal/reduced intro intermediate opacity, changing WebGL frames, reveal timing, eight responsive widths/centering, hover stability, wheel interaction, console and production build (30 static routes). Control recording: motion-v14.webm.

## Version 15 — seamless entrance and grounded atmosphere

The curtain now waits for all opening animations to finish. WebGL is prepared behind the logo and starts moving after entry; stable scrollbar gutters prevent width changes on scroll unlock. Browser sampling verifies hero bounds before/after curtain removal differ by less than 0.1px. Logo retains frame-progress protection; the opening uses coordinated compositor animations.

Fog is more visible around wheels and follows a continuous 32-second circular noise path. Three aligned pairs of wall strips breathe smoothly over eight seconds without flashes. Carousel cars have depth offsets, selected lighting, contact shadows and model-matched mirrored reflections. Section/carousel reveals move vertically upward; icons also rise rather than scale. Compact consultation reads “Обсудим ваш автомобиль” on one line with the booking button beneath it.

Validation: production build (30 pages), check-v14 (normal/reduced intro and changing WebGL frames), check-v15 (handoff bounds, lights, carousel and CTA at 320/390/768/1440), check-centering (8 widths), check-v11 (stable hover and sequential reveal). Cars remain photographic assets. Prior version archives are preserved.

## Version 16 — upward row reveal and visible scene motion

Removed per-column reveal delays: each intersecting row rises together with zero delay and 24px vertical movement over 1.1s. This fixes the perceived left-to-right sweep. Card artwork now zooms only 2.5% over 1.4s within clipped bounds; line icons do not enlarge. Increased the visible two-layer drifting mist and GPU fog motion, and replaced subtle breathing with a seven-second varied lamp pulse. Consultation heading matches section Montserrat weight 750 and tracking.

Validation: check-v16 asserts zero stagger/vertical keyframes, actual intermediate zoom values and unchanged card bounds, moving mist transforms and lamp opacity, matching heading family/weight. Production build and eight-width centering check passed. check-v16 supersedes older stagger assertions in check-v14/check-v11. Reduced-motion preferences retain static atmosphere. Prior archives remain immutable.

## Version 17 — geometric Three.js studio

Replaced the first-screen photographic overlay renderer with a perspective 3D scene. components/studio3d.ts builds two original procedural SUV models (326 scene meshes including detailed wheels, glazing, chrome, grilles and lamps), studio walls, six emissive wall strips, real point/directional lighting, shadow maps and a reflected wet floor. Vehicle models are simplified interpretations, not licensed/exact Rolls-Royce or ZEEKR production models. They do not use vehicle photographs or billboard geometry.

A depth-texture postprocess raymarches animated 3D density inside a low fog volume. Integration stops at visible scene geometry. Floor reflections use a second camera with rough surface distortion. Lamp intensity animates actual scene lights and the fog scattering tint. Photographic/CSS atmosphere is disabled when the real scene is available, retained as a WebGL failure fallback. Offscreen rendering pauses, shadow maps cache static geometry, and render resolution is capped at 1200px width. Mobile camera framing adapts to the viewport. Original photographic v16 remains archived for comparison.

Validation: production build (30 routes), check-v17 verifies mesh count, disabled old effects, changing rendered pixels and physical light intensity, browser errors and responsive canvas sizes. Model fidelity remains visibly lower than the photographic reference; this release establishes an actual editable 3D studio, not a claim of photorealistic vehicle reproduction.

## Version 18 — photographic baseline and gentle hover

Restored Atmosphere.tsx and studio.css from the v16 archive; the experimental v17 3D studio is not imported into this release. Photograph cards zoom internally to 1.03 over 1.8 seconds, and outline digital icons to 1.05 over 1.6 seconds. Both directions use the same easing and duration, with clipped/fixed card bounds. Mouse-only hover prevents sticky enlargement on touch; reduced motion disables the zoom. check-hover-v18 samples intermediate scale values on hover and exit for direction, service, project and digital cards and asserts unchanged card bounds. Production build passed.

## Version 19 — calmer selection, unified buttons and hero composition

Carousel transitions now last 1500ms with a shared ease-in/out curve for geometry, illumination, reflections and labels. Labels use consistent metrics and their highlight follows the incoming center position. Child transitions are disabled at the cyclic slot reset so a newly assigned sprite does not replay another car's lighting transition. Click/wheel/gesture intent handling remains discrete.

Header and consultation booking buttons share a translucent red background, 10px corners and restrained hover. Hero typography uses section Montserrat 750 weight, slightly larger desktop sizing and a lower position. Mobile positioning is independent and the scene moves upward to close the text/car gap. CSS fog cycles span 64/82 seconds with smaller movement; shader noise traverses its path over 90 seconds. Wall lights have occasional soft glints during a 22-second cycle.

Validation: production build, check-v19 at 320/390/768/1440; identical button styling; sampled carousel geometry and label opacity remain continuous across reset; keyboard and wheel transitions; browser errors. Archive originals are stored only in site-archives, keeping Pages lightweight.

## Version 20 — light looping fog and periodic wall glow

Restored perceptible atmosphere without the dense/fast v16 look. CSS fog follows continuous 32/43-second loops with staggered phases and lower opacity; shader flow has a 48-second cycle with reduced density. Wall strips and their aura rise/fall smoothly every 12 seconds, with no long inactive interval. v19 layout, buttons, hero type and carousel are preserved. check-atmosphere-v20 verifies real drift/light changes, matching cycle boundaries, reduced-motion CSS and no shader/browser errors; production build passed. publish-archived.py now prepares lightweight releases from the separately stored archive and pins the previous version correctly.

## Version 21 — unified photographic service sections

Replaced the two duplicate introductory direction cards with two complete service compositions. Auto styling has a new front-facing BMW studio image, centered title and all six existing service cards inside one frame. Digital services retain the three-model selector and six functional cards on a shared wet studio floor. Heading links retain access to both category pages. Newly generated studio assets are local WebP files and embedded in the standalone release.

Retained v20 hero atmosphere, intro, smooth carousel, upward scroll reveals and gentle internal hover zoom. Mobile styling tiles scroll horizontally; digital services wrap into two columns. The digital floor is framed separately on narrow screens to align with the vehicles instead of falling behind the icon grid.

Validation: 30-route production build; check-v21 at 320, 390, 768 and 1440 pixels checks retained service links/counts, no horizontal page overflow, carousel completion, stable card bounds on hover, detail navigation and browser errors. Desktop and mobile panel screenshots reviewed. Standalone release and complete source are archived separately from the lightweight Pages deployment; previous versions remain unchanged.

## Version 22 — continuous studio background and expandable service rail

Removed the large section frames and independent digital/studio background panels. A single generated graphite-floor image spans the homepage; the hero and styling photograph have soft edge masks, while projects, facts and the booking area continue on the same surface. BMW framing adapts to small screens. Service and project tiles retain their images with quieter outlines; digital icons have lighter surfaces.

Photographic hover now scales the actual `::before` artwork inside its stationary clipping box by 5.5% over 1.35 seconds, in both directions. This keeps labels and borders still and makes the slow approach perceptible. Reduced-motion preferences disable this zoom. Intro, upward reveals, 1500ms vehicle transitions, light fog and periodic wall glow remain.

Services are grouped explicitly by direction rather than split at a fixed array index. Home styling renders the complete group in a fixed-width horizontal rail, with a partial next tile and edge fades. Mouse wheel and keyboard scrolling use a subpixel accumulator to avoid rounding stalls near the end. Dragging suppresses link activation, native touch handles swiping, and wheel events at the boundary continue scrolling the page. Projects use the same rail behavior. No additional demo services were published.

Validation: production build (30 static routes); `check-v22.cjs` checks 320/390/768/1440/1920 widths, transparent borderless sections, real intermediate hover scales and stable tile bounds, appended future cards, wheel/drag/keyboard/edge release, carousel and service navigation. `check-v22-touch.cjs` checks native touch input, no accidental navigation, moving fog/lamp opacity, vertical icon reveal, reduced motion and mobile header. Desktop and mobile screenshots reviewed. The separate version archive includes the standalone site, source and generated assets; v21 remains available for rollback.

## Version 23 — restore the previous facts block

Restored the v21 facts block's glass/rock background, red vertical dividers and original internal spacing. Soft alpha masks on the background and light layers join it to the continuous v22 floor without a straight top edge. The current booking area, other sections and interactions remain unchanged.

Validation: production build (30 routes); browser comparison against the archived v21 at 1440 and 390 pixels confirms matching facts spacing/divider styling and no page overflow. Reviewed desktop/mobile screenshots of the restored block and its transition. v22 is retained in the version archive.

## Version 24 — restored CTA frame, frosted cards and uninterrupted page scrolling

Restored the consultation frame with a thin red border, rounded corners and translucent red-tinted background. Digital service tiles now use a lighter translucent gradient with 14px backdrop blur, keeping text/icons fully opaque. The continuous background and v23 facts backdrop remain.

Removed the vehicle selector's wheel listener entirely. Wheel and vertical trackpad gestures scroll the page; model changes retain their 1500ms animation on neighboring-car clicks and horizontal mouse/touch gestures. Native vertical touch panning and pinch zoom are allowed. Arrow keys remain available for keyboard users. The independent service rail keeps its wheel behavior.

All four facts headings now share Montserrat, weight 700, line height, tracking and one column-relative font-size rule. The common responsive size fits the two-line premium-materials label instead of giving that label a separate smaller font. Narrow-screen inner padding gives the titles more space.

Validation: production build; check-v24 covers wheel pass-through without model changes, intermediate click animation, drag/release selection, service-rail scrolling, matching/fitting typography at 320/390/768/1440, CTA dialog, native vertical touch scrolling and horizontal model swipes. Desktop/mobile visual review of glass cards and restored consultation frame. Earlier releases remain archived.

## Version 25 — interior scene, lighter headings and transparent header

Removed the styling subtitle. Digital services now follow the same visual order as styling: centered heading, a large generated luxury-cabin photograph with Russian infotainment labels, then the existing model selector and six service tiles. The interior uses soft edge masks against the continuous floor and joins the existing upward reveal animation. The WebP asset is local and embedded in the standalone release.

Hero, section headings (including projects), and consultation now share Manrope 500, consistent tracking and line-height; all section headings share a responsive size. Facts and card-label typography are preserved. The sticky header uses a translucent dark fill with backdrop blur and no bottom border. An SVG color-matrix filter makes the existing logo's dark background transparent at display time without replacing or redrawing the logo asset.

Validation: production build (30 static routes); browser review at 320/390/768/1440 checks no overflow, image/selector/tile order, removed subtitle, consistent section typography and sticky borderless header. Desktop/mobile screenshots reviewed; the header logo was additionally checked over the bright hero reflections. Existing check-v24 passes for wheel/vertical touch page scrolling, click/drag/swipe model selection, service rail, facts typography and consultation dialog. v24 remains archived for rollback.

## Version 26 — integrated BMW scroll transformation

Integrated the approved photographic BMW transformation into the styling section. Native scrolling drives the glossy-to-matte body reveal followed by headlights; the scene releases naturally into the service rail. Only the normal section heading remains: no demo instructions, stage labels, progress indicators or replay controls. Embedded scene images keep the published HTML self-contained. Reduced-motion support, image-failure fallback and listener cleanup are included.

Validation: check-v26 passes all four stages at 320/390/768/1440 widths, sticky positioning and release, reverse scroll, detail/home remount, reduced motion, no overflow and no external asset requests. Desktop/mobile screenshots reviewed. v25 retained for rollback.

## Version 27 — mobile scene flow and opening-screen separation

The opening hero now fills at least one viewport so the styling heading appears only after scrolling. The BMW roof sits closer below its heading. On narrow screens and coarse touch devices, the whole BMW scene stays in normal document flow: no sticky hold or three-screen spacer. Gloss/matte/headlight progress follows the scene entering the viewport, completing while the car is visible. The compact scene joins directly to service cards. Desktop keeps the approved pinned progression and timing. Mobile hero composition is vertically balanced within the full opening screen.

Validation: production build; check-v27 verifies 320/390 phone portrait, 844 phone landscape, 768 touch tablet, 1440/1920 desktop. Checks include native touch movement of scene with page, all desktop stages, hidden second heading on initial viewport, compact heading/rail spacing, no overflow or browser errors. Desktop and mobile screenshots reviewed. v26 retained for rollback.

## Version 28 — compact mobile hero and blended BMW surroundings

The mobile/coarse-touch opening now follows its photographic composition instead of viewport height: a 48px heading inset, both cars fully visible, wet-floor reflections and a short fade into styling. Desktop hero geometry stays unchanged. BMW uses intersecting horizontal/vertical feather masks that preserve the body, a subtle lower-floor color blend, and a low-opacity crop of its wet floor extending behind the start of the service rail. The heading has no separate panel. Animation timing, sharp car layers and normal mobile document scrolling are preserved.

Validation: production build; check-v28 checks compact opening geometry at 320/390, landscape phone and touch tablet flow, native touch movement, no overflow, and the four transformation stages on 1440/1920 desktop. Mobile/desktop screenshots reviewed. v27 remains archived for rollback.

## Version 29 — scroll-driven infotainment translation

Replaced the static interior with an edited photograph that removes the rear-view mirror/overhead console and baked-in text while preserving dashboard, screen icons and car graphic. A single SVG camera moves the photograph and separate screen typography together, smoothly zooming 10% around the tablet. Native scroll drives staggered crossfades from 导航 / 空调 / 设置 to Навигация / Климат / Настройки, reversing on upward scroll. No pinning, scroll interception, instructions or progress controls. Mobile framing keeps the tablet readable and the surrounding cabin visible. Reduced motion disables camera zoom and directly follows scroll state. Chinese glyphs are embedded from a six-character Noto Sans CJK subset with its license, so standalone rendering does not depend on device fonts.

Validation: production build (30 static routes); check-v29 verifies sequential fades, final/reverse states, camera scale, page scrolling, reduced motion, local embedded assets/fonts, remount and zero browser errors/overflow at 320/390/768/1440 widths. Mobile/desktop screenshots reviewed. v28 retained for rollback.

## Version 30 — reforming screen text and clean model transition

Removed overlaid Chinese/Russian text layers. Each row now has one visible sequence of two glyph runs: each Chinese glyph briefly compresses, reforms into its Russian word segment and expands, with a local subtle blur only during change. Segments and rows are staggered deterministically by scroll, without random characters or language opacity crossfades. Reverse scroll restores Chinese; reduced motion skips deformation. Text widths keep adjacent segments together.

Removed the separate model-stage glow/background in the homepage digital section, faded the shared rough floor underneath that section into the same dark cabin tone, and replaced negative carousel margins with positive spacing. Carousel overflow is contained so it cannot cover the interior. Model contact shadows and restrained local lighting remain.

Validation: production build; check-v30 covers complete/reverse language states, one visible text sequence, non-overlapping cabin/carousel geometry, responsive overflow, model selection, wheel pass-through and reduced motion at 320/390/768/1440. Desktop/mobile visual review. v29 retained for rollback.

## Version 31 — desktop pinned localization scene

The homepage digital heading and cabin now share a desktop-only sticky stage below the header. Its native scroll span drives the existing 10% camera move and sequential glyph reformation, then releases into the model selector after completion. No wheel interception or body scroll lock is used. Narrow and coarse-touch devices retain the v30 normal document flow. Short desktop viewports have a smaller camera framing and heading to keep the tablet visible. Reverse scrolling and reduced-motion behavior remain supported.

Validation: production build; check-v31 covers desktop 1440/768, short 1280x500, phone portrait and touch landscape. Checks pinning, language stages, release, non-overlap with model selector, normal touch flow, reverse translation, reduced motion, overflow and browser errors. Desktop/mobile screenshots reviewed. v30 archived for rollback.

## Version 32 — visible desktop camera push-in

Increased the pinned desktop cabin camera movement from 10% to 30%, centered on the tablet and driven continuously by the same eased scroll progress. Touch/mobile retains its 10% movement; reduced motion still disables zoom. Text transformation, scene pin/release and model rail remain unchanged.

Validation: production build; check-v32 verifies camera scale at four scroll stages, desktop pin/release at wide/narrow/short viewports, mobile normal flow, reverse text, reduced motion and overflow. Desktop/mobile screenshots reviewed. v31 retained for rollback.

## Version 33 — tighter mobile digital-section spacing

For screens up to 650px, reduced the gap after styling services from 64px to 32px, cabin height to 240–300px, and heading bottom margin to 4px. Raised the camera within the cabin to 42%, reduced the model rail margin to 8px and rail height to 250px. Camera scale, text translation, desktop layout/pinning and model interaction are unchanged.

Validation: production build; browser review at 320/390/430 checks no horizontal overflow, the 8px non-overlapping cabin/model gap and visible tablet/vehicle content. Mobile screenshots reviewed. v32 saved for rollback.

## Version 34 — ultrawide image edges and hybrid desktop pinning

Applied horizontal feathering to the actual cabin SVG bounds, so the 1450px image no longer ends abruptly inside a wider viewport mask. Restricted coarse-pointer mobile rules to widths below 1024px, and made the digital sticky sequence unconditional at 1024px and above. This prevents touch-capable desktop devices from losing both BMW and cabin pinning or receiving the compact mobile hero. A stable dark BMW stage backdrop prevents the scrolling shared floor from moving behind its feathered edges.

Validation: production build; check-v34 exercises both scenes with real wheel input at 2048/3440 mouse, 2560/1024 touch-hybrid, plus a 390px phone. Verifies pin position through coating/lights and translation, release after completion, image edge masks and no overflow/browser errors. Wide screenshots reviewed. v33 retained for rollback.

For viewports at least 2000px wide, both photographic scenes additionally scale against viewport height/width with capped sizes, avoiding a small fixed-width image on an ultrawide monitor. Rechecked the two ultrawide cases after this geometry adjustment.

## Version 35 — reference-inspired hero typography and layered atmosphere

Split the hero heading into a wide Montserrat 800 silver-gradient main line and a lighter tracked subtitle. Added a scalable outline 77 sign behind the heading, with subdued red glow and slow opacity breathing. Added a separate slow procedural SVG mist layer registered to the hero photograph; its mask excludes the two car silhouettes and fades vertically into the far floor. Existing foreground GPU atmosphere and lights remain. Mobile retains compact composition with fitted typography. Reduced motion disables the new drift/glow loops.

Validation: production build; check-v35 verifies 320/390/1440/2048 layouts, fitted headline and no overflow, rear atmosphere/occlusion and sign presence, changing fog transform, reduced motion and no browser errors. Desktop/mobile screenshots reviewed. v34 retained for rollback.

## Version 36 — rebuilt hero atmosphere and dedicated typography

Generated a refined studio photograph with coherent distant wall haze and reflections while preserving both cars. Replaced stretched Montserrat headline with locally embedded Unbounded variable Cyrillic subset (OFL included). Removed the polygon-traced vehicle fog mask entirely. The distant 77 now has separate contour/bloom layers with a slow pulse and an independently drifting, softly bounded haze layer composited in front of the digits. Existing foreground atmosphere remains. Reduced motion disables new loops.

Validation: production build; 390/1440 browser review confirms font loading, no overflow, active sign pulse/haze animations. Screenshots reviewed. v35 retained for rollback.

## v37 — layered approved hero

The hero uses registered 1672×941 environment and transparent car masters in
`public/assets/masters/v37/`. WebP copies retain native resolution; no artificial
4K claim or upscaling. `HeroDepth.tsx` contains editable vector 77, soft pulse and
rear mist. `Site.tsx` keeps the Russian heading as real selectable text. Layer order:
environment → lamps/sign → rear haze → alpha cars → GPU foreground fog → title.
All layers share the same aspect ratio; mobile has its own title placement.
Reduced-motion preferences disable drift and pulse. Intro lifecycle is preserved.

Validation: production build; Chromium 320/390/1440/3440 px, heading/overflow,
image loading, moving rear haze, reduced motion and no runtime errors.

## v38 — long 77 and seamless hero edges

Extended the vector legs of both sevens from 280 to 520 units. A local SVG
opacity gradient fades them out before the closed lower edges. Removed the
central decorative red line and the additional sign-local rectangular fog layer.
Photographic backdrop now has its own top/side/bottom feathering; the parent no
longer clips fog or the mobile sign. Wider screens use a broader side feather.
Verified production build and Chromium at 320, 390, 1440 and 3440 px.

## v39 — rebuilt cinematic opening scene

`components/CinematicHero.tsx` replaces the former hero markup and overlays.
New assets are independent room, Rolls-Royce and ZEEKR images; PNG masters live
in `public/assets/masters/v39`, native 1672×941 room and 1536×1024 cars. Room has
no baked fog. Vehicles are photographic alpha planes, not low-poly vehicle meshes.
Three.js renders the room, bevelled/extruded 77 geometry, luminous edge/glint
materials, depth-separated procedural fog, vehicle shadows and attenuated
reflections. Bloom uses EffectComposer/UnrealBloomPass. No decorative centre line.
Fog is shader-driven and loops over 90 seconds. Rendering pauses offscreen and in
hidden tabs; reduced motion freezes time. Resolution capped at 2000 pixels, frame
rate at 30 fps. HTML image fallback remains if WebGL cannot initialize or is lost.
Editable HTML title stays independent of the canvas. Other sections preserved.

Checks: production Next build; Chromium 390/1440/3440, real WebGL initialized,
clock advances, reduced motion stops it, no runtime errors or horizontal overflow.

## v40 — preserve the approved reference composition

Restored the approved camera angles, relative sizes, placement, photographic
contact shadows and wet-floor reflections. The clean photographic plate is a
minimal fog-removal retouch of the approved composition, not two newly styled
cars. Native 1672×941 PNG master: public/assets/masters/v40/approved-composition-clean.png.
A registered matte reprojects identical photo pixels in front of rear atmosphere;
this deliberately locks vehicle layout to the approved plate. It is not a free
3D vehicle model. Removed v39 synthetic reflections/shadows and separate vehicle
placements. Updated wall-light coordinates to this reference. Geometry 77, live
shader fog, reduced-motion behavior and independent HTML title remain.
Validation: production build and real Chromium WebGL at 390, 1440, 3440 pixels;
no browser errors/overflow; animation runs and reduced-motion freezes time.
