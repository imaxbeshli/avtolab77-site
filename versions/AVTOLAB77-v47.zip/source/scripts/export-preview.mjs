import {build} from 'esbuild';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';
const output='/workspace/previews';
await mkdir(output,{recursive:true});
const result=await build({entryPoints:['scripts/preview-entry.tsx'],bundle:true,minify:true,write:false,format:'iife',jsx:'automatic',define:{'process.env.NODE_ENV':'"production"'},target:['es2020']});
let js=result.outputFiles[0].text;
// SVG scene images also need embedding for the standalone Pages release.
const sceneAssets=[...new Set([...js.matchAll(/["'](\/assets\/[^"'\s]+\.(?:webp|png))["']/g)].map(m=>m[1]))];
for(const url of sceneAssets){const data=await readFile(path.join('public',url));const mime=url.endsWith('.png')?'image/png':'image/webp';js=js.split(url).join(`data:${mime};base64,${data.toString('base64')}`)}
let css=(await readFile('app/globals.css','utf8'))+'\n'+(await readFile('styles/studio.css','utf8'));
const urls=[...new Set([...css.matchAll(/url\(['"]?(\/assets\/[^)'"\s]+)['"]?\)/g)].map(m=>m[1]))];
for(const url of urls){const data=await readFile(path.join('public',url));const mime=url.endsWith('.woff')?'font/woff':url.endsWith('.woff2')?'font/woff2' :url.endsWith('.png')?'image/png':'image/webp';css=css.split(url).join(`data:${mime};base64,${data.toString('base64')}`)}
const html=`<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="icon" href="data:,"><meta name="robots" content="noindex,nofollow"><title>AVTOLAB77 — дизайн сайта</title><style>${css}</style></head><body><div id="root"></div><script>${js.replaceAll('</script','<\\/script')}</script></body></html>`;
await writeFile(output+'/AVTOLAB77.html',html);
console.log(`Standalone: ${output}/AVTOLAB77.html (${(Buffer.byteLength(html)/1024/1024).toFixed(2)} MB)`);
