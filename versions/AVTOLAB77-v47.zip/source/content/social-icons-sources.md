# Social marks, v47
Telegram, VK, YouTube, Instagram: Simple Icons, CC0, via @iconify-json/simple-icons 1.2.101.
https://github.com/simple-icons/simple-icons
MAX Messenger: Arcticons max-messenger, CC BY-SA 4.0, via @iconify-json/arcticons 1.2.59. Stroke adjusted for the 22px header display; shape unchanged.
https://github.com/Arcticons-Team/Arcticons
https://creativecommons.org/licenses/by-sa/4.0/
All marks use currentColor. No external runtime icon requests.
Links retain the existing /contacts destination until studio account URLs are supplied.
