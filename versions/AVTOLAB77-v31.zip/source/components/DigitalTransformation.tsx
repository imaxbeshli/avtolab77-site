'use client';
import {useEffect,useRef} from 'react';

const labels=[['导航','Навигация'],['空调','Климат'],['设置','Настройки']];
const words=labels.map(([cn,ru])=>[...cn].map((glyph,j)=>({cn:glyph,ru:ru.slice(Math.round(j*ru.length/cn.length),Math.round((j+1)*ru.length/cn.length))})));
export function DigitalTransformation(){
 const scene=useRef<HTMLDivElement>(null),camera=useRef<SVGGElement>(null);
 useEffect(()=>{
  const el=scene.current;if(!el)return;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const parts=Array.from(el.querySelectorAll<SVGGElement>('.screen-part'));
  const texts=parts.map(part=>part.querySelector('text')!);
  let current=0,target=0,frame=0,last=0,disposed=false;
  const clamp=(n:number)=>Math.max(0,Math.min(1,n));
  const smooth=(n:number)=>{const p=clamp(n);return p*p*(3-2*p)};
  const paint=(p:number)=>{
   const zoom=reduced.matches?1:1+.1*smooth(p);
   camera.current?.setAttribute('transform',`translate(830 475) scale(${zoom}) translate(-830 -475)`);
   words.forEach((row,i)=>{let x=0;row.forEach((word,j)=>{
    const index=i*2+j,part=parts[index],text=texts[index];
    const phase=smooth((p-(.16+i*.2+j*.07))/.18),russian=phase>=.5;
    // One visible glyph run: compress, reform, and expand, never superimpose languages.
    const pulse=reduced.matches?0:Math.pow(Math.sin(Math.PI*phase),4),scale=1-.92*pulse;
    const value=russian?word.ru:word.cn;
    if(text.textContent!==value)text.textContent=value;
    text.setAttribute('font-family',russian?'Manrope, sans-serif':'TabletChinese, sans-serif');
    text.setAttribute('font-size',russian?'20':'22');
    part.setAttribute('transform',`translate(${x} 0) scale(${scale} 1)`);
    part.style.filter=pulse>.01?`blur(${pulse*.65}px)`:'none';
    part.dataset.language=russian?'ru':'zh';part.dataset.phase=phase.toFixed(4);
    x+=text.getComputedTextLength()*scale;
   })});
   el.dataset.progress=p.toFixed(4);el.dataset.zoom=zoom.toFixed(4);
  };
  const tick=(now:number)=>{if(disposed)return;const dt=Math.min(64,now-last);last=now;current=reduced.matches?target:current+(target-current)*(1-Math.exp(-dt/120));if(Math.abs(current-target)<.0001)current=target;paint(current);frame=current!==target?requestAnimationFrame(tick):0};
  const update=()=>{
   const pinned=el.closest<HTMLElement>('.digital-pinned'),sequence=el.closest<HTMLElement>('.digital-sequence');
   if(pinned&&sequence&&getComputedStyle(pinned).position==='sticky'){
    const inset=parseFloat(getComputedStyle(pinned).top)||0;
    target=clamp((inset-sequence.getBoundingClientRect().top)/Math.max(1,sequence.offsetHeight-pinned.offsetHeight));
   }else{
    const viewport=document.documentElement.clientHeight,start=viewport*.82,end=Math.max(78,viewport*.16);
    target=clamp((start-el.getBoundingClientRect().top)/(start-end));
   }
   if(!frame){last=performance.now();frame=requestAnimationFrame(tick)}
  };
  paint(0);update();document.fonts.ready.then(()=>{if(!disposed)paint(current)});addEventListener('scroll',update,{passive:true});addEventListener('resize',update);reduced.addEventListener('change',update);
  return()=>{disposed=true;cancelAnimationFrame(frame);removeEventListener('scroll',update);removeEventListener('resize',update);reduced.removeEventListener('change',update)};
 },[]);
 return <div ref={scene} className="digital-interior digital-transformation" role="img" aria-label="Русификация экрана автомобиля: китайские подписи плавно меняются на Навигация, Климат и Настройки">
  <svg className="digital-camera" viewBox="0 0 1536 1024" aria-hidden="true"><g ref={camera}>
   <image href="/assets/digital-interior-v29.webp" width="1536" height="1024"/>
   {words.map((row,i)=><g key={i} className="screen-label" transform={`translate(695 ${423+i*55})`}>{row.map((word,j)=><g key={j} className="screen-part" transform={`translate(${j*22} 0)`}><text fontFamily="TabletChinese, sans-serif" fontSize="22" fill="#e8edf0">{word.cn}</text></g>)}</g>)}
  </g></svg>
 </div>;
}
