'use client';
import {useRef,useState,type PointerEvent,type KeyboardEvent} from 'react';
import {Plus,Minus} from 'lucide-react';

type View={scale:number;x:number;y:number};
type Point={x:number;y:number};
const initial:View={scale:1,x:0,y:0};
const limit=(value:number,min:number,max:number)=>Math.max(min,Math.min(max,value));

export function LocationMap(){
 const viewport=useRef<HTMLDivElement>(null),image=useRef<HTMLImageElement>(null);
 const current=useRef<View>(initial),points=useRef(new Map<number,Point>());
 const gesture=useRef<{view:View;center:Point;distance:number}|null>(null);
 const [view,setView]=useState<View>(initial),[dragging,setDragging]=useState(false);
 const update=(next:View)=>{
  const scale=limit(next.scale,1,3),edge=(scale-1)/2;
  current.current={scale,x:limit(next.x,-edge,edge),y:limit(next.y,-edge,edge)};
  setView(current.current);
 };
 const sample=()=>{
  const rect=viewport.current!.getBoundingClientRect();
  const [a,b]=Array.from(points.current.values());
  return {center:{x:((b?(a.x+b.x)/2:a.x)-rect.left)/rect.width-.5,
   y:((b?(a.y+b.y)/2:a.y)-rect.top)/rect.height-.5},
   distance:b?Math.hypot(b.x-a.x,b.y-a.y):0};
 };
 const begin=(event:PointerEvent<HTMLDivElement>)=>{
  if(event.button!==0||points.current.size>=2)return;
  // Stop a button-driven zoom at its actual visible frame before dragging.
  if(!points.current.size&&image.current){
   const rect=event.currentTarget.getBoundingClientRect();
   const matrix=new DOMMatrixReadOnly(getComputedStyle(image.current).transform);
   update({scale:matrix.a,x:matrix.e/rect.width,y:matrix.f/rect.height});
  }
  points.current.set(event.pointerId,{x:event.clientX,y:event.clientY});
  event.currentTarget.setPointerCapture(event.pointerId);
  gesture.current={view:current.current,...sample()};setDragging(true);
 };
 const move=(event:PointerEvent<HTMLDivElement>)=>{
  if(!points.current.has(event.pointerId)||!gesture.current)return;
  points.current.set(event.pointerId,{x:event.clientX,y:event.clientY});
  const start=gesture.current,now=sample();
  const scale=limit(start.view.scale*(start.distance>0?now.distance/start.distance:1),1,3);
  const ratio=scale/start.view.scale;
  update({scale,x:now.center.x-(start.center.x-start.view.x)*ratio,
   y:now.center.y-(start.center.y-start.view.y)*ratio});
 };
 const end=(event:PointerEvent<HTMLDivElement>)=>{
  if(!points.current.delete(event.pointerId))return;
  // Rebase when a pinch becomes a one-finger drag, preventing a jump.
  gesture.current=points.current.size?{view:current.current,...sample()}:null;
  setDragging(points.current.size>0);
 };
 const zoom=(factor:number)=>{
  const before=current.current,scale=limit(before.scale*factor,1,3),ratio=scale/before.scale;
  update({scale,x:before.x*ratio,y:before.y*ratio});
 };
 const keyboard=(event:KeyboardEvent<HTMLDivElement>)=>{
  if(event.key==='+'||event.key==='='){event.preventDefault();zoom(1.4)}
  else if(event.key==='-'){event.preventDefault();zoom(1/1.4)}
  else if(event.key==='0'||event.key==='Home'){event.preventDefault();update(initial)}
  else if(current.current.scale>1&&['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)){
   event.preventDefault();const v=current.current;
   update({...v,x:v.x+(event.key==='ArrowLeft'?.12:event.key==='ArrowRight'?-.12:0),
    y:v.y+(event.key==='ArrowUp'?.12:event.key==='ArrowDown'?-.12:0)});
  }
 };
 return <div className="booking-map">
  <div ref={viewport} className="booking-map-viewport" role="group" tabIndex={0}
   aria-label="Карта расположения студии. Масштаб: плюс и минус; перемещение: стрелки; исходный вид: Home."
   aria-keyshortcuts="+ - ArrowLeft ArrowRight ArrowUp ArrowDown Home"
   data-dragging={dragging} data-scale={view.scale.toFixed(3)}
   onPointerDown={begin} onPointerMove={move} onPointerUp={end} onPointerCancel={end}
   onLostPointerCapture={end} onKeyDown={keyboard}>
   <img ref={image} className="booking-map-image" src="/assets/studio-map-v61.webp" width={1315} height={1196}
    loading="lazy" decoding="async" draggable={false}
    style={{transform:`translate(${view.x*100}%,${view.y*100}%) scale(${view.scale})`}}
    alt="Схема расположения Автолаб77 рядом с метро Шелепиха и Москва-Сити"/>
  </div>
  <div className="booking-map-controls" role="group" aria-label="Масштаб карты">
   <button type="button" aria-label="Приблизить карту" disabled={view.scale>=3||dragging} onClick={()=>zoom(1.4)}><Plus size={18}/></button>
   <button type="button" aria-label="Отдалить карту" disabled={view.scale<=1||dragging} onClick={()=>zoom(1/1.4)}><Minus size={18}/></button>
  </div>
 </div>;
}
