# BMW scroll prototype 1

Standalone review of gloss-to-matte paint transformation, separate from the v25 site.

- Native page scrolling drives a sticky photographic scene; no wheel/touch preventDefault or scroll locking.
- 0–10%: glossy black BMW, headlights off.
- 10–73%: a soft horizontal reveal of a separately generated matte finish. SVG masks protect windows, wheels, grille, headlight lenses and lower trim.
- 79–93%: original headlight pixels and subtle floor light fade in after the body transition completes.
- Further scrolling exits the sticky scene. Reverse scrolling reverses the effect; replay returns to its start.
- Desktop scene spans 320svh; mobile 275svh. Reduced motion removes progress interpolation.

This is a photographic compositing prototype, not a physically rendered 3D vehicle. Generated variants may still contain small local differences in body detail; final production masks can be refined after visual review. Assets were generated from the same supplied BMW image; the stationary base and exclusion mask preserve the surrounding scene.

Build: python3 scripts/build-bmw-prototype.py. Output: /workspace/previews/bmw-scroll-v1.html, with embedded images/fonts for standalone viewing.

Validation: browser sampled progress 0/.45/.76/.97 at 1440px and 390px; paint precedes light; reverse/replay; reduced motion; no horizontal overflow or browser errors. Final desktop framing places the car below the heading.
